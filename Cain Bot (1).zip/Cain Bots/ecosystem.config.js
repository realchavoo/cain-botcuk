let Bots = [
{
name: "Distributors",
namespace: "Distributors",
script: 'index.js',
watch: true,
exec_mode: "cluster",
max_memory_restart: "2G",
cwd: "./Bots/Distributors/"
},
{
name: "Protection",
namespace: "Protection",
script: 'index.js',
watch: true,
exec_mode: "cluster",
max_memory_restart: "2G",
cwd: "./Bots/Protection/"
},
{
name: "Welcome",
namespace: "Welcome",
script: 'index.js',
watch: true,
exec_mode: "cluster",
max_memory_restart: "2G",
cwd: "./Bots/Welcome/"
}
]
module.exports = { apps: Bots }