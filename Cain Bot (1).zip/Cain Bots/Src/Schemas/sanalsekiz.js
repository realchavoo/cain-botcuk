const { Schema, model } = require("mongoose");

const Roles = Schema({
  user1Id: String,
  user2Id: String,
  channelId: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = model("sanalsekiz", Roles);
