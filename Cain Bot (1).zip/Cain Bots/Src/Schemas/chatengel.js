const { Schema, model } = require("mongoose");

const chatengel = Schema({
    userId: { type: String, required: true, unique: true }
});

module.exports = model("chatengel", chatengel);
