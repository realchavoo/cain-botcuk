const { Schema, model } = require("mongoose");

const schema = Schema({
guildID: { type: String, required: true },
words: { type: [String], default: [] }
});

module.exports = model("yasakkelime", schema);