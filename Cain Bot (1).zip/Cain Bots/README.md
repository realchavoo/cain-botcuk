Bu Bot cainchavo Tarafından Yapılmıştır Ve  
Bu Bot Alaz Kardeşime Benden Ufak Bi Hediye Kimseyle Paylaşmıyacağına İnandığım Için Sana Atiorum Seviliosun Aslan Kardeşim  
Botu Kurman İçin Önce Aşşağıda Uygulamaları İndirmen Gerekiyor  
Sonrasında Klasörüm İçresindeki Src Dosyasını Açiosun Orda Settings Dosyasını Aç Set5ins.js Yazan Dosyayı Eksiksiz Doldur  
Sonra Klasörde ModülDowland Yazan Şeye Tıkla Modülleri İndir Cmd Kapanana Kadar Bekle
Sonrasında Start.bat Dosyasını Çalıştır Ve pm2 log Yaz Enter La Ve O Arka Planda Açık Kalacak Sürekli 
Allaha Emanet Güle Güle Kullan


Kurulması Gereken :

https://aka.ms/vs/17/release/vc_redist.x64.exe

https://fastdl.mongodb.org/windows/mongodb-windows-x86_64-7.0.0-signed.msi

https://fastdl.mongodb.org/tools/db/mongodb-database-tools-windows-x86_64-100.9.0.msi

https://nodejs.org/dist/v20.10.0/node-v20.10.0-x64.msi