const settings = require("../../../../../Src/Settings/Settings.json");
const emojis = require("../../../../../Src/Settings/emojiName.json");
const Users = require("../../../../../Src/Schemas/UsersDB");
const setups = require("../../../../../Src/Schemas/Setup");
const Puans = require("../../../../../Src/Schemas/Puans");
const moment = require("moment");
require("moment-duration-format");
moment.locale("tr");
const CommandPermissions = require("../../../../../Src/Schemas/CommandPermissions")
module.exports = {
    conf: {
        aliases: ["ycekk"],
        name: "ycekk",
        help: "yetkial @Cain/ID",
        category: "terfi",
    },
    Cyrstal: async (client, message, args, embed, prefix) => {
        const ayar = await setups.findOne({ guildID: message.guild.id });
        if (!ayar) return;

        const Name = [];
        const Data = await CommandPermissions.findOne({ guildID: message.guild.id, Command: Name.map(x => x) });
        if (!Data?.Permissions?.some(x => message.member.roles.cache.has(x) || x.includes(message.author.id)) && 
            !ayar.seniorStaffRoles.some(x => message.member.roles.cache.has(x)) && 
            !ayar.roleAddRoles.some((x) => message.member.roles.cache.has(x)) && 
            !message.member.permissions.has(8n)) {
            await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            return message.reply({ content: "Bu Komutu Kullanabilmek İçin Yeterli Yetkiniz Bulunmamaktadır." }).sil(15);
        }

        let üye = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!üye) {
            await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            return message.reply({ content: "Bir Kullanıcı Etiketle" }).sil(15);
        }

        // Eksik obje kontrolü
        if (!message.guild || !message.guild.roles || !message.guild.roles.highest) {
            await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            return message.reply({ content: "Sunucunun rollerine erişilemiyor." }).sil(15);
        }

        if (!üye || !üye.roles || !üye.roles.highest) {
            await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            return message.reply({ content: "Üyenin rollerine erişilemiyor." }).sil(15);
        }

        // Yetki kontrolü
        if (message.member.roles.highest.position <= üye.roles.highest.position) {
            await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            return message.reply({ content: `Senden yüksekte olan birisinin yetkisini çekemezsin.` }).sil(15);
        }

        // Kendini kontrol et
        if (message.author.id === üye.id) {
            await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            return message.reply({ content: `Kendini yetkiden çekemezsin.` }).sil(15);
        }

        // Botlara işlem yapma
        if (ayar.SafeBots.includes(üye.user.id)) {
            await message.react(message.guild.emojiGöster(emojis.no));
            return message.reply({ content: "Botlara İşlem Yapamazsın" }).sil(15);
        }

        // Üye kontrolü
        let kontrol = await Users.findOne({ _id: üye.id });
        if (kontrol && kontrol.Staff == false) {
            await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            return message.reply({ content: `${üye} isimli üye zaten yetkili olarak belirlenmemiş.` }).sil(15);
        }

        let altYetki = message.guild.roles.cache.get(ayar.registerPerms);
        await üye.removeRoles(üye.roles.cache.filter(rol => altYetki.position <= rol.position && rol.id !== message.guild.id && message.guild.members.cache.get(client.user.id).roles.highest.position > rol.position).map(rol => rol.id))
            .then(async () => {
                await message.reply({ content: `${message.guild.emojiGöster(emojis.yes)} ${üye} Kullanıcısının Yetkisi ${message.author} Tarafından Alındı.` }).sil(15);
                await message.react(message.guild.emojiGöster(emojis.yes)).catch(e => {});
            }).catch(async err => {
                await message.reply({ content: `${message.guild.emojiGöster(emojis.yes)} ${üye} Kullanıcısının Yetkisi Alınırken Bir Hata Oldu.` }).sil(15);
                await message.react(message.guild.emojiGöster(emojis.no)).catch(e => {});
            });

        await Puans.updateOne({ guildID: settings.Moderation.guildID, userID: üye.id }, { $set: { puan: 0 } }, { upsert: true }).exec();
        const ytsi = kontrol ? kontrol.StaffGiveAdmin : message.guild.id;
        await Users.updateOne({ _id: ytsi }, { $pull: { "Staffs": { id: üye.id } } }, { upsert: true }).exec();
        await Users.deleteMany({ _id: üye.id }, { upsert: true }).exec();

        const channel = await client.kanalBul("yetki-çek-log");
        channel.send({ embeds: [embed.setDescription(`${üye.toString()} Üyesinin Yetkisi ${message.author} Tarafından <t:${String(Date.now()).slice(0, 10)}:R> Alındı!`)] });
    }
};
