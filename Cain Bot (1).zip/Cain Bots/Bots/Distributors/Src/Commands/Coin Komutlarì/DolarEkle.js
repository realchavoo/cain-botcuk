const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const dolars = require("../../../../../Src/Schemas/Dolars");
const emojis = require('../../../../../Src/Settings/emojiName.json');
const setups = require("../../../../../Src/Schemas/Setup");
const settings = require("../../../../../Src/Settings/Settings.json");

module.exports = {
    conf: {
        aliases: ["dolarekle", "paraekle"],
        name: "dolarekle",
        help: ".dolarekle @Cain/ID <Miktar>",
        category: "dolarcik",
        owner: true, // Sadece yetkili kişiler kullanabilir
    },

    Cyrstal: async (client, message, args) => {
        // Yalnızca bir sunucuda çalışmasını sağla
        if (!message.guild) return;

        // Sunucu ayarlarını kontrol et
        const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
        if (!ayar) {
            return message.reply({ content: `Sunucu ayarları bulunamadı. Sistem kurulu değil.` });
        }

        // Komutun sadece yetkililer tarafından kullanılmasını sağla
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply({
                content: `${message.guild.emojiGöster(emojis.no)} Bu komutu kullanmak için Yönetici yetkisine sahip olmalısınız.`,
            });
        }

        // Kullanıcı argümanını kontrol et
        const targetUser =
            message.mentions.members.first() ||
            message.guild.members.cache.get(args[0]);

        if (!targetUser) {
            return message.reply({
                content: `${message.guild.emojiGöster(emojis.no)} Bir kullanıcı etiketlemeli veya bir kullanıcı ID'si girmelisiniz.`,
            });
        }

        // Miktar argümanını kontrol et
        const amount = parseInt(args[1]);
        if (!amount || isNaN(amount) || amount <= 0) {
            return message.reply({
                content: `${message.guild.emojiGöster(emojis.no)} Geçerli bir miktar belirtmelisiniz. (Örneğin: \`!dolarekle @kullanıcı 100\`)`,
            });
        }

        // Kullanıcının dolar verisini güncelle
        await dolars.findOneAndUpdate(
            { userID: targetUser.id, guildID: settings.Moderation.guildID },
            { $inc: { dolar: amount } },
            { upsert: true }
        );

        // Başarılı mesajı
        const embed = new EmbedBuilder()
            .setTitle("Dolar Ekleme İşlemi")
            .setDescription(
                `${message.guild.emojiGöster(emojis.yes)} ${targetUser} kullanıcısına başarılı bir şekilde **${amount}** **${ayar.GuildName}** doları eklendi.`
            )
            .setColor("Green")
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    }
};
