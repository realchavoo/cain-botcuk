const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { createCanvas } = require("canvas");
const dolars = require("../../../../../Src/Schemas/Dolars");
const emojis = require('../../../../../Src/Settings/emojiName.json');
const setups = require("../../../../../Src/Schemas/Setup");
const settings = require("../../../../../Src/Settings/Settings.json");

module.exports = {
    conf: {
        aliases: ["cuzdan", "cash", "cüzdan", "dolarim", "dolarım"],
        name: "cuzdan",
        help: "cuzdan @Kullanici/ID",
        category: "dolarcik",
    },

    Cyrstal: async (client, message, args) => {
        if (!message.guild) return;

        const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
        if (!ayar) return;

        const allowedChannels = ["dolar", "dolar-chat"];
        if (!allowedChannels.some(channel => message.channel.name.toLowerCase().includes(channel))) {
            await message.react(message.guild.emojiGöster(emojis.no));
            return await message.reply({
                content: `${message.guild.emojiGöster(emojis.no)} Bu komut sadece dolar kanallarında kullanılabilir.`
            }).then(msg => setTimeout(() => msg.delete(), 15000));
        }

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
        if (!member) {
            return await message.reply({ content: 'Kullanıcı bulunamadı. Lütfen bir kullanıcı etiketleyin veya doğru bir ID girin.' });
        }

        let dolarData = await dolars.findOne({ guildID: settings.Moderation.guildID, userID: member.id });
        if (!dolarData || (dolarData && !dolarData.dolar)) {
            await message.react(message.guild.emojiGöster(emojis.no));
            return await message.reply({
                content: `${message.guild.emojiGöster(emojis.no)} ${member} üyesinin hesabı bulunmuyor.`
            }).then(msg => setTimeout(() => msg.delete(), 15000));
        }

        const username = member.user.username;
        const userID = member.id;  // Adding user ID
        const bakiye = Math.floor(parseInt(dolarData.dolar));

        const canvas = createCanvas(1000, 400);
        const ctx = canvas.getContext('2d');

        // Apply a gradient background
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, "#4b6cb7");
        gradient.addColorStop(1, "#182848");
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Align text to the left by setting the x-coordinate for the text
        const textPadding = 40; // Add padding from the left edge
        const textX = textPadding; // Left-aligned text

        // Drawing the information on the left side
        ctx.fillStyle = "#FFD700";
        ctx.font = '50px Bold Arial';
        ctx.textAlign = 'left'; // Align text to the left
        ctx.fillText(`${username}'in Cüzdanı`, textX, 80); // User's name

        ctx.fillStyle = "#00FF00";
        ctx.font = '35px Arial';
        ctx.fillText(`💵 Bakiye: ${bakiye.toLocaleString()} Dolar`, textX, 150); // Balance

        ctx.font = '25px Arial';
        ctx.fillStyle = "#FFFFFF";
        ctx.fillText(`🆔 Kullanıcı ID: ${userID}`, textX, 200); // User ID
        ctx.fillText(`🌍 Sunucu: ${ayar.GuildName}`, textX, 230); // Guild name

        // Adding a border
        ctx.strokeStyle = "#FFD700";
        ctx.lineWidth = 5;
        ctx.setLineDash([10, 5]);
        ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);

        const attachment = canvas.toBuffer();
        await message.reply({
            content: `${member}, cüzdan bilgilerin burada.`,
            files: [{ attachment: attachment, name: "cuzdan.png" }]
        });
    }
};
