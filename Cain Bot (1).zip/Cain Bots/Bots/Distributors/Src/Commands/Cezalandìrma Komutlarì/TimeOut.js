const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const ms = require('ms');
const settings = require("../../../../../Src/Settings/Settings.json");
const emojis = require("../../../../../Src/Settings/emojiName.json");
const setups = require("../../../../../Src/Schemas/Setup");
const CommandPermissions = require("../../../../../Src/Schemas/CommandPermissions");
const Discord = require("discord.js");

module.exports = {
    conf: {
        name: "timeout",
        aliases: ["timeout", "timeoutat", "tm"],
        help: "timeout @Cain/ID Süre Sebep",
        category: "cezalandirma",
        cooldown: 15,
    },

    Cyrstal: async (client, message, args, embed) => {
        const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
        if (!ayar) return;

        const Name = ["timeout", "timeoutat", "tm"];
        const Data = await CommandPermissions.findOne({ guildID: message.guild.id, Command: Name.map(x => x) });

        // Kullanıcıda yeterli yetki kontrolü
        if (!Data?.Permissions?.some(x => message.member.roles.cache.has(x) || x.includes(message.author.id)) && 
            !ayar.seniorStaffRoles.some(x => message.member.roles.cache.has(x)) && 
            !message.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) {
            
            await message.react(message.guild.emojiGöster(emojis.no));
            await message.reply({ content: "Bu komutu kullanabilmek için yeterli yetkiye sahip değilsin!" }).sil(15);
            return;
        }

        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!member) {
            await message.reply({ content: "Lütfen bir kullanıcı belirtmelisin!" }).sil(15);
            await message.react(message.guild.emojiGöster(emojis.no));
            return;
        }

        // Süre seçimi için menü oluşturma
        const row = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('timeout_duration')
                    .setPlaceholder('Timeout Süresini Seçin')
                    .addOptions(
                        { label: '60 Saniye', value: '60s' },
                        { label: '5 Dakika', value: '5m' },
                        { label: '10 Dakika', value: '10m' },
                        { label: '1 Saat', value: '1h' },
                        { label: '1 Gün', value: '1d' },
                        { label: '1 Hafta', value: '1w' }
                    )
            );

        await message.reply({
            content: `Lütfen ${member} kullanıcısına ne kadar süreyle timeout atacağınızı seçin.`,
            components: [row],
        });

        // Seçim yapıldıktan sonra işlem başlatma
        const filter = i => i.user.id === message.author.id; // sadece komutu kullanan kişi etkileşimde bulunabilir
        const collector = message.channel.createMessageComponentCollector({ filter, time: 15000 }); // 15 saniye süre

        collector.on('collect', async (interaction) => {
            const timeoutDuration = interaction.values[0]; // Seçilen süre
            const duration = ms(timeoutDuration); // Seçilen süreyi saniyeye çevir

            // Timeout sebebini belirleme
            let reason = "Genel zaman aşımı uygulandı."; // Varsayılan sebep
            switch (timeoutDuration) {
                case '60s': reason = "Kısa süreli zaman aşımı."; break;
                case '5m': reason = "5 dakikalık sessizlik cezası."; break;
                case '10m': reason = "10 dakikalık sessizlik cezası."; break;
                case '1h': reason = "1 saatlik sessizlik cezası."; break;
                case '1d': reason = "1 günlük sessizlik cezası."; break;
                case '1w': reason = "1 haftalık sessizlik cezası."; break;
                default: reason = "Genel zaman aşımı uygulandı."; break;
            }

            // Timeout işlemi
            if (!member.manageable) {
                await interaction.reply({ content: "Bu kullanıcıyı susturamıyorum!", ephemeral: true });
                return;
            }

            // Kullanıcıya timeout uygulama
            await member.timeout(duration, reason).catch(e => {});

            // İşlem sonrası kullanıcıya bilgi verme
            await interaction.reply({
                content: `${member.toString()} kullanıcısına **${reason}** sebebiyle ${timeoutDuration} kadar timeout atıldı.`,
                ephemeral: true
            });

            // Menü mesajını silme
            await interaction.message.delete();

            // Kullanıcıya zaman aşımı bildirisi
            await message.channel.send(`${member.toString()} kullanıcısı **${reason}** sebebiyle **${timeoutDuration}** süreyle zaman aşımına uğradı.`);

            // Log Gönderme
            const logChannel = message.guild.channels.cache.find(ch => ch.name === 'timeout-log');
            if (logChannel) {const { ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
            const ms = require('ms');
            const settings = require("../../../../../Src/Settings/Settings.json");
            const emojis = require("../../../../../Src/Settings/emojiName.json");
            const setups = require("../../../../../Src/Schemas/Setup");
            const CommandPermissions = require("../../../../../Src/Schemas/CommandPermissions");
            const Discord = require("discord.js");
            
            module.exports = {
                conf: {
                    name: "timeout",
                    aliases: ["timeout", "timeoutat", "tm"],
                    help: "timeout @Cain/ID Süre Sebep",
                    category: "cezalandirma",
                    cooldown: 15,
                },
            
                Cyrstal: async (client, message, args, embed) => {
                    const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
                    if (!ayar) return;
            
                    const Name = ["timeout", "timeoutat", "tm"];
                    const Data = await CommandPermissions.findOne({ guildID: message.guild.id, Command: Name.map(x => x) });
            
                    // Kullanıcıda yeterli yetki kontrolü
                    if (!Data?.Permissions?.some(x => message.member.roles.cache.has(x) || x.includes(message.author.id)) && 
                        !ayar.seniorStaffRoles.some(x => message.member.roles.cache.has(x)) && 
                        !message.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) {
                        
                        await message.react(message.guild.emojiGöster(emojis.no));
                        await message.reply({ content: "Bu komutu kullanabilmek için yeterli yetkiye sahip değilsin!" }).sil(15);
                        return;
                    }
            
                    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
                    if (!member) {
                        await message.reply({ content: "Lütfen bir kullanıcı belirtmelisin!" }).sil(15);
                        await message.react(message.guild.emojiGöster(emojis.no));
                        return;
                    }
            
                    // Kullanıcıya süreyi seçtirecek seçim menüsünü oluştur
                    const row = new ActionRowBuilder()
                        .addComponents(
                            new StringSelectMenuBuilder()
                                .setCustomId('timeout_duration')
                                .setPlaceholder('Timeout Süresini Seçin')
                                .addOptions(
                                    { label: '60 Saniye', value: '60s' },
                                    { label: '5 Dakika', value: '5m' },
                                    { label: '10 Dakika', value: '10m' },
                                    { label: '1 Saat', value: '1h' },
                                    { label: '1 Gün', value: '1d' },
                                    { label: '1 Hafta', value: '1w' }
                                )
                        );
            
                    await message.reply({
                        content: `Lütfen ${member} kullanıcısına ne kadar süreyle timeout atacağınızı seçin.`,
                        components: [row],
                    });
            
                    // Seçim yapıldıktan sonra işlem başlatma
                    const filter = i => i.user.id === message.author.id; // sadece komutu kullanan kişi etkileşimde bulunabilir
                    const collector = message.channel.createMessageComponentCollector({ filter, time: 15000 }); // 15 saniye süre
            
                    collector.on('collect', async (interaction) => {
                        const timeoutDuration = interaction.values[0]; // Seçilen süre
                        const duration = ms(timeoutDuration); // Seçilen süreyi saniyeye çevir
            
                        // Timeout sebebini belirleme
                        let reason = "Genel zaman aşımı uygulandı."; // Varsayılan sebep
                        switch (timeoutDuration) {
                            case '60s': reason = "Kısa süreli zaman aşımı."; break;
                            case '5m': reason = "5 dakikalık sessizlik cezası."; break;
                            case '10m': reason = "10 dakikalık sessizlik cezası."; break;
                            case '1h': reason = "1 saatlik sessizlik cezası."; break;
                            case '1d': reason = "1 günlük sessizlik cezası."; break;
                            case '1w': reason = "1 haftalık sessizlik cezası."; break;
                            default: reason = "Genel zaman aşımı uygulandı."; break;
                        }
            
                        // Timeout işlemi
                        if (!member.manageable) {
                            await interaction.reply({ content: "Bu kullanıcıyı susturamıyorum!", ephemeral: true });
                            return;
                        }
            
                        // Kullanıcıya timeout uygulama
                        await member.timeout(duration, reason).catch(e => {});
            
                        // Sebep ve süreyle birlikte kullanıcıya mesaj gönderme
                        await interaction.reply({
                            content: `${member.toString()} kullanıcısına **${reason}** sebebiyle **${timeoutDuration}** kadar zaman aşımı atıldı.`,
                            ephemeral: true
                        });
            
                        // Menü mesajını silme
                        await interaction.message.delete();
            
                        // Kullanıcıya zaman aşımı bildirisi
                        await message.channel.send({
                            content: `${member.toString()} kullanıcısı **${reason}** sebebiyle **${timeoutDuration}** süreyle **ZAMAN AŞIMINA UĞRADI**! ⏳`
                        });
                    });
                },
            };
            
                const logEmbed = new EmbedBuilder()
                    .setColor("Random")
                    .setAuthor({ name: member.user.tag, iconURL: member.user.avatarURL() })
                    .setDescription(`
                        **Kullanıcı**: ${member}
                        **Yetkili**: ${message.author}
                        **Süre**: ${timeoutDuration}
                        **Sebep**: ${reason}
                    `)
                    .setFooter({ text: `Tarih: ${new Date().toLocaleString()}` });

                // Log kanalına mesaj gönderme
                logChannel.send({ embeds: [logEmbed] }).catch(err => {
                    console.error('Log kanalı hatası:', err);
                });
            } else {
                console.log("timeout-log kanal bulunamadı!");
            }
        });
    },
};
