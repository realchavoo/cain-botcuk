const { 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    EmbedBuilder 
} = require("discord.js");
const ForbiddenWords = require("../../../../../Src/Schemas/yasakkelime");

module.exports = {
    conf: {
        aliases: ["yasakkelime", "yasak-kelime"],
        name: "yasakkelime",
        help: ".yasakkelime <Kelime>",
        category: "styonetim",
        owner: true,
        cooldown: 15,
    },
    Cyrstal: async (client, message) => {
        if (!message.member.permissions.has("ManageGuild")) 
            return message.reply("Bu komutu kullanmak için `ManageGuild` yetkisine sahip olmalısınız!");

        const guildID = message.guild.id;
        let data = await ForbiddenWords.findOne({ guildID });

        if (!data) {
            data = new ForbiddenWords({ guildID });
            await data.save();
        }

        const embed = new EmbedBuilder()
            .setTitle("Yasaklı Kelime Listesi")
            .setDescription(data.words.length 
                ? `🔒 **Yasaklı Kelimeler:**\n${data.words.map((w, i) => `**${i + 1}.** \`${w}\``).join("\n")}`
                : "⚠️ Henüz yasaklı kelime eklenmemiş!")
            .setColor("Grey")
            .setFooter({ text: "Yasaklı Kelime Sistemi" })
            .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("addWord")
                .setLabel("Kelime Ekle")
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId("removeWord")
                .setLabel("Kelime Çıkar")
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId("listWords")
                .setLabel("Kelime Listesi")
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId("clearWords")
                .setLabel("Tüm Kelimeleri Sil")
                .setStyle(ButtonStyle.Secondary)
        );

        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        // Buton Etkileşimleri
        const filter = (i) => i.user.id === message.author.id;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

        collector.on("collect", async (interaction) => {
            if (!data) {
                data = new ForbiddenWords({ guildID });
                await data.save();
            }

            if (interaction.customId === "addWord") {
                const modal = new ModalBuilder()
                    .setCustomId("addWordModal")
                    .setTitle("Kelime Ekle");

                const input = new TextInputBuilder()
                    .setCustomId("wordInput")
                    .setLabel("Eklenecek Kelime")
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder("Kelimeyi buraya yazın.")
                    .setRequired(true);

                const actionRow = new ActionRowBuilder().addComponents(input);
                modal.addComponents(actionRow);
                await interaction.showModal(modal);
            } else if (interaction.customId === "removeWord") {
                const modal = new ModalBuilder()
                    .setCustomId("removeWordModal")
                    .setTitle("Kelime Çıkar");

                const input = new TextInputBuilder()
                    .setCustomId("wordInput")
                    .setLabel("Çıkarılacak Kelime")
                    .setStyle(TextInputStyle.Short)
                    .setPlaceholder("Kelimeyi buraya yazın.")
                    .setRequired(true);

                const actionRow = new ActionRowBuilder().addComponents(input);
                modal.addComponents(actionRow);
                await interaction.showModal(modal);
            } else if (interaction.customId === "listWords") {
                embed.setDescription(data.words.length 
                    ? `🔒 **Yasaklı Kelimeler:**\n${data.words.map((w, i) => `**${i + 1}.** \`${w}\``).join("\n")}`
                    : "⚠️ Henüz yasaklı kelime eklenmemiş!");
                await sentMessage.edit({ embeds: [embed] });
                await interaction.reply({ content: "Yasaklı kelime listesi güncellendi!", ephemeral: true });
            } else if (interaction.customId === "clearWords") {
                data.words = [];
                await data.save();

                embed.setDescription("⚠️ Tüm yasaklı kelimeler silindi!");
                await sentMessage.edit({ embeds: [embed] });

                await interaction.reply({ content: "✅ Tüm yasaklı kelimeler başarıyla silindi!", ephemeral: true });
            }
        });

        // Modal Etkileşimleri
        client.on("interactionCreate", async (modalInteraction) => {
            if (!modalInteraction.isModalSubmit()) return;

            const word = modalInteraction.fields.getTextInputValue("wordInput");

            if (modalInteraction.customId === "addWordModal") {
                if (data.words.includes(word)) {
                    return modalInteraction.reply({ content: "Bu kelime zaten yasaklılar listesinde!", ephemeral: true });
                }

                data.words.push(word);
                await data.save();

                embed.setDescription(`🔒 **Yasaklı Kelimeler:**\n${data.words.map((w, i) => `**${i + 1}.** \`${w}\``).join("\n")}`);
                await sentMessage.edit({ embeds: [embed] });

                return modalInteraction.reply({ content: `✅ \`${word}\` kelimesi yasaklı kelimeler listesine eklendi!`, ephemeral: true });
            } else if (modalInteraction.customId === "removeWordModal") {
                if (!data.words.includes(word)) {
                    return modalInteraction.reply({ content: "Bu kelime yasaklılar listesinde bulunmuyor!", ephemeral: true });
                }

                data.words = data.words.filter((w) => w !== word);
                await data.save();

                embed.setDescription(data.words.length 
                    ? `🔒 **Yasaklı Kelimeler:**\n${data.words.map((w, i) => `**${i + 1}.** \`${w}\``).join("\n")}`
                    : "⚠️ Henüz yasaklı kelime eklenmemiş!");
                await sentMessage.edit({ embeds: [embed] });

                return modalInteraction.reply({ content: `✅ \`${word}\` kelimesi yasaklı kelimeler listesinden çıkarıldı!`, ephemeral: true });
            }
        });
    },
};
