const {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    EmbedBuilder,
  } = require("discord.js");
  const settings = require("../../../../../Src/Settings/Settings.json");
  const emojis = require("../../../../../Src/Settings/emojiName.json");
  const ChatMessage = require("../../../../../Src/Schemas/iltifatDB");
  const setups = require("../../../../../Src/Schemas/Setup");
  const CommandPermissions = require("../../../../../Src/Schemas/CommandPermissions");
  
  module.exports = {
    conf: {
      name: "iltifatmenu",
      aliases: ["iltifatmenu"],
      help: "İltifat ekle/sil/liste/düzenle",
      category: "styonetim",
    },
    Cyrstal: async (client, message, args, embed) => {
      const ayar = await setups.findOne({ guildID: message.guild.id });
      if (!ayar) return;
      const data = await ChatMessage.findOne({ guildID: message.guild.id });

      const Name = ["kelime", "söz", "soz"];
      const Data = await CommandPermissions.findOne({
        guildID: message.guild.id,
        Command: Name.map((x) => x),
      });
  
      if (!Data?.Permissions?.some(x => message.member.roles.cache.has(x) || x.includes(message.author.id)) &&
          !ayar.seniorStaffRoles.some(x => message.member.roles.cache.has(x)) &&
          !message.member.permissions.has("Administrator") &&
          !ayar.ownerRoles.some(x => message.member.roles.cache.has(x)) &&
          !ayar.roleAddRoles.some(s => message.member.roles.cache.has(s))) {
        await message.react(message.guild.emojiGöster(emojis.no));
        return message.reply({ content: "Bu komutu kullanmak için yeterli yetkiniz yok." }).then((msg) => msg.delete({ timeout: 15000 }));
      }
  
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("add").setLabel("Ekle").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("delete").setLabel("Sil").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("list").setLabel("Listele").setStyle(ButtonStyle.Secondary)
      );
  
      const initialEmbed = new EmbedBuilder()
        .setColor("Grey")
        .setTitle("🌟 İltifat Listesi")
        .setDescription(
          `Bu sunucuda **${data.sözler.length} adet iltifat** kayıtlıdır.\n` +
          `Aşağıdaki düğmeleri kullanarak iltifatları ekleyebilir, silebilir veya listeyi düzenleyebilirsiniz.`
        )
      const msg = await message.reply({ embeds: [initialEmbed], components: [row] });
  
      const collector = msg.createMessageComponentCollector({ time: 60000 });
  
      collector.on("collect", async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({ content: "Bu işlemi yalnızca komutu kullanan kişi yapabilir.", ephemeral: true });
        }
  
        if (interaction.customId === "add") {
          const modal = new ModalBuilder()
            .setCustomId("addModal")
            .setTitle("Yeni İltifat Ekle");
  
          const input = new TextInputBuilder()
            .setCustomId("iltifatInput")
            .setLabel("Eklenecek İltifat")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);
  
          modal.addComponents(new ActionRowBuilder().addComponents(input));
          await interaction.showModal(modal);
        }
  
        if (interaction.customId === "delete") {
          const modal = new ModalBuilder()
            .setCustomId("deleteModal")
            .setTitle("İltifat Sil");
  
          const input = new TextInputBuilder()
            .setCustomId("iltifatDeleteInput")
            .setLabel("Silinecek İltifat")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);
  
          modal.addComponents(new ActionRowBuilder().addComponents(input));
          await interaction.showModal(modal);
        }
  
        if (interaction.customId === "list") {
          const data = await ChatMessage.findOne({ guildID: message.guild.id });
          if (!data || !data.sözler || data.sözler.length === 0) {
            return interaction.reply({ content: "Henüz iltifat listesi bulunmuyor.", ephemeral: true });
          }
  
          const iltifatChunks = data.sözler.reduce((resultArray, item, index) => {
            const chunkIndex = Math.floor(index / 35);
            if (!resultArray[chunkIndex]) resultArray[chunkIndex] = [];
            resultArray[chunkIndex].push({ text: item, number: index + 1 });
            return resultArray;
          }, []);
  
          for (const [index, chunk] of iltifatChunks.entries()) {
            const listEmbed = new EmbedBuilder()
              .setTitle(`İltifat Listesi (${index + 1}/${iltifatChunks.length})`)
              .setDescription(chunk.map(({ text, number }) => `\`${number}.\` **${text}**`).join("\n"))
              .setColor("Green");
  
            await interaction.channel.send({ embeds: [listEmbed] });
          }
  
          return interaction.reply({ content: "İltifat listesi gönderildi!", ephemeral: true });
        }
      });
  
      client.on("interactionCreate", async (modalInteraction) => {
        if (!modalInteraction.isModalSubmit()) return;
  
        const data = await ChatMessage.findOne({ guildID: message.guild.id }) || new ChatMessage({ guildID: message.guild.id, sözler: [] });
  
        if (modalInteraction.customId === "addModal") {
          const iltifat = modalInteraction.fields.getTextInputValue("iltifatInput");
  
          if (data.sözler.includes(iltifat)) {
            return modalInteraction.reply({ content: "Bu iltifat zaten listede mevcut!", ephemeral: true });
          }
  
          data.sözler.push(iltifat);
          await data.save();
  
          return modalInteraction.reply({ content: `Başarıyla "${iltifat}" eklendi.`, ephemeral: true });
        }
  
        if (modalInteraction.customId === "deleteModal") {
          const iltifat = modalInteraction.fields.getTextInputValue("iltifatDeleteInput");
  
          if (!data.sözler.includes(iltifat)) {
            return modalInteraction.reply({ content: "Bu iltifat listede bulunamadı!", ephemeral: true });
          }
  
          data.sözler = data.sözler.filter((x) => x !== iltifat);
          await data.save();
  
          return modalInteraction.reply({ content: `Başarıyla "${iltifat}" silindi.`, ephemeral: true });
        }
      });
    },
  };
  