const { PermissionsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const schema = require("../../../../../Src/Schemas/chatengel");

module.exports = {
    conf: {
        aliases: ["chatengel"],
        name: "chatengel",
        help: "chatengel",
        category: "styonetim",
        owner: true,
    },

    Cyrstal: async (client, message, args) => {
        const targetUser = message.mentions.users.first() || client.users.cache.get(args[0]);
        if (!targetUser) return message.reply({ content: "Lütfen bir kullanıcı etiketleyin veya ID girin." });

        const guildMember = message.guild.members.cache.get(targetUser.id);

        if (!guildMember) return message.reply({ content: "Kullanıcı bu sunucuda bulunamadı." });

        if (guildMember.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply({ content: "Bir yöneticiyi chatten engelleyemezsiniz." });
        }

        if (targetUser.id === message.author.id) {
            return message.reply({ content: "Kendinizi chatten engelleyemezsiniz." });
        }

        let existing = await schema.findOne({ userId: targetUser.id });

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId("toggleBlock")
                    .setLabel(existing ? "Engeli Kaldır" : "Engelle")
                    .setStyle(existing ? ButtonStyle.Success : ButtonStyle.Danger)
            );

        const embed = new EmbedBuilder()
            .setColor(existing ? "Green" : "Red")
            .setAuthor({ name: `Kullanıcı: ${targetUser.tag}`, iconURL: targetUser.displayAvatarURL({ dynamic: true }) })
            .setDescription(
                existing
                    ? `**${targetUser.tag}** şu anda chatten engellenmiş durumda.`
                    : `**${targetUser.tag}** şu anda chatten engellenmemiş.`
            )
            .setFooter({ text: "Chat Engeli Yönetim Sistemi", iconURL: client.user.displayAvatarURL() })
            .setTimestamp();

        const sentMessage = await message.reply({ embeds: [embed], components: [buttons] });

        const filter = (interaction) => interaction.user.id === message.author.id;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 30000 });

        collector.on("collect", async (interaction) => {
            if (interaction.customId === "toggleBlock") {
                existing = await schema.findOne({ userId: targetUser.id }); // Son durum kontrolü

                if (existing) {
                    // Engeli kaldır
                    await schema.deleteOne({ userId: targetUser.id });
                    embed.setColor("Red").setDescription(`**${targetUser.tag}** chat engeli başarıyla kaldırıldı.`);
                    buttons.components[0]
                        .setLabel("Engelle")
                        .setStyle(ButtonStyle.Danger);
                } else {
                    // Engelle
                    await schema.updateOne(
                        { userId: targetUser.id },
                        { userId: targetUser.id },
                        { upsert: true } // Eğer kayıt yoksa oluşturur
                    );
                    embed.setColor("Green").setDescription(`**${targetUser.tag}** başarıyla chatten engellendi.`);
                    buttons.components[0]
                        .setLabel("Engeli Kaldır")
                        .setStyle(ButtonStyle.Success);

                    try {
                        await targetUser.send("Chatten engellendiniz. Yönetici ile iletişime geçin.");
                    } catch {}
                }
                await interaction.update({ embeds: [embed], components: [buttons] });
            }
        });

        collector.on("end", async () => {
            try {
                await sentMessage.edit({ components: [] });
            } catch {}
        });
    },
};


client.on("messageCreate", async (message) => {
    const isBlocked = await schema.findOne({ userId: message.author.id });
    if (isBlocked) {

            await message.delete();
            await message.author.send("Chatten engellendiniz ve yazdığınız her mesaj otomatik olarak silinecek.");

    }
});

// Periodik kontrol (örnek: her 1 dakikada bir kontrol ediliyor)
setInterval(async () => {
    const users = await schema.find();
    // Gerekirse başka işlemler eklenebilir.
}, 60000); // 60000 ms = 1 dakika
