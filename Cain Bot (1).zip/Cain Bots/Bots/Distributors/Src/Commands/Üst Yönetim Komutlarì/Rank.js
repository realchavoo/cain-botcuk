const rankDB = require("../../../../../Src/Schemas/RankSystem")
const emojis = require("../../../../../Src/Settings/emojiName.json")
const settings = require("../../../../../Src/Settings/Settings.json")
const Discord = require("discord.js")

module.exports = {
    conf: {
        name: "rank",
        aliases: ["ranks"],
        help: "rank ekle/sil/liste/ayarla/düzenle [Puan] @Rol/ID - @Hammer/ID",
        owner: true,
        category: "styonetim"
    },
    Cyrstal: async (client, message, args, embed) => {
        if (!args[0]) return message.reply({ content: "Lütfen geçerli bir işlem belirtin!" }).sil(15);

        if (args[0] === "ekle") {
            if (!args[1]) return message.reply({ content: "Lütfen geçerli bir puan belirtin!" }).sil(15);
            if (!Number(args[1])) return message.reply({ content: "Lütfen bir sayı belirtin!" }).sil(15);
            
            const args2 = args.splice(2).join(" ").split(" - ");
            if (!args2) {
                await message.react(message.guild.emojiGöster(emojis.no));
                return message.reply({ content: "Lütfen bir rol belirtin!" }).sil(15);
            }

            const role = args2[0].split(" ").map((e) => e.replace(/<@&/g, "").replace(/>/g, ""));
            if (!role) return message.reply({ content: "Lütfen bir rol belirtin!" }).sil(15);

            let hammer;
            if (!args2[0]) return message.reply({ content: "Lütfen bir rol belirtin!" }).sil(15);
            if (args2[1]) hammer = args2[1].split(" ").map((e) => e.replace(/<@&/g, "").replace(/>/g, ""));

            let data = await rankDB.findOne({ guildID: message.guild.id });
            if (!data) data = await new rankDB({ guildID: message.guild.id }).save();
            if (data && data.ranks.map(rank => rank.roleID).includes(role.id)) {
                return message.reply({ content: "Bu rol zaten veritabanında bulunuyor!" }).sil(15);
            }

            await rankDB.updateOne({ guildID: message.guild.id }, { $push: { ranks: { roleID: String(role), puan: Number(args[1]), hammer: hammer ? hammer : [] } } }, { upsert: true });
            data.RankSystem = true;
            data.save();
            await message.react(message.guild.emojiGöster(emojis.yes));
            await message.reply({ content: "Başarılı bir şekilde " + role.map(r => `**${message.guild.roles.cache.get(r).name}**`).join(", ") + " rolü veritabanına eklendi!" });
        } else if (args[0] === "sil") {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]);
            if (!role) return message.reply({ content: "Lütfen geçerli bir rol belirtin!" }).sil(15);

            let data = await rankDB.findOne({ guildID: message.guild.id, ranks: { $elemMatch: { roleID: role.id } } });
            if (data && !data.ranks.map(rank => rank.roleID).includes(role.id)) return message.reply({ content: "Bu rol veritabanında bulunamadı!" }).sil(15);

            await rankDB.updateOne({ guildID: message.guild.id }, { $pull: { ranks: { roleID: role.id } } });
            await message.react(message.guild.emojiGöster(emojis.yes));
            await message.reply({ content: "Başarılı bir şekilde **" + role.name + "** rolü veritabanından silindi!" });
        } else if (args[0] === "liste") {
            let data = await rankDB.findOne({ guildID: message.guild.id });
            if (!data) return message.reply({ content: "Veritabanında hiçbir rol bulunamadı!" }).sil(15);

            embed.setFooter({ text: "Toplam Yetki Sayısı: " + data.ranks.length, iconURL: message.guild.iconURL({ dynamic: true }) });
            embed.setDescription(`${message.guild.emojiGöster(emojis.info)} **${message.guild.name}** Sunucusunun Rank Sistem Ayarları Aşağıda Belirtilmiştir;\n\n${data.ranks.map((rank, index) => `\` ${index+1}. \` **Yetki: ${message.guild.roles.cache.get(rank.roleID) || "Bulunamadı."} Puan: ${rank.puan} Hammer: ${rank.hammer.map(y => message.guild.roles.cache.get(y)).join(", ") || "Bulunamadı."}**`).join("\n\n")}`);
            await message.react(message.guild.emojiGöster(emojis.yes));
            await message.reply({ embeds: [embed] });
        } else if (args[0] === "düzenle") {
            const yt = args[1];
            if (!yt) {
                await message.react(message.guild.emojiGöster(emojis.no));
                return message.reply({ content: "Lütfen bir yetki sırası belirtin!" }).sil(15);
            }

            let data = await rankDB.findOne({ guildID: message.guild.id });
            if (!data || !data.ranks) {
                await message.react(message.guild.emojiGöster(emojis.no));
                return message.reply({ content: "Veritabanında hiçbir yetki bulunamadı!" }).sil(15);
            }

            if (yt > data.ranks.length || yt < 1) {
                await message.react(message.guild.emojiGöster(emojis.no));
                return message.reply({ content: "Lütfen geçerli bir yetki sırası belirtin!" }).sil(15);
            }

            // Seçilen sıradaki rank verisini alıyoruz
            let rankToEdit = data.ranks[yt - 1]; // 1'den başlayarak sıralama yapıyoruz
            if (!rankToEdit) {
                await message.react(message.guild.emojiGöster(emojis.no));
                return message.reply({ content: "Lütfen geçerli bir yetki sırası belirtin!" }).sil(15);
            }

            // Kullanıcıya düzenleme seçeneklerini sunuyoruz
            const row = new Discord.ActionRowBuilder().addComponents(
                new Discord.RoleSelectMenuBuilder().setCustomId("permRolesSelectMenu").setPlaceholder("Yetkili Rol Düzenle").setMinValues(1).setMaxValues(1)
            );
            const row3 = new Discord.ActionRowBuilder().addComponents(
                new Discord.RoleSelectMenuBuilder().setCustomId("permRolesSelectMenu3").setPlaceholder("Hammer Rol Ekle").setMinValues(1).setMaxValues(20)
            );
            const row4 = new Discord.ActionRowBuilder().addComponents(
                new Discord.RoleSelectMenuBuilder().setCustomId("permRolesSelectMenu4").setPlaceholder("Hammer Rol Kaldır").setMinValues(1).setMaxValues(20)
            );
            const row5 = new Discord.ActionRowBuilder().addComponents(
                new Discord.StringSelectMenuBuilder().setCustomId("permRolesSelectMenu5").setPlaceholder("Puanı Düzenle").addOptions([{ label: "Puanı Düzenle", value: "duzenle" }]).setMinValues(1).setMaxValues(1)
            );

            // Hammer rolü varsa, Hammer silme işlemi aktif olmalı
            if (rankToEdit.hammer.length === 1) {
                row4.components[0].setDisabled(true);
            }

            const msg = await message.reply({
                embeds: [embed.setDescription(`${message.guild.emojiGöster(emojis.yes)} ${message.member} **${yt}** Sıradaki Yetki Bilgileri Aşağıda Belirtilmiştir.
                
                Yetkili Rol: ${message.guild.roles.cache.get(rankToEdit.roleID) || "Bulunamadı."}
                Hammer Rol: ${rankToEdit.hammer.map(x => message.guild.roles.cache.get(x)).join(", ") || "Bulunamadı."}
                Puan: **${rankToEdit.puan || "Bulunamadı."}**`)],
                components: [row, row3, row4, row5]
            });

            let filter = (i) => i.user.id === message.member.id;
            const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

            collector.on("collect", async i => {
                if (i.customId === "permRolesSelectMenu") {
                    if (!i.values[0]) return;
                    let data = await rankDB.findOne({ guildID: message.guild.id });
                    if (!data || !data.ranks) return await i.reply({ content: "Veritabanında hiçbir yetki bulunamadı!", ephemeral: true });

                    // Seçilen sıradaki rank verisini tekrar alıyoruz
                    let rankToEdit = data.ranks[yt - 1];
                    if (rankToEdit.roleID === i.values[0]) return await i.reply({ content: "Lütfen farklı bir yetki seçin!", ephemeral: true });

                    // Rolü güncelliyoruz
                    rankToEdit.roleID = i.values[0];
                    await rankDB.updateOne({ guildID: message.guild.id }, { $set: { "ranks": data.ranks } });

                    await i.reply({ content: "Yetki başarıyla ayarlandı!", ephemeral: true });
                    await msg.edit({
                        embeds: [embed.setDescription(`${message.guild.emojiGöster(emojis.yes)} ${message.member} **${yt}** Sıradaki Yetki Bilgileri Aşağıda Belirtilmiştir.

                        Yetkili Rol: ${message.guild.roles.cache.get(rankToEdit.roleID) || "Bulunamadı."}
                        Hammer Rol: ${rankToEdit.hammer.map(x => message.guild.roles.cache.get(x)).join(", ") || "Bulunamadı."}
                        Puan: **${rankToEdit.puan || "Bulunamadı."}**`)],
                        components: [row, row3, row4, row5]
                    });
                }

                if (i.customId === "permRolesSelectMenu3") {
                    if (!i.values[0]) return;
                    let data = await rankDB.findOne({ guildID: message.guild.id });
                    if (!data || !data.ranks) return await i.reply({ content: "Veritabanında hiçbir yetki bulunamadı!", ephemeral: true });

                    // Seçilen sıradaki rank verisini tekrar alıyoruz
                    let rankToEdit = data.ranks[yt - 1];
                    if (rankToEdit.hammer.includes(i.values[0])) return await i.reply({ content: "Lütfen farklı bir hammer seçin!", ephemeral: true });

                    // Yeni hammer'ı ekliyoruz
                    rankToEdit.hammer.push(i.values[0]);
                    await rankDB.updateOne({ guildID: message.guild.id }, { $set: { "ranks": data.ranks } });

                    await i.reply({ content: "Hammer rol başarıyla eklendi!", ephemeral: true });

                    if (rankToEdit.hammer.length > 1) {
                        row4.components[0].setDisabled(false);
                    }

                    await msg.edit({
                        embeds: [embed.setDescription(`${message.guild.emojiGöster(emojis.yes)} ${message.member} **${yt}** Sıradaki Yetki Bilgileri Aşağıda Belirtilmiştir.

                        Yetkili Rol: ${message.guild.roles.cache.get(rankToEdit.roleID) || "Bulunamadı."}
                        Hammer Rol: ${rankToEdit.hammer.map(x => message.guild.roles.cache.get(x)).join(", ") || "Bulunamadı."}
                        Puan: **${rankToEdit.puan || "Bulunamadı."}**`)],
                        components: [row, row3, row4, row5]
                    });
                }

                if (i.customId === "permRolesSelectMenu4") {
                    if (!i.values[0]) return;
                    let data = await rankDB.findOne({ guildID: message.guild.id });
                    if (!data || !data.ranks) return await i.reply({ content: "Veritabanında hiçbir yetki bulunamadı!", ephemeral: true });

                    // Seçilen sıradaki rank verisini tekrar alıyoruz
                    let rankToEdit = data.ranks[yt - 1];
                    if (!rankToEdit.hammer.includes(i.values[0])) return await i.reply({ content: "Lütfen sistemde olan bir hammer seçin!", ephemeral: true });

                    // Hammer'ı kaldırıyoruz
                    rankToEdit.hammer = rankToEdit.hammer.filter(x => x !== i.values[0]);
                    await rankDB.updateOne({ guildID: message.guild.id }, { $set: { "ranks": data.ranks } });

                    await i.reply({ content: "Hammer rol başarıyla kaldırıldı!", ephemeral: true });

                    if (rankToEdit.hammer.length === 1) {
                        row4.components[0].setDisabled(true);
                    }

                    await msg.edit({
                        embeds: [embed.setDescription(`${message.guild.emojiGöster(emojis.yes)} ${message.member} **${yt}** Sıradaki Yetki Bilgileri Aşağıda Belirtilmiştir.

                        Yetkili Rol: ${message.guild.roles.cache.get(rankToEdit.roleID) || "Bulunamadı."}
                        Hammer Rol: ${rankToEdit.hammer.map(x => message.guild.roles.cache.get(x)).join(", ") || "Bulunamadı."}
                        Puan: **${rankToEdit.puan || "Bulunamadı."}**`)],
                        components: [row, row3, row4, row5]
                    });
                }

                if (i.customId === "permRolesSelectMenu5") {
                    const Modal = new Discord.ModalBuilder()
                        .setTitle("Rank Puan Düzenleme")
                        .setCustomId("ranksystemedit");

                    const puans = new Discord.TextInputBuilder()
                        .setCustomId("puans")
                        .setPlaceholder("Puan Belirt.")
                        .setLabel("Puan Belirt.")
                        .setMinLength(1)
                        .setMaxLength(5)
                        .setRequired(true)
                        .setStyle(Discord.TextInputStyle.Short);

                    Modal.addComponents(new Discord.ActionRowBuilder().addComponents(puans));
                    await i.showModal(Modal);
                }
            });
        }
    }
};
