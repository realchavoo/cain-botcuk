const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const schema = require("../../../../../Src/Schemas/chatengel");

module.exports = {
    conf: {
        aliases: ["chatengel-liste", "chgl"],
        name: "chatengel-liste",
        help: "chatengel-liste",
        category: "styonetim",
        owner: true,
    },

    Cyrstal: async (client, message, args) => {
        const blockedUsers = await schema.find();

        if (!blockedUsers.length) {
            return message.reply({ content: "❌ Hiçbir kullanıcı chatten engellenmemiş." });
        }

        const embedBuilder = new EmbedBuilder()
            .setColor("Blue")
            .setTitle("🚫 Chat Engelli Kullanıcılar")
            .setDescription(
                blockedUsers
                    .map((user, index) => `**${index + 1}.** <@${user.userId}>`)
                    .join("\n")
            )
            .setFooter({ text: `Toplam: ${blockedUsers.length} kullanıcı`, iconURL: client.user.displayAvatarURL() })
            .setTimestamp();

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("clearAll")
                .setLabel("Tüm Engelleri Kaldır")
                .setStyle(ButtonStyle.Danger)
        );

        const sentMessage = await message.channel.send({ embeds: [embedBuilder], components: [buttons] });

        const filter = (interaction) => interaction.user.id === message.author.id;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 30000 });

        collector.on("collect", async (interaction) => {
            if (interaction.customId === "clearAll") {
                await schema.deleteMany(); // Tüm kayıtları sil

                // Embed'i güncelle
                embedBuilder
                    .setDescription("🚫 Tüm chat engelleri kaldırıldı.")
                    .setColor("Green")
                    .setFooter({ text: "Engellenen kullanıcı bulunmamaktadır.", iconURL: client.user.displayAvatarURL() })
                    .setTimestamp(new Date());

                await interaction.update({
                    embeds: [embedBuilder],
                    components: [],
                });

                collector.stop(); // İşlem tamamlandığında toplayıcıyı durdur
            }
        });

        collector.on("end", async () => {
            try {
                await sentMessage.edit({ components: [] }); // Süre dolunca butonları kaldır
            } catch {}
        });
    },
};
