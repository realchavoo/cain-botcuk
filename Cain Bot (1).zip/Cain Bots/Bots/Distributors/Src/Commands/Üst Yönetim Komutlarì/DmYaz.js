const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
  conf: {
    aliases: ["Cain","dmyaz"], 
    name: "Cain",
    help: ".dmyaz Butona Tıkla Ve Id Gir Sonra Metini Gir",
    owner: true,
    category: "styonetim",
  },

  Cyrstal: async (client, message, args) => {
    // Embed ve buton oluşturma
    const embed = new EmbedBuilder()
      .setTitle("DM Gönder")
      .setDescription("Butona basarak bir kullanıcıya özel DM gönderebilirsiniz.")
      
    const button = new ButtonBuilder()
      .setCustomId("open_modal")
      .setLabel("DM Gönder")
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(button);

    await message.channel.send({ embeds: [embed], components: [row] });

    // Buton interaction listener
    const filter = (interaction) => interaction.customId === "open_modal" && interaction.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on("collect", async (interaction) => {
      // Modal oluşturma
      const modal = new ModalBuilder()
        .setCustomId("send_dm")
        .setTitle("DM Gönder")
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("user_id")
              .setLabel("Kullanıcı ID")
              .setStyle(TextInputStyle.Short)
              .setPlaceholder("Göndermek istediğiniz kullanıcının ID'si")
              .setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId("message_content")
              .setLabel("Mesaj")
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder("Göndermek istediğiniz mesajı yazın")
              .setRequired(true)
          )
        );

      await interaction.showModal(modal);
    });

    // Modal submit listener
    client.on("interactionCreate", async (interaction) => {
      if (!interaction.isModalSubmit() || interaction.customId !== "send_dm") return;

      const userId = interaction.fields.getTextInputValue("user_id");
      const messageContent = interaction.fields.getTextInputValue("message_content");

      try {
        const user = await client.users.fetch(userId);
        await user.send(messageContent);

        await interaction.reply({ content: "Mesaj başarıyla gönderildi!", ephemeral: true });
      } catch (error) {
        console.error(error);
        await interaction.reply({ content: "Mesaj gönderilirken bir hata oluştu. Lütfen ID'nin doğru olduğundan emin olun.", ephemeral: true });
      }
    });
  },
};
