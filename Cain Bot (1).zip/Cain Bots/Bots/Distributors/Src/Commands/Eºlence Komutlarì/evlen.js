const Discord = require('discord.js');
const emojis = require('../../../../../Src/Settings/emojiName.json');
const Marry = require('../../../../../Src/Schemas/Marriage');
module.exports = {
conf: {
aliases: ["evlen", "evlilik", "evlilik-teklif-et"],
name: "evlen",
help: "evlen @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Kendinle Evlenemezsin!"}).sil(15)
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Benimle Evlenemezsin!"}).sil(15)
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Botlarla Evlenemezsin!"}).sil(15)
}
const data = await Marry.findOne({guildID: message.guild.id, userID: message.author.id});
if(data && data.friendsID) return message.reply({content: `${message.member} Zaten ${message.guild.members.cache.get(data.friendsID) ? message.guild.members.cache.get(data.friendsID) : "Bir Kullanıcı"} İle Evlisin.`}).sil(15)
const data2 = await Marry.findOne({guildID: message.guild.id, userID: member.user.id});
if(data2 && data2.friendsID && data2.friendsID != message.author.id) return message.reply({content: `${message.member} Etiketlediğin Kişi Zaten ${message.guild.members.cache.get(data2.friendsID) ? message.guild.members.cache.get(data2.friendsID) : "Bir Kullanıcı"} İle Evli.`}).sil(15)
if(data2 && data2.friendsID === message.author.id) return message.reply({content: ("Etiketlediğin Kişiyle Zaten Evlisin!")}).sil(15)
if(!member.user.bot) {
let yüzük = ["Tek Taş Yüzük", "Elmas Yüzük", "Altın Yüzük", "Gümüş Yüzük", "Bronz Yüzük"];
let yüzükler = yüzük[Math.floor(Math.random() * yüzük.length)];
const yüzüks = yüzükler;
const row = new Discord.ActionRowBuilder().addComponents(
new Discord.ButtonBuilder().setStyle(Discord.ButtonStyle.Success).setLabel("Kabul Et").setCustomId("evet"),
new Discord.ButtonBuilder().setStyle(Discord.ButtonStyle.Danger).setLabel("Reddet").setCustomId("hayir")
);
embed.setDescription(`💍 ${member}, ${message.author} Sana Evlenme Teklif Etti! Kabul Eder Misin?`)
embed.setImage("https://cdn.discordapp.com/attachments/1218642925609685083/1220852469794603128/Bh187SpongebobGIF.gif?ex=66107277&is=65fdfd77&hm=21a7057dcffde6bbd60d25044cb03dad5f057615ff2731e3f5605e9647fb3021&")
const msg = await message.reply({embeds: [embed], content: (`${member}`), components: [row]})
const filter = (button) => button.user.id === member.user.id;
const collector = msg.createMessageComponentCollector({filter, time: 60000});
collector.on("collect", async (button) => {
if(button.customId === "evet") {
await Marry.findOneAndUpdate({guildID: message.guild.id, userID: message.author.id}, {$set: {friendsID: member.id, yüzük: yüzüks, Date: Date.now()}, }, {upsert: true});
await Marry.findOneAndUpdate({guildID: message.guild.id, userID: member.id}, {$set: {friendsID: message.author.id, yüzük: yüzüks, Date: Date.now()}, }, {upsert: true});
button.reply({content: ("Evet Dediğin İçin Tebrikler! Artık Evli Oldunuz!"), ephemeral: true})
msg.edit({embeds: [embed.setDescription(`💍 ${member}, ${message.author} Evlenerek Mutlu Bir Hayata Adım Attılar, **${yüzüks}** Taktı Sana!`).setImage("https://cdn.discordapp.com/attachments/1218642925609685083/1220852574618390548/PrincessCarryHappilyGIF.gif?ex=66107290&is=65fdfd90&hm=bea5454619a55ac4643b3fb4792b6e1b11d5fc30fa71e0e7e453f8107abaeccf&")], components: []})
} else if(button.customId === "hayir") {
button.reply({content: ("Hayır Dediğin İçin Üzgünüm! Teklifi Reddettiniz!"), ephemeral: true})
msg.edit({embeds: [embed.setDescription(`🥹 ${member}, ${message.author} Evlenme Teklifini Reddetti!`).setImage("https://cdn.discordapp.com/attachments/1218642925609685083/1220853020330430615/MonkeySadMonkeyGIF.gif?ex=661072fa&is=65fdfdfa&hm=2f74fc0a1312223e249a13f5aa78655ea76303f0045c51204a57d6bad1d70100&")], components: []})
}
});
}
}
}