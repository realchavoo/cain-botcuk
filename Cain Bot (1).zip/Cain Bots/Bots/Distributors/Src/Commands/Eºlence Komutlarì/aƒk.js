const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["aşk", "aşk-ölçer", "aşk-ölç", "aşkölçer", "aşkölç", "aşkölcer", "ask", "ask-olcer", "ask-olc", "askolcer"],
name: "aşk-ölç",
help: "aşk-ölç @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Kendine Aşk Ölçemezsin!"}).sil(15)
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Bana Aşk Ölçemezsin!"}).sil(15)
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Botlara Aşk Ölçemezsin!"}).sil(15)
}
var gifler = ['12', '0', '0', '100', '4', '0', '17', '24', '1', '27', '100', '29', '40', '37', '54', '67', '100', '78', '74', '100', '84', '81', '94', '93', '99', '100'];
let resimler = gifler[Math.floor(Math.random() * gifler.length)];
embed.setDescription(`>>> :cloud: *${message.author}, ${message.mentions.members.first()} \n:heart_decoration: İle Aranda \` %${resimler} \` Aşk Var* 🥰`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
embed.setImage("https://media.discordapp.net/attachments/949237232064135238/973270294284369960/tumblr_nlasaq2IJP1sb6gt5o1_500.gif")
await message.reply({content: `${member}, ${message.author} Adlı Kullanıcı Sana Aşk Ölçtü!`, embeds: [embed]})
}
}