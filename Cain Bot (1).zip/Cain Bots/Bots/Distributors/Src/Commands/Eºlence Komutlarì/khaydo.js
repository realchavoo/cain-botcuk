const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["khaydo"],
name: "khaydo",
help: "khaydo @Cain/ID",
category: "eglence"
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
let kapak = [
"hadi bas bana bas +basacaam dıbına basacam -yukarı çık yukarı +yukarda da basarııımm.",
"Vay şibabam neytmisler sana yavv.",
"istikbal yaylı yataklarında gibiş keyfi inanılmaz.",
"Git bana dübür içi burma yap -Ne dübürü ne içi amina goyim ne dedi lan bu şimdi.",
"Ay bizi giben yok muuuu -U eh u Kaaarrrrrıııı + ula ha bu motori da bozmusuk daa - motorunu gibem seniiiggggn.",
"Biliyimisin ula oynamayı -Anasını bile giberim, Kes! -Öyle mi kesilir amina koydugum.",
"sen kendini kerpeten amcklu hamdiyemi zannettin lan.",
"dükkan, dürbün, dü dübür.",
"yav arkadaş daha önce böyle yemek duyduysam anamı siksinler.",
"Lan bu gırtlağını gibtiklerim düğüne gidiyor lan kızıl kafalar.",
"Yürüyün la dıbına koyduklarim şunu delelim dmini gibtimini.",
"Şehmistat del lan şu kapıyı o dmini gibtiğim içerde.",
"askerler bırakın oynamayı elliyi aha duruyor orda tavşanın deliği.",
"Amucamin Amuha Goyim.",
"Aha o holywooddan ciktim ben -holywoodun dmina koyam salavat getir dmina koydugum vuracam seni.",
"Tak tak tak. Çıh lan dışarığğ. -Şlaaaak - Vay ben senin gotünü gibem çıhsana lan dışarıya.",
"lan amına kodumunun bana niye ateş ediyosun ağzına bokumu koycam senin.",
"haydi oğlum şemistan, fırlat beni yarrah gibi uzayim oraya.",
"davşan gardeş sana kanım çok ısındı bi yol öpebilirmiyim-bana daha çok anamu sevdun gibime geldi.",
"tavşan kardeş 2 tane yumurta kırdım kahvaltı hazır -zaaarrrtttttt +hööööö cık la dısarı aq çocuğu öldüm ya.",
"Karabiberim Vur Kadehlere + Skrm Senin Karabiberini."
]
embed.setDescription(`*${kapak[Math.floor(Math.random() * kapak.length)]}*`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
message.reply({embeds: [embed], content: (`${message.mentions.members.first()}`)});
}
}