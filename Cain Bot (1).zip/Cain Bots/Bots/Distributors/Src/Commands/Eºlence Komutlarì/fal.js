const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["fal"],
name: "fal",
help: "fal",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
var gifler = [
'Hayatında hiç evlenmiceksin, Evliliğe karşı çıkacaksın',
'Çok göz var sende, ay çok nazar',
'son zamanlarda için kabarmış senin',
'çok düşünüyorsun',
'görüyorum, hem de çok iyi görüyorum şükürler olsun Allah’ım bana bunları gösterdiğin için. Havuç ye göze çok iyi geliyor',
'rende birisi var, sana dolanıp durur, üç vakte kadar gelip seni babandan isteyecek, çok mutlu olacaksınız, üç çocuğunuz olacak',
'atya fallarının her zaman tek bir sonucu vardır; elinize bakarsanız ve size kalan tek şeyin bir sap olduğunu görürsünüz',
'kısa bir süre içinde beklediğin bir yerden iyi bir haber alacaksın',
'ışın mı desem, esmer mi desem, kumrala da benziyor, yok yok demeyim en iyisi',
'Eski şeylerin artık sona erdiği bir zamandasın',
'Aklınızda sizi meşgul bir iş pozitif sonuç verecek',
'Hiç beklemediğiniz bir paraya kısa sürede kavuşacaksınız',
'Uzun vadeli ve mutlu bir yaşam sizi bekliyor',
'Çevrenizde sizi kandırmak isteyenler var',
'Bu günlerde yaptığınız iş neticesinde size mutluluk getirecek',
'Bu günlerde bazı karışık işlere gireceksiniz, dikkatli olun',
'Sevindirici, pozitif haberler alacaksınız',
'Birileri sizi kandırmaya çalışıyor, son derece dikkatli olun',
'Harcamalarınıza dikkat etmelisiniz, para kaybı olabilir',
'Büyük bir aşka tutulacaksınız, sakın ola ki onu kaybetmeyin',
'Sevdiğiniz kişi ile aranız açılacaktır, ancak onu yeniden kazanın',
'Dertleriniz sona erecek, huzurlu ve pozitif günler sizi bekliyor',
'Dua ve dilekleriniz en sonunda artık kabul olacak',
'Çevrenizde sizi seven insanlar var, onları kırmayın',
'Üzüntü, dert ve kederden artık kurtuluyorsunuz',
'Beklediğiniz maddi imkanlar nihayet önünüze açılıyor',
'Sizi üzen bir sorunlardan uzaklaşarak ancak rahatlayacaksınız',
'Üzüntü duyacağınız negatif bir haber alacaksınız',
'Sıkıntılı bir zamanınızda yakınlarınız yardımınıza koşacak',
'Bekar iseniz zengin bir evlilik yapacak, evli iseniz yeni bir ev, mal, zenginliğe kavuşacaksınız',
'Hayırlı bir olay yada verimli bir iş sizi bekliyor',
'Çok sevdiğiniz birisinden kısa süreli bir ayrılık yaşayabilirsiniz',
'Yeni dostluk başlangıcı, uzun süredir göremediğiniz bir dosttan haber alacaksınız',
'İşlerinizi çok fazla ihmal ettiniz, artık toparlanmalısınız',
'Yakında bir iyilikle karşılaşacaksınız, nihayet beklediğinize ulaşacaksınız',
'Negatif olan alışkanlıklardan, dostlardan uzaklaşmanız gerekiyor',
'Yüksek kariyer sahibi birisinden negatif bir olay göreceksiniz',
'Çok zor durumda olan bir kişiye yardım edeceksiniz',
'Kimi kararları iyice düşündükten sonra almalısınız',
'Ay bakamam ben bu fala',
'Bak bak, tam şurada. Ay nasıl görmüyorsun canım, tırnağımın uç tarafına doğru bak',
'Çok göz var sende, ay çok nazar',
'Düğün gibi bir şey görüyorum, kalabalıklara karışıyorsun'
];
let resimler = gifler[Math.floor(Math.random() * gifler.length)];
embed.setTitle(`${message.member.user.username} Bahtına bakalım 🤓`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(message.member.displayAvatarURL({dynamic: true}))
embed.setDescription(`*${resimler}.*`)
message.reply({embeds: [embed]});
}
}