const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["lafat"],
name: "lafat",
help: "lafat @Cain/ID",
category: "eglence"
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
let kapak = [
"Yalanım yok ki benim, aklımdasın hala. Ne yapayım güzelim gereksiz şeyleri kafa hep takıyorum.",
"A101'de satılan 25 kuruşluk çikolatanın tadını bile veremeyen insanlar var. Öyle gereksizler.",
"Bazı insanların da aynı televizyon gibi tepesine vurulduğunda düzelmesi en büyük temennimdir.",
"Kimine göre kral, kimine göre yalanım... Unutmayın beyler adamına göre adamım.",
"Bazı kişiler dümen çevirmek olunca kaptan olmak için sıraya giriyor.",
"Içinden geldiği için bizimle olanları, işinden geldiği için bizimle olanlara değiştik. Yanlış ettik.",
"Canımı yakacak kadar güçlü olanın sonuçlarına katlanacak kadar gücü olmalı.",
"Eğer ben güneş isem sen aysın. Benim doğduğum yerde sen batarsın.",
"Bana laf cambazlığı yapma kızım, bir laf sokarım kürtajla bile aldıramazsın.",
"Terk etmek kolaysa senin için, el sallamakta hiç zor olmaz benim için.",
"Insanlığa davet etsek yol tarifi isteyecek insanlar var.",
"Senin etiketinin olduğu yer fiyatı ben koyarım.",
"Arada makyaj malzemelerini de ye ki, biraz da için güzelleşsin",
"Balonlar, içi boş şeylerin de bazen yükselebileceğini hatırlatır.",
"Bazı insanları sarımsaklasak da mı saklasak, yoksa boğup da rahatlasak mı?.",
"Laf sokma, kapak olursun. Yalvarma, köpek olursun. Delikanlı ol, belki yanımda yer bulursun.",
"Laf Sokarim Derinden Gotun Oynar Yerinden.",
"Her gün resmine bakmadan duramıyorum. –İlla TÜKÜRECEĞİM.",
"Kapak Olana Kapak Laf Sokamam :(",
"Top Topu Çeker Dediğinde İnanmamıştım .. Doğruymuş Ama.",
"Laf dedi oldu kapak, söz söyledi oldu tencereye kapak.",
"Çok talibim var diyenler; Sevinmeyin! Ucuz malın alıcısı çoktur.",
"Etme sırtını duvardan başkasına emanet. En kralının bile içinde vardır bir nebze ihanet.",
"İnsanlar da fotoğraf gibi; ne kadar büyütürsen, o  düşüyor kalitesi.",
"Sana biraz adam ol diyeceğim seni de zor durumda bırakmak istemiyorum.",
"Uzak dur çek elini benden, senin gibi seviyesizleri çok geride bıraktım ben.",
"Bana şiir yaz diyorsun hoş güzel de, peki sen kaç harf edersin.",
"2 dakika adam ol desem kaç dakikam kaldı diye soracak insansın.",
"Laf sokarım derinden aklın oynar yerinden.",
"Ben sana ilaç olurum da, sen benim yan etkilerime dayanamazsın.",
"Karabiber Ayran Koyumda Yaylan.",
"Senden Bir Kaşık Cacık Bile Olmazki Adam Olucaksın.",
"Sana Laf Sokmucam Şanslısın :)",
"Senin zirven benim zeminim.",
"Sen vurursun bela okurlar. Biz vururuz sala okurlar.",
"Sen Vurursun Dikiş Atarlar Ben Vururum Toprak Atarlar.",
"Yaklaşma toz olursun geçme pişman olursun.",
"Yapında bozukluk varsa benden mimarlık bekleme",
"Uzaktan kusursuz, yakından lüzumsuz insanlar tanıdım.",
"Senin artistlik yaptığın yerde bana yönetmenlik düşer.",
"bir şey bilmene gerek yok haddini bil yeter.",
"Bugün laf koymayacağım. Çay koydum; gel, iç, insanlık gör.",
"Beni eleştireceğine, git beynini geliştir.",
"Tipinizin gideri var ama karakterinizin ederi yok.",
"Erkek özlediğini söylemez! Oturur bir sigara daha yakar.",
"Matematikte bir konu olsan “Boş Küme” olursun. Havan kime.",
"52 ekran televizyon kadar kafan var ama küçük düğmesi kadar beynin yok.",
"Konu adamlığa geldi, sen git istersen.",
"Aklını alırdım ama ucuz mal bende alerji yapıyor.",
"Dur! Beynimi çıkarayım da eşit şartlarda konuşalım.",
"Canım, karakterin yere düşmüş.",
"Senin gibiler su ihtiyacını ancak tükürdüğünü yalayarak karşılıyor. Ne yaparsın işte.",
"Bugün laf koymayacam. Çay koydum; gel, iç, insanlık gör.",
"Tipi Tarlabaşı ama egosu sanırsın Nişantaşı.",
"Ben sana inandığım için BİR GÜN kaybederim ama sen bu karaktersizliğinle bir ömür kaybedersin.",
"Hesabını veremeyeceğin işlere kalkışma! Öbür tarafta bulaşık yıkatmıyorlar.",
"Hesabı olanlar sanmasın kapandı defterler. Tek tek yazıyorum her birini bir kenara. iyi kötü, bir gün ödenecek bedeller.",
"Tahammülü kalmamış birine hata.",
"Sahipsiz kalıp tutuşunca etekler, sahibine döner tüm köpekler.",
"Seni tanıyamıyorum artık. Künefe gibi için kaşar dışın ise çok tatlı."
]
embed.setDescription(`*${kapak[Math.floor(Math.random() * kapak.length)]}*`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
message.reply({embeds: [embed], content: (`${member}`)});
}
}