const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["tokat"],
name: "tokat",
help: "tokat @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Kendine Tokat Atamazsın!"}).sil(15)
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Bana Tokat Atamazsın!"}).sil(15)
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Botlara Tokat Atamazsın!"}).sil(15)
}
const gif = [
"https://cdn.discordapp.com/attachments/767247105172439042/767262725105254400/giphy.gif",
"https://cdn.discordapp.com/attachments/767247105172439042/767262735838216232/bf4ac591346c0e44d88beff1c8525a9e.gif",
"https://cdn.discordapp.com/attachments/767247105172439042/767262731556225034/HkA6mJFP-.gif",
"https://cdn.discordapp.com/attachments/767247105172439042/767262733212450846/HyPjmytDW.gif",
"https://cdn.weeb.sh/images/HJcoQ1Fwb.gif",
"https://cdn.weeb.sh/images/Hk6JVkFPb.gif",
"https://cdn.weeb.sh/images/SkSCyl5yz.gif",
"https://cdn.weeb.sh/images/rknn7Jtv-.gif",
"https://images-ext-2.discordapp.net/external/VT5Wb1dtOIrEa9CRpVB2hmYxFBBLnxzFWMtDJqwpFF4/https/cdn.weeb.sh/images/rJgTQ1tvb.gif",
"https://images-ext-1.discordapp.net/external/byPQO7FP2zpjV-LJpopq8zShVRLjK3_giKzv224nBcI/https/cdn.weeb.sh/images/rkaqm1twZ.gif",
"https://images-ext-2.discordapp.net/external/fidBWA0FTxe_HpmG0P5HFA4Kj6rWUEq6M9jp31ruvY0/https/cdn.weeb.sh/images/SJL3Q1Fvb.gif",
"https://images-ext-2.discordapp.net/external/xdNGuZzdnzDvLnp3xLYx1wAXpz67yHwklt7yV1KJAAk/https/cdn.weeb.sh/images/B1jk41KD-.gif",
"https://images-ext-1.discordapp.net/external/EqImXZ-Xb7G4GhhNqWHm8Lml1QJCp0cc-sSAMRSup5E/https/cdn.weeb.sh/images/B156XkFP-.gif",
"https://images-ext-2.discordapp.net/external/O_4TE883f7rySd5tYIZ2ZT76mu-W_XHafFWJJ4bYrHs/https/cdn.weeb.sh/images/SkNimyKvZ.gif",
"https://images-ext-1.discordapp.net/external/WI4hV1-0IW3KPzQzEmuhnbRRKRi03oYvMsPbflZHlBM/https/cdn.weeb.sh/images/Bkj-oaV0Z.gif",
"https://images-ext-1.discordapp.net/external/N62oAmXji3QUs5pgtMeXY-EAJxyqrNebCbq_pTrmBME/https/cdn.weeb.sh/images/SJ-CQytvW.gif",
"https://images-ext-1.discordapp.net/external/k7dhMk6Zb21vVcUOmpTgzvvL6cCrMkKCfM7Xxb-qhcw/https/cdn.weeb.sh/images/By2iXyFw-.gif",
"https://images-ext-1.discordapp.net/external/jL1iF6VeVHRUADsRlVUEVvu0gFnOonn4wMesV-loYtM/https/cdn.weeb.sh/images/BkxEo7ytDb.gif",
"https://images-ext-1.discordapp.net/external/VUdQTn8cYzOwlb2SYfmJA7QU_MLuq0Z8VntC8K0HGGM/https/cdn.weeb.sh/images/BJSpWec1M.gif",
"https://images-ext-1.discordapp.net/external/Z-nvbcSDKstH-Y99F8U1WhUZq1cjD5ovV2BWEs27-Z4/https/cdn.weeb.sh/images/r1siXJKw-.gif",
"https://images-ext-2.discordapp.net/external/4_nMMRGuUYD88fenXzzw0R1d6v1qhmgrQtiyCSbEb4c/https/cdn.weeb.sh/images/SkxGcmJKPb.gif",
"https://images-ext-1.discordapp.net/external/PTu9TahlTEaW9ppqMriRgas0bC6zVSIrkIteZy9X13w/https/cdn.weeb.sh/images/HkJ6-e91z.gif",
"https://images-ext-2.discordapp.net/external/ZWMYp1a93sk1WIKvvWNx7MYKrYl4yV9xlYYDDIPS78E/https/cdn.weeb.sh/images/rJYqQyKv-.gif",
"https://images-ext-1.discordapp.net/external/hHSiItwzffiKIJrZrKORpzmxoi0R6wzDRx59f6tx_Y4/https/cdn.weeb.sh/images/HkskD56OG.gif",
"https://images-ext-1.discordapp.net/external/RkuVbGqqfdQnvvz5G6kccEkN3qQkWStkPDU8ghc1GL8/https/cdn.weeb.sh/images/H16aQJFvb.gif",
"https://images-ext-1.discordapp.net/external/pG43ZUsVfKWvzXpKn3SLz9nzSMMpWGScnoeAUgtihW0/https/cdn.weeb.sh/images/ByTR7kFwW.gif",
"https://images-ext-1.discordapp.net/external/LU1gZ4OUDdBY2MeuQt_FgGDPZJkfoMX23UHpAJt-v0o/https/cdn.weeb.sh/images/r1VF-lcyz.gif",
"https://images-ext-2.discordapp.net/external/sZZBSC9KfJU_--hWJ5h2G6aqItuji07Ncjfq8QquJ-A/https/cdn.weeb.sh/images/BkzyEktv-.gif",
"https://images-ext-1.discordapp.net/external/NyI8ezfHfCza2N2zmt1AwLIFM_BuUD2x05YxYJDT8yc/https/cdn.weeb.sh/images/r1PXzRYtZ.gif",
"https://images-ext-2.discordapp.net/external/P9b6VaURdUtaTk9k1nsT79X_TZ48PSNU9dffRe0cRog/https/cdn.weeb.sh/images/ry2tWxcyf.gif",
"https://images-ext-2.discordapp.net/external/Mjh-SesBluNQ_SohJpk_30ac6GgDvaQ4Mx3-kbBH1vs/https/cdn.weeb.sh/images/SJdXoVguf.gif"
]
let resimler = gif[Math.floor(Math.random() * gif.length)];
await message.react(message.guild.emojiGöster(emojis.yes))
return message.reply({content: `${member}, ${message.author} Adlı Kullanıcı Sana Tokat Attı!`, files: [resimler]})
}
}