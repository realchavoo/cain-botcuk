const Discord = require('discord.js');
const Tweet = require("../../../../../Src/Plugins/Tweet")
const emojis = require("../../../../../Src/Settings/emojiName.json")
const tweetDB = require("../../../../../Src/Schemas/TweetDB")
module.exports = {
conf: {
name: "tweet",
aliases: ["tweet"],
help: "tweet Text",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args) => {
let kanallar = ["tweet", "tweet-chat"]
if (!kanallar.some((x) => message.channel.name.toLowerCase().includes(x))) {
await message.react(message.guild.emojiGöster(emojis.no))
let kanalListesi = [...new Set(kanallar.map(x => message.guild.channels.cache.find(chan => chan.name.toLowerCase().includes(x))))];
return message.reply({content: `${message.guild.emojiGöster(emojis.no)} ${kanalListesi.map(kanal => kanal.toString()).join(', ')} Kanallarında Kullanabilirsin.`}).sil(15)
}
const text = args.join(" ");
if (!text) return message.reply({ content: "Bir Tweet Metni Belirtmelisin!"}).sil(15);
const tweet = new Tweet()
.setTheme("light")
.setUser({displayName: message.author.displayName, username: message.author.username})
.setVerified(true)
.setAvatar(message.author.displayAvatarURL({ dynamic: true, size: 1024 }))
.setComment(""+text+"");
const image = await tweet.build();
const row = new Discord.ActionRowBuilder()
.addComponents(
new Discord.ButtonBuilder()
.setLabel("Like")
.setCustomId("like")
.setEmoji("1235161731819376780")
.setStyle(Discord.ButtonStyle.Secondary),
new Discord.ButtonBuilder()
.setLabel("Dislike")
.setCustomId("dislike")
.setEmoji("1258781397892468796")
.setStyle(Discord.ButtonStyle.Secondary),
new Discord.ButtonBuilder()
.setLabel("Retweet")
.setCustomId("retweet")
.setEmoji("1258781590025273404")
.setStyle(Discord.ButtonStyle.Secondary)
);
await message.delete().catch(() => {});
const msg = await message.channel.send({ files: [{ attachment: image, name: "tweet.png" }], components: [row] });
await tweetDB.updateOne({ guildID: message.guild.id, userID: message.author.id }, { messageID: msg.id, Clicking: [], Retweet: [], Likes: 0, Dislikes: 0 }, { upsert: true })
const collector = msg.createMessageComponentCollector({});
collector.on("collect", async (i) => {
if (i.customId === "like") {
const data = await tweetDB.findOne({ guildID: message.guild.id, userID: message.author.id, messageID: msg.id })
if(data && data.Clicking.includes(i.user.id)) return i.reply({ content: "Bu Tweeti Zaten Beğenmişsin.", ephemeral: true })
const like = data ? data.Likes : 0
const dislike = data ? data.Dislikes : 0
await i.reply({ content: "Tweeti Beğendin!", ephemeral: true })
row.components[0].setLabel(`Like: ${like + 1}`)
row.components[1].setLabel(`Dislike: ${dislike}`)
await msg.edit({ files: [{ attachment: image, name: "tweet.png" }], components: [row] });
await tweetDB.updateOne({ guildID: message.guild.id, userID: message.author.id, messageID: msg.id }, { $push: { Clicking: i.user.id }, $set: { Likes: like + 1 } }, { upsert: true })
}
if (i.customId === "dislike") {
const data = await tweetDB.findOne({ guildID: message.guild.id, userID: message.author.id, messageID: msg.id })
if(data && data.Clicking.includes(i.user.id)) return i.reply({ content: "Bu Tweeti Zaten Beğenmemişsin.", ephemeral: true })
const like = data ? data.Likes : 0
const dislike = data ? data.Dislikes : 0
await i.reply({ content: "Tweeti Beğenmedin!", ephemeral: true })
row.components[0].setLabel(`Like: ${like}`)
row.components[1].setLabel(`Dislike: ${dislike + 1}`)
await msg.edit({ files: [{ attachment: image, name: "tweet.png" }], components: [row] });
await tweetDB.updateOne({ guildID: message.guild.id, userID: message.author.id, messageID: msg.id }, { $push: { Clicking: i.user.id }, $set: { Dislikes: dislike + 1 } }, { upsert: true })
}
if (i.customId === "retweet") {
const Modal = new Discord.ModalBuilder()
.setTitle("Tweet Retweet")
.setCustomId('retweets');

const Input = new Discord.TextInputBuilder()
.setCustomId('tweets')
.setLabel('Tweet Metni')
.setPlaceholder('Tweet Metni')
.setRequired(true)
.setMaxLength(200)
.setMinLength(5)
.setStyle(Discord.TextInputStyle.Paragraph);

let tweetRow = new Discord.ActionRowBuilder().addComponents(Input);
Modal.addComponents(tweetRow);

await i.showModal(Modal);

const modal = await i.awaitModalSubmit({ time: 60000 }).catch(() => {});
if (!modal) {
return i.followUp({ content: "Modal zaman aşımına uğradı veya iptal edildi.", ephemeral: true });
}

await modal.deferReply({ ephemeral: true });

const data = await tweetDB.findOne({ guildID: message.guild.id, userID: message.author.id, messageID: msg.id });
if (data && data.Retweet.includes(i.user.id)) {
return modal.followUp({ content: "Bu Tweet Zaten Retweetlendi.", ephemeral: true });
}

const txt = modal.fields.getTextInputValue('tweets');
const tweets = new Tweet()
.setTheme("light")
.setUser({ displayName: i.member.displayName, username: i.user.username })
.setVerified(true)
.setAvatar(i.member.displayAvatarURL({ dynamic: true, size: 1024 }))
.setComment("" + txt + "");

const images = await tweets.build();
const msj = await msg.reply({ files: [{ attachment: images, name: "retweet.png" }] });

await tweetDB.updateOne({ guildID: message.guild.id, userID: i.member.id }, { messageID: msj.id, Clicking: [], Retweet: [], Likes: 0, Dislikes: 0 }, { upsert: true });

await modal.followUp({ content: "Tweet Retweetlendi!", ephemeral: true });
}
})
}
};