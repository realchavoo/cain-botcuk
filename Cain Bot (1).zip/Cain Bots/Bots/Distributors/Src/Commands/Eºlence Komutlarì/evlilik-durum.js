const Discord = require('discord.js');
const emojis = require('../../../../../Src/Settings/emojiName.json');
const Marry = require('../../../../../Src/Schemas/Marriage');
module.exports = {
conf: {
aliases: ["evlilikdurum"],
name: "evlilik-durum",
help: "evlilik-durum @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
const Data = await Marry.findOne({guildID: message.guild.id, userID: member.id})
if(!Data) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `${member} Biriyle Evli Değil.`}).sil(15)
}
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({embeds: [embed.setDescription(`*${message.guild.emojiGöster(emojis.kalp)} ${member} Kullanıcısı Şuan'da ${message.guild.members.cache.get(Data.friendsID) ? message.guild.members.cache.get(Data.friendsID) : `**${await client.fetchUser(Data.userID).username}**`} İle Evli.*

\`Evlilik Tarihi:\` <t:${String(Data.Date).slice(0, 10)}>
\`Yüzük:\` **${Data.yüzük}**`)]})
}
}