const DB = require("../../../../../Src/Schemas/UserEngel")
const Discord = require("discord.js")
const settings = require("../../../../../Src/Settings/Settings.json")
const emojis = require("../../../../../Src/Settings/emojiName.json")
module.exports = {
conf: {
aliases: ["engelle", "engel"],
name: "engelle",
help: "engel ekle/kaldır/liste @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed, prefix) => {
let engelData = await DB.findOne({ guildID: message.guild.id, userID: message.author.id });
if(!engelData) engelData = new DB({ guildID: message.guild.id, userID: message.author.id, veri: [] }).save();
if(!args[0]) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Bir Seçenek Belirtmelisin! (ekle/kaldır/liste)*`)] }).sil(15)
}
if(args[0] === "ekle") {
let member = message.mentions.members.first() || message.guild.members.cache.get(args[1])
if (!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Bir Kullanıcı Belirtmelisin!*`)] }).sil(15)
}
if (member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Kendini Engelleyemezsin!*`)] }).sil(15)
}
if (member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Beni Engelleyemezsin!*`)] }).sil(15)
}
if(!engelData) {
let newData = new DB({
guildID: message.guild.id,
userID: message.author.id,
veri: []
});
newData.save();
}
if(engelData.veri?.includes(member.id)) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Bu Kullanıcı Zaten Engelli!*`)] }).sil(15)
}
await DB.updateOne({ guildID: message.guild.id, userID: message.author.id }, { $push: { veri: member.id } });
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({ embeds: [embed.setDescription(`*${member} Kullanıcısı Başarıyla Engellendi!*`)] })
} else if(args[0] === "kaldır" || args[0] === "sil" || args[0] === "çıkar" && args[0] === "kaldir") {
let member = message.mentions.members.first() || message.guild.members.cache.get(args[1])
if (!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Bir Kullanıcı Belirtmelisin!*`)] }).sil(15)
}
if (member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Kendini Engelleyemezsin!*`)] }).sil(15)
}
if (member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Beni Engelleyemezsin!*`)] }).sil(15)
}
if(engelData) {
if(!engelData.veri?.includes(member.id)) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ embeds: [embed.setDescription(`*Bu Kullanıcı Engelli Değil!*`)] }).sil(15)
}
await DB.updateOne({ guildID: message.guild.id, userID: message.author.id }, { $pull: { veri: member.id } });
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({ embeds: [embed.setDescription(`*${member} Kullanıcısının Engeli Başarıyla Kaldırıldı!*`)] })
} else {
await message.react(message.guild.emojiGöster(emojis.no))
await message.reply({ embeds: [embed.setDescription(`*Bu Kullanıcı Engelli Değil!*`)] }).sil(15)
}
} else if(args[0] === "liste") {
if(engelData) {
let mapped = engelData.veri.map((x, index) => `\` ${index+1} \` ${message.guild.members.cache.get(x) ? message.guild.members.cache.get(x) : client.users.fetch(x).username || x}`).join("\n")
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({ embeds: [embed.setDescription(`
${message.guild.emojiGöster(emojis.warn)} **Merhaba**, ${message.author} *Engelli Kullanıcılarınız Aşağıda Belirtilmiştir;*

${mapped || "Veri Bulunamadı."}`)] })
}
}
}
}