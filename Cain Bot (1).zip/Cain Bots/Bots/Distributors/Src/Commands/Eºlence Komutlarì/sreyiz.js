const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["sreyiz", "sreyis"],
name: "sreyiz",
help: "sreyiz @Cain/ID",
category: "eglence"
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
let kapak = [
"mezardaki etine tenezzül eden böceğin izzeti nefsini gibeyim",
"seni sputnike oturturum uzaya çıkarttıktan sonra ananı dünya manzarasına karşı giberim",
"seni adı duyulmamış, bağrı yanık türkücülere gibtirtirim",
"ananı telefon direğine bağlar paralelden bacını giberim",
"seni hap diye yutar tak diye sıçarım",
"seni getiren leyleklerin yol haritasını gibeyim",
"hay zütünü moğol ordusuna teslim edip eti sizin kemiği benim dediğiminin evladı ya",
"ebeni havaya atayım inişine mala vurayım",
"seni bir giberim, şeytan bile besmele çeker",
"seni handikaplı gibsinler huur çocugu",
"eşşeğin ağzına çiklet verde seni giberken anırıp ses yapmasın",
"battal gazinin torunu vanku gibi gideceksin hakkuvat yapacaksın dıbınakodumun oğluna",
"eşhedü en lâ ilâhe illallah, islama dön putperest pekekent, ineklerden fayda yok",
"dıbına koduğumunun hakan balamir'i, bu nasıl tip lan?",
"belediyeye rüşvet verip evini yıktırıcam huur çocuğu",
"korka korka cennete gideceğine osura osura cehenneme git bin"
]
embed.setDescription(`*${kapak[Math.floor(Math.random() * kapak.length)]}*.`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
message.reply({embeds: [embed], content: (`${member}`)});
}
}