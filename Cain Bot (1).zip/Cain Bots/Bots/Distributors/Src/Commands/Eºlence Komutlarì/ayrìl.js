const Discord = require('discord.js');
const emojis = require('../../../../../Src/Settings/emojiName.json');
const Marry = require('../../../../../Src/Schemas/Marriage');
module.exports = {
conf: {
aliases: ["ayrıl", "ayril", "boşan"],
name: "boşan",
help: "boşan @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Kendinle Boşanamazsın!"}).sil(15)
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Benimle Boşanamazsın!"}).sil(15)
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Botlarla Boşanamazsın!"}).sil(15)
}
const data = await Marry.findOne({guildID: message.guild.id, userID: message.author.id});
if(!data) return message.reply({content: ("Zaten Bir Evliliğin Yok!")}).sil(15)
const data2 = await Marry.findOne({guildID: message.guild.id, userID: member.user.id});
if(!data2) return message.reply({content: ("Etiketlediğin Kişinin Zaten Bir Evliliği Yok!")}).sil(15)
if(data.friendsID !== member.user.id) return message.reply({content: ("Etiketlediğin Kişiyle Evli Değilsin!")}).sil(15)
if(data2.friendsID !== message.author.id) return message.reply({content: ("Etiketlediğin Kişiyle Evli Değilsin!")}).sil(15)
if(!message.guild.members.cache.get(member.user.id)) Marry.updateOne({guildID: message.guild.id, userID: message.author.id}, {$pull: {friendsID: member.user.id}}).exec();
const row = new Discord.ActionRowBuilder().addComponents(
new Discord.ButtonBuilder().setStyle(Discord.ButtonStyle.Success).setLabel("Kabul Et").setCustomId("evet"),
new Discord.ButtonBuilder().setStyle(Discord.ButtonStyle.Danger).setLabel("Reddet").setCustomId("hayir")
);
embed.setDescription(`💔 ${member}, ${message.author} Sana Boşanma Teklif Etti! Kabul Eder Misin?`)
embed.setImage("https://cdn.discordapp.com/attachments/1218642925609685083/1220854039919460372/LettingGoClarenceGIF.gif?ex=661073ed&is=65fdfeed&hm=68de3cb0a24911e4af5d5218337367a58798f0f3bf3d0632714fd6675baaefd4&")
const msg = await message.reply({embeds: [embed], content: (`${member}`), components: [row]})
const filter = (button) => button.user.id === member.user.id;
const collector = msg.createMessageComponentCollector({filter, time: 60000});
collector.on("collect", async (button) => {
if(button.customId === "evet") {
await Marry.findOneAndDelete({guildID: message.guild.id, userID: message.author.id});
await Marry.findOneAndDelete({guildID: message.guild.id, userID: member.user.id});
button.reply({content: ("Evet Dediği İçin Tebrikler! Artık Boşandınız!"), ephemeral: true})
msg.edit({embeds: [embed.setDescription(`💔 ${member}, ${message.author} Boşanarak Mutlu Bir Hayata Adım Attılar!`).setImage("https://cdn.discordapp.com/attachments/1218642925609685083/1220854890096623717/HugSadGIF_2.gif?ex=661074b8&is=65fdffb8&hm=9ce3e1536a213360c5080189c9a323fa810a76cd4d71290cfe91920e1896cf19&")], components: []})
} else if(button.customId === "hayir") {
button.reply({content: ("Hayır Dediği İçin Üzgünüm! Teklifi Reddettiniz!"), ephemeral: true})
msg.edit({embeds: [embed.setDescription(`🥹 ${member}, ${message.author} Boşanma Teklifini Reddetti!`).setImage("https://cdn.discordapp.com/attachments/1218642925609685083/1220854725784895508/DogGIF_2.gif?ex=66107491&is=65fdff91&hm=3a8642092f7c8cec1f6e2265f72380e2cc01c960cd01b2817fd7af9fa9c9824e&")], components: []})
}
});
}
}