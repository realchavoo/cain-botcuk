const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["yala"],
name: "yala",
help: "yala @Cain/ID",
category: "eglence"
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
var gifler = [
"https://images-ext-2.discordapp.net/external/7Z44TxcqvrQ0MFBN58xgLORs2IFpOlm-SIMwrF0JP2g/https/cdn.weeb.sh/images/rykRHmB6W.gif",
"https://images-ext-2.discordapp.net/external/EVS-yozpRCwqM9JrkkgoTry1IqkDyTJVNjF7ZhIik5U/https/cdn.weeb.sh/images/S1Ill0_vW.gif",
"https://images-ext-2.discordapp.net/external/kfgdvK8A0dborfyqQbX3tNsZ1ON5_1vTc3t_eEs7g3g/https/cdn.weeb.sh/images/HkEqiExdf.gif",
"https://images-ext-1.discordapp.net/external/GP9w453JCQ0V06BTF67fUAQZ216QL7aOuU4MWbi8YMI/https/cdn.weeb.sh/images/rktygCOD-.gif",
"https://images-ext-2.discordapp.net/external/thImffzNHXbD4uB3R-av9x0cvsdmumPWfN8IW7huw1c/https/cdn.weeb.sh/images/Bkagl0uvb.gif",
"https://images-ext-2.discordapp.net/external/1AoFzXaNiKcnBc4OrS3R7jsf9MJEDcikx38nUkbFQW8/https/cdn.weeb.sh/images/HJRRyAuP-.gif",
"https://images-ext-1.discordapp.net/external/r8JiD5lRAfxjdcNRHBqfjJw3dU31fkFGOnIrBwe94Fg/https/cdn.weeb.sh/images/ryGpGsnAZ.gif",
"https://images-ext-2.discordapp.net/external/EWiWNWlRxXpK4c98xW9VxZyh6KfO4DUIFnuOMf7NpCQ/https/cdn.weeb.sh/images/rJ6hrQr6-.gif",
"https://images-ext-2.discordapp.net/external/7Gn2RWDXniNHDEtInim2q5Xm8pXDcVQ54OGTC-rQ7pk/https/cdn.weeb.sh/images/Sk7xeAdwb.gif",
"https://images-ext-1.discordapp.net/external/QAh4YL0JFxeg7wWxw4G3cCucyPRj2fHB3w3zmONGtjg/https/cdn.weeb.sh/images/Bkxge0uPW.gif",
"https://images-ext-2.discordapp.net/external/thImffzNHXbD4uB3R-av9x0cvsdmumPWfN8IW7huw1c/https/cdn.weeb.sh/images/Bkagl0uvb.gif",
"https://images-ext-2.discordapp.net/external/AqmvPrnwsYvvxn5kgJH9Bd-J7mKkl3ka-jpVCwOiMyQ/https/cdn.weeb.sh/images/Sk15iVlOf.gif",
"https://images-ext-2.discordapp.net/external/EVS-yozpRCwqM9JrkkgoTry1IqkDyTJVNjF7ZhIik5U/https/cdn.weeb.sh/images/S1Ill0_vW.gif",
"https://images-ext-2.discordapp.net/external/p9PPETtAMlABYLR7mC1aJZdjjvd0JJ3hx3Wbta1oALY/https/cdn.weeb.sh/images/rkBbBQS6W.gif",
"https://images-ext-2.discordapp.net/external/YveW8Lanx1kD9154i-y3ZalegChtroIEACzKTRsoNnc/https/cdn.weeb.sh/images/H13HS7S6-.gif",
"https://images-ext-2.discordapp.net/external/kfgdvK8A0dborfyqQbX3tNsZ1ON5_1vTc3t_eEs7g3g/https/cdn.weeb.sh/images/HkEqiExdf.gif",
"https://images-ext-2.discordapp.net/external/9xiregisvDewxtEC9iCJPqJWNlrFEn3kcj3YA-ev_Po/https/cdn.weeb.sh/images/H1EJxR_vZ.gif",
"https://images-ext-2.discordapp.net/external/NDTd_FWKJcHbDQ0LeuYWS871_m2pBTOaNWAD8ZX8VBQ/https/cdn.weeb.sh/images/S1QzRJp7z.gif",
"https://images-ext-2.discordapp.net/external/9bHT8aeSTZnMcfTFsR4S_IawF7WOUwK4fKLGhIHVYnw/https/cdn.weeb.sh/images/Syg8gx0OP-.gif",
"https://images-ext-1.discordapp.net/external/GP9w453JCQ0V06BTF67fUAQZ216QL7aOuU4MWbi8YMI/https/cdn.weeb.sh/images/rktygCOD-.gif",
"https://images-ext-2.discordapp.net/external/1AoFzXaNiKcnBc4OrS3R7jsf9MJEDcikx38nUkbFQW8/https/cdn.weeb.sh/images/HJRRyAuP-.gif",
"https://images-ext-1.discordapp.net/external/_QaVvq5ZM5eJ2WvVsd7y24dP3UGU3fHfOdh2YMt6DmI/https/cdn.weeb.sh/images/Hkknfs2Ab.gif",
"https://images-ext-1.discordapp.net/external/FkCpjXWxRoOX04p318pJb2KDyTcgzSk7DsAufy8m9pc/https/cdn.weeb.sh/images/BkvTBQHaZ.gif",
"https://tenor.com/view/ebony-black-kissing-neck-kisses-melanin-gif-17988299"
];
let resimler = gifler[Math.floor(Math.random() * gifler.length)];
embed.setDescription(`>>> ${message.author}, ${member} *Kişisini Yaladı.*`)
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setImage(resimler)
message.reply({embeds: [embed], content: (`${member}`)});
}
}