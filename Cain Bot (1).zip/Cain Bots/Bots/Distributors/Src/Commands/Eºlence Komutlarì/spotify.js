const Discord = require('discord.js');
const Spotify = require("../../../../../Src/Plugins/Spotify")
const emojis = require("../../../../../Src/Settings/emojiName.json")
module.exports = {
conf: {
name: "spotify",
aliases: ["spoti","şarkı","dinlediğim","müzik","spotfy", "spo"],
help: "spotify @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
if (member && member.presence && member.presence.activities && member.presence.activities.some(five => five.name == "Spotify" && five.type == Discord.ActivityType.Listening)) {
let durum = await member.presence.activities.find(five => five.type == Discord.ActivityType.Listening);
await message.react(message.guild.emojiGöster(emojis.yes))
const spotify = await new Spotify()
.setAuthor(durum.state)
.setAlbum(durum.assets.largeText)
.setTimestamp(new Date(Date.now()).getTime() - new Date(durum.timestamps.start).getTime(), new Date(durum.timestamps.end).getTime() - new Date(durum.timestamps.start).getTime())
.setImage(`https://i.scdn.co/image/${durum.assets.largeImage.slice(8)}`)
.setTitle(durum.details)
.build();
return message.reply({content: `${message.guild.emojiGöster(emojis.star)} ${member} Kullanıcısının Dinlediği Şarkı Hakkında Bilgiler Aşağıda Belirtilmiştir.`, files:[{name:"spotify.png",attachment:spotify}]});
} else {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({embeds: [embed.setDescription(`${member} Kullanıcısı Spotify'da Şarkı Dinlemiyor.`)]}).sil(15)
}
}
};