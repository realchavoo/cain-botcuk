const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["serdar"],
name: "serdar",
help: "serdar @Cain/ID",
category: "eglence"
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
let serdar = [
"AAAĞĞAAHAHAAAAA AĞĞĞĞAAAHAHAAAAAA",
"YEEEETTTEEEEEEEEEERRR YYEEETTEEEEEEEEEEERRR",
"SEN sigMiOOOON TECAVÜZ EDiYOOON OOĞLUUUM LAAAAN",
"AAAĞĞĞGGGAAAHAAAAAHAAAA SERDAR YABANCI DEĞiLiM YAAAAAAA AĞĞĞĞAA AAĞĞGĞGĞGGAAA YAAA AHAAAA",
"ÖYLE VURMA ÖYLE VURMAA NE OLURSUN YAAA HAAA HAA",
"AAAAAĞĞĞ AAAAAAAAĞĞĞĞGG",
"HAFiF GÜLÜŞMELER",
"YAA YETER ÇIKAR NE OLURSUN ÇIKAR",
"yiteeeer, yiteeer, yiteeeer diyordu ama serdar hiç dinlemiyordu.",
"AAAĞĞĞGGGAAAHAAAAAHAAAA SERDAR YABANCI DEĞiLiM YAAAAAAA AĞĞĞĞAA AAĞĞGĞGĞGGAAA YAAA AHAAAA",
"YEEEETTTEEEEEEEEEERRR YYEEETTEEEEEEEEEEERRR",
"şaplak sesi"
]
embed.setDescription(`*${serdar[Math.floor(Math.random() * serdar.length)]}*.`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
message.reply({embeds: [embed], content: (`${member}`)});
}
}