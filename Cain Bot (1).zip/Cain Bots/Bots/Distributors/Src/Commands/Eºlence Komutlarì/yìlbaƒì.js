const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
  conf: {
    aliases: ["yilbasi"],
    name: "yilbasi",
    help: "yilbasi",
    category: "eglence",
    owner: true,
  },
  Cyrstal: async (client, message, args) => {
    const embed = new EmbedBuilder()
      .setTitle("🎄 Yılbaşı Teması 🎄")
      .setDescription("Kanallarınıza yılbaşı ağacı eklemek veya kaldırmak için aşağıdaki butonları kullanabilirsiniz.")

    // Butonlar oluştur
    const addButton = new ButtonBuilder()
      .setCustomId("add-tree")
      .setLabel("Yılbaşı Teması Ekle")
      .setStyle(ButtonStyle.Success);

    const removeButton = new ButtonBuilder()
      .setCustomId("remove-tree")
      .setLabel("Yılbaşı Temasını Kaldır")
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(addButton, removeButton);

    // Mesaj gönder
    const messageSent = await message.channel.send({
      embeds: [embed],
      components: [row],
    });

    // Buton etkileşimlerini dinle
    const filter = (interaction) => interaction.isButton() && interaction.user.id === message.author.id;
    const collector = messageSent.createMessageComponentCollector({ filter, time: 60000 }); // 1 dakika süre

    collector.on("collect", async (interaction) => {
      if (interaction.customId === "add-tree") {
        // Kanalların başına yılbaşı ağacı ekle
        message.guild.channels.cache.forEach((channel) => {
          if (!channel.name.startsWith("🎄")) {
            channel.setName(`🎄${channel.name}`).catch(console.error);
          }
        });
        await interaction.reply({ content: "Kanallarınıza yılbaşı ağacı eklendi! 🎄", ephemeral: true });
      } else if (interaction.customId === "remove-tree") {
        // Kanallardan yılbaşı ağacını kaldır
        message.guild.channels.cache.forEach((channel) => {
          if (channel.name.startsWith("🎄")) {
            channel.setName(channel.name.replace(/^🎄/, "")).catch(console.error);
          }
        });
        await interaction.reply({ content: "Kanallarınızdan yılbaşı ağacı kaldırıldı!", ephemeral: true });
      }
    });

    collector.on("end", () => {
      messageSent.edit({ components: [] }); // Süre dolduğunda butonları devre dışı bırak
    });
  },
};
