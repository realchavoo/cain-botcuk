const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["dürt"],
name: "dürt",
help: "dürt @Cain/ID",
category: "eglence",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return
}
embed.setDescription(`*Hey ${member}, ${message.author} Kullanıcısı Sizi Dürttü.*`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
embed.setImage("https://media.discordapp.net/attachments/930066248291741696/930457259618762752/200.gif")
embed.setFooter({text: `${message.member.user.username} Dürttü`, iconURL: message.member.user.avatarURL({dynamic: true})})
message.reply({embeds: [embed], content: (`${member}`)})
}
}