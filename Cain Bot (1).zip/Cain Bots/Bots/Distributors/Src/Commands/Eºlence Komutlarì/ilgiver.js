const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["ilgiver"],
name: "ilgiver",
help: "ilgiver @Cain/ID",
category: "eglence"
},
Cyrstal: async (client, message, args, embed, prefix) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Kendine İlgi Veremezsin!"}).sil(15)
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Bana İlgi Veremezsin!"}).sil(15)
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Botları İlgi Veremezsin!"}).sil(15)
}
let ilgi=[
"Gece nasıl sabahı bekliyorsa aydınlanmak için ben de seni öyle bekliyorum",
"Gülüşünde nice ilaçlar var yarama merhem olan",
"Bir sahil kasabasının huzuru birikmiş yüzüne",
"Sen benim düşlerimin surete bürünmüş halisin",
"Anılarımızın hatırına sevme beni, kalbimin güzelliğini keşfet.",
"Manzara seyretmek için gidilen bir yerde bile senden güzel bir görsel olamaz.",
"Gözlerimi senden alamıyorum, benim tüm dünyam sensin.",
"Senin olduğun yer papatyalarla doludur.",
"Şekere zam gelmiş, ne fark eder ki; sensiz hayatın zaten tadı yok.",
"Lütfen üzerine alın! Kimseyi görmedim ben, senden daha güzel gülen.",
"Aslında dünyanın 7 harikası yok 1 tane harikası var; O da senin kalbin.",
"Aklım mı? O yüzsüz bir misafir, hep sende kalıyor.",
"Ne yaparsan yap, sen her zaman çok doğalsın.",
"Sen, tanıdığım en cesur insansın. Keşke senin gibi olabilseydim.",
"Sen tanıdığım en tatlı insansın.",
"Seninle konuşmak, ferah bir nefes almak gibidir.",
"Bugün harika iş çıkardın. Seninle çalışmayı çok seviyorum.",
"Enerjinin bulaşıcı olduğunu kendi gözlerimle gördüm. Sen mükemmel bir insansın.",
"O kadar nazik ve anlayışlısın ki etrafındaki herkesi daha iyi bir insan yapmayı başarıyorsun.",
"Keşke senin kadar mükemmel bir insan olabilseydim.",
"Yaratıcılığın çok yüksek bir seviyede.",
"İnsanlara güvenmeni seviyorum. Bu anlayışının bir kısmını bana gönderir misin?",
"Ünlü olduğun zaman, hayran kulübünün tek başkanı olmak istiyorum.",
"Çocuklarına çok iyi örnek oluyorsun. Her şeyi doğru yapmana bayılıyorum.",
"Sen yeri doldurulamaz bir insansın.",
"Farkında olduğundan daha harikasın.",
"Senin gibi bir arkadaşımın olması özel hissetmeme neden oluyor.",
"Beni hiçbir zaman hayal kırıklığına uğratmıyorsun. Ne olursa olsun sana güvenebileceğimi biliyorum.",
"Makyaja ihtiyacın yok. Zaten doğal olarak çok güzelsin.",
"Uyurken ne kadar güzel göründüğünü bilsen, kendini izlemek istersin.",
"Harika bir tarzın var. Keşke dolabını birkaç gün kullanabilseydim.",
"Herkesin hayatında olması gereken senin gibi bir arkadaşa ihtiyacı vardır. Sen mükemmel bir insansın.",
"Saçların deniz kızının saçları gibi görünüyor. Çok güzeller.",
"Sen masallardaki prenseslerin gerçek hayat versiyonu olabilirsin.",
"Seni her gördüğümde daha da güzelleşmeyi nasıl başardığına anlam veremiyorum.",
"Bir derginin kapağının en güzel resmi gibisin.",
"İnsanların şarkı yazarken ilham aldığı türden bir insansın.",
"Gülümsemen benim en sevdiğim görüntü olabilir.",
"Sen, her erkeğin sahip olmayı isteyeceği karakterde bir kızsın. Çok özelsin.",
"Gözlerine bakmaktan asla vazgeçmek istemiyorum.",
"Senin yanımda olduğun zaman kendimi çok şanslı hissediyorum.",
"Kötü bir fotoğrafın olamaz; çünkü sen muhteşemsin.",
"Bütün gözlerin sadece senin üzerinde olmasını hak ediyorsun. Çok güzelsin.",
"O kadar tatlı görünüyorsun ki seni hemen yiyebilirim.",
"Keşke bu hayatta senin gibi daha çok insan olsaydı. Hayat, o zaman daha anlamlı olurdu.",
"Milyonda bir gibisin ve iyi ki hayatımdasın.",
"Bu yaşıma kadar gördüğüm en güzel gülümsemeye sahipsin.",
"Her zaman yanımda olmandan gurur duyuyorum.",
"Dünyanın en iyi yemeklerini sadece sen yapıyorsun.",
"Senin gibi bir anneyi herkes hak ediyor. Çok şanslıyım.",
"Senin kadar düşünceli biri ile tanıştığım için çok mutluyum."
]
let ilgis = ilgi[Math.floor(Math.random() * ilgi.length)];
embed.setDescription(`*${ilgis}*.`)
embed.setAuthor({name: message.member.user.username, iconURL: message.member.user.avatarURL({dynamic: true})})
embed.setColor("Random")
embed.setThumbnail(member.displayAvatarURL({dynamic: true}))
embed.setImage("https://media.discordapp.net/attachments/949237232064135238/973270294284369960/tumblr_nlasaq2IJP1sb6gt5o1_500.gif")
message.reply({embeds: [embed], content: (`${member}`)});
}
}