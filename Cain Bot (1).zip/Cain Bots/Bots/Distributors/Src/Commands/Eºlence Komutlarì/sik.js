const emojis = require('../../../../../Src/Settings/emojiName.json');
module.exports = {
conf: {
aliases: ["sik"],
name: "sik",
help: "sik @Cain/ID",
category: "eglence",
developer: true
},
Cyrstal: async (client, message, args, embed) => {
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Lütfen Bir Kullanıcı Belirtin!"}).sil(15)
}
if(member.id === message.author.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Kendini Sikemezsin!"}).sil(15)
}
if(member.id === client.user.id) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Beni Sikemezsin!"}).sil(15)
}
if(member.user.bot) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: "Botları Sikemezsin!"}).sil(15)
}
var gifler = [
"https://i.ibb.co/Qc41SCY/fuck21.gif",
"https://i.ibb.co/Pjw6TM2/fuck20.gif",
"https://i.ibb.co/Y37KSP9/fuck19.gif",
"https://i.ibb.co/VHD6050/fuck18.gif",
"https://i.ibb.co/YL3BmtN/fuck17.gif",
"https://i.ibb.co/t8bLx5s/fuck-5.gif",
"https://i.ibb.co/PChtBmT/fuck-6.gif",
"https://i.ibb.co/5cZNvN7/fuck-7.gif",
"https://i.ibb.co/QQrqkDx/fuck-8.gif",
"https://i.ibb.co/RpxL9mc/fuck-9.gif",
"https://i.ibb.co/RDWHxsk/fuck-10.gif",
"https://i.ibb.co/NKc9hRh/fuck-11.gif",
"https://i.ibb.co/D4ytLNJ/fuck-12.gif",
"https://i.ibb.co/b1bP6FC/fuck-13.gif",
"https://i.ibb.co/Bzjn9KT/fuck-14.gif",
"https://i.ibb.co/FW5s3WZ/fuck-15.gif",
"https://i.ibb.co/H2rbkjn/fuck-16.gif",
"https://i.ibb.co/YL3BmtN/fuck17.gif",
"https://i.ibb.co/VHD6050/fuck18.gif",
"https://i.ibb.co/Y37KSP9/fuck19.gif",
"https://i.ibb.co/Pjw6TM2/fuck20.gif",
"https://i.ibb.co/Qc41SCY/fuck21.gif",
];
let resimler = gifler[Math.floor(Math.random() * gifler.length)];
await message.react(message.guild.emojiGöster(emojis.yes));
await message.reply({
content: `>>> ${message.author}, ${member} *Kişisini Sikti.*`,
files: [{attachment: resimler, name: "SPOILER_sik.gif"}]
});
}
}