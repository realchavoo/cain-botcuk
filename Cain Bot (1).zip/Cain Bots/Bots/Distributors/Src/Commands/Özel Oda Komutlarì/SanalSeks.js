const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');
const mongoose = require('mongoose');
const Room = require('../../../../../Src/Schemas/sanalsekiz'); // Schema ayrı dosyadan import edildi

/**
 * @schema CreateRoomModal
 * @property {string} customId - Benzersiz kimlik (Modal ID)
 * @property {string} title - Modal başlığı
 * @property {Array} components - Input bileşenlerini içeren dizi
 */

/**
 * @schema VoiceChannel
 * @property {string} name - Ses kanalının adı
 * @property {string} type - Kanal tipi (ses kanalı)
 * @property {Array} permissionOverwrites - Kanal izinleri
 */

/**
 * @schema PersistentButton
 * @property {string} label - Butonun etiketi
 * @property {string} style - Butonun stili
 * @property {string} customId - Butonun benzersiz kimliği
 */

module.exports = {
  conf: {
    aliases: ["sanalseks", "odakur"], 
    name: "sanalseks",
    help: ".sanalseks",
    owner: true,
    category: "scroom",
  },

  Cyrstal: async (client, message, args) => {
    // Kalıcı buton oluştur
    const button = new ButtonBuilder()
      .setCustomId('createRoomButton')
      .setLabel('Oda Kur')
      .setStyle(ButtonStyle.Primary);

    const actionRow = new ActionRowBuilder().addComponents(button);
    message.channel.send({ content: 'Özel oda oluşturmak için aşağıdaki butona tıklayın:', components: [actionRow] });

    // Buton etkileşimini bekleme
    client.on('interactionCreate', async (interaction) => {
      if (!interaction.isButton() || interaction.customId !== 'createRoomButton') return;

      // Modal Builder oluştur
      const modal = new ModalBuilder()
        .setCustomId('createRoomModal')
        .setTitle('Özel Ses Odası Kur');

      const userIdInput = new TextInputBuilder()
        .setCustomId('userIdInput')
        .setLabel('Kullanıcı ID Girin')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('Örn: 123456789012345678')
        .setRequired(true);

      const modalActionRow = new ActionRowBuilder().addComponents(userIdInput);
      modal.addComponents(modalActionRow);

      await interaction.showModal(modal);

      // Modal cevaplarını bekleme
      const filter = (i) => i.customId === 'createRoomModal' && i.user.id === interaction.user.id;
      interaction.awaitModalSubmit({ filter, time: 60000 })
        .then(async (modalInteraction) => {
          const userId = modalInteraction.fields.getTextInputValue('userIdInput');
          const user1 = interaction.user;
          const user2 = await interaction.guild.members.fetch(userId).catch(() => null);

          if (!user2) return modalInteraction.reply({ content: 'Geçersiz kullanıcı ID.', ephemeral: true });

          // Ses kanalı oluştur
          const voiceChannel = await interaction.guild.channels.create({
            name: `${user1.username} & ${user2.user.username}`,
            type: ChannelType.GuildVoice,
            permissionOverwrites: [
              { id: interaction.guild.id, deny: [PermissionsBitField.Flags.Connect] },
              { id: user1.id, allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak] },
              { id: user2.id, allow: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.Speak] },
            ],
          });

          // Oda bilgilerini MongoDB'ye kaydet
          const newRoom = new Room({
            user1Id: user1.id,
            user2Id: user2.id,
            channelId: voiceChannel.id
          });
          await newRoom.save();

          modalInteraction.reply({ content: `Ses odası başarıyla oluşturuldu: ${voiceChannel}`, ephemeral: true });

          // Odada kullanıcı takibi
          const voiceStateUpdate = async (oldState, newState) => {
            const channel = newState.guild.channels.cache.get(voiceChannel.id);
            if (!channel) return;

            const members = channel.members.map((m) => m.id);
            if (members.some((id) => id !== user1.id && id !== user2.id)) {
              const unauthorized = members.find((id) => id !== user1.id && id !== user2.id);
              const member = await newState.guild.members.fetch(unauthorized);
              if (member) member.voice.disconnect(`Bu oda sadece ${user1.username} ve ${user2.user.username} için oluşturulmuştur.`);
            }

            if (members.length === 0) {
              channel.delete().catch(() => {});
              client.off('voiceStateUpdate', voiceStateUpdate);

              // MongoDB kaydını sil
              await Room.findOneAndDelete({ channelId: voiceChannel.id });
            }
          };

          client.on('voiceStateUpdate', voiceStateUpdate);
        })
        .catch(() => interaction.followUp({ content: 'Zaman aşımına uğradı.', ephemeral: true }));
    });
  },
};
