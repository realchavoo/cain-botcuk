const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const settings = require("../../../../../Src/Settings/Settings.json")
const Discord = require('discord.js');
const setups = require("../../../../../Src/Schemas/Setup")
const PrivateCommands = require("../../../../../Src/Schemas/PrivateCommands")
const emojis = require("../../../../../Src/Settings/emojiName.json")

module.exports = {
conf: {
name: "yardım",
aliases: ["help", "y", "yardim"],
help: "yardım"
},
Cyrstal: async (client, message, args, embed) => {
const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
if (!ayar) return;
let data = await PrivateCommands.find({ guildID: message.guild.id });
if (!data) data = await new PrivateCommands({ guildID: message.guild.id }).save();
let res = await PrivateCommands.find({});
const row = new Discord.ActionRowBuilder()
.addComponents(
new Discord.StringSelectMenuBuilder()
.setCustomId('helpss')
.setPlaceholder('Bot komutlarını görüntülemek için tıklayınız!')
.addOptions([
{
label: "User",
description: 'User komutlarını görüntülemek için tıklayınız.',
value: 'user',
emoji: message.guild.emojiGöster(emojis.sagok).id,
},
{
label: 'Bot Developer',
description: 'Bot Developer Komutlarını görüntülemek için tıklayınız.',
value: 'developer',
emoji: message.guild.emojiGöster(emojis.sagok).id,
},
{
label: 'Çekiliş',
description: 'Çekiliş komutlarını görüntülemek için tıklayınız.',
value: 'cekilis',
emoji: message.guild.emojiGöster(emojis.sagok).id,
},
{
label: 'Cezalandırma',
description: 'Cezalandırma komutlarını görüntülemek için tıklayınız.',
value: 'cezalandirma',
emoji: message.guild.emojiGöster(emojis.sagok).id,
},
{
label: 'Dolar',
description: 'Dolar komutlarını görüntülemek için tıklayınız.',
value: 'dolarcik',
emoji: message.guild.emojiGöster(emojis.sagok).id,
},
{
label: 'Eğlence',
description: 'Eğlence komutlarını görüntülemek için tıklayınız.',
value: 'eglence',
emoji: message.guild.emojiGöster(emojis.sagok).id,
},
{
label: 'Kayıt',
description: 'Kayıt komutlarını görüntülemek için tıklayınız.',
value: 'kayit',
emoji: message.guild.emojiGöster(emojis.sagok).id,
},


{
    label: 'Guard',
    description: 'Guard komutlarını görüntülemek için tıklayınız.',
    value: 'guard',
    emoji: message.guild.emojiGöster(emojis.sagok).id,
    },

    {
        label: 'Özel Oda',
        description: 'Özel Oda komutlarını görüntülemek için tıklayınız.',
        value: 'scroom',
        emoji: message.guild.emojiGöster(emojis.sagok).id,
        },
        {
            label: 'Sunucu Sahip',
            description: 'Sunucu Sahip komutlarını görüntülemek için tıklayınız.',
            value: 'owner',
            emoji: message.guild.emojiGöster(emojis.sagok).id,
            },
            {
                label: 'Terfi',
                description: 'Terfi komutlarını görüntülemek için tıklayınız.',
                value: 'terfi',
                emoji: message.guild.emojiGöster(emojis.sagok).id,
                },

                {
                    label: 'Ust Yonetim',
                    description: 'Ust Yonetim komutlarını görüntülemek için tıklayınız.',
                    value: 'styonetim',
                    emoji: message.guild.emojiGöster(emojis.sagok).id,
                    },
                    {
                        label: 'Stat',
                        description: 'Stat komutlarını görüntülemek için tıklayınız.',
                        value: 'stat',
                        emoji: message.guild.emojiGöster(emojis.sagok).id,
                        },
                        {
                            label: 'Yetkili',
                            description: 'Yetkili komutlarını görüntülemek için tıklayınız.',
                            value: 'yetkili',
                            emoji: message.guild.emojiGöster(emojis.sagok).id,
                            },

]),
);
const msg = await message.reply({ content: `**Merhaba!** Yardım almak ister misin?\nAşağıda bulunan menüden yardım almak istediğiniz kategoriyi seçin. 🎉`, components: [row], ephemeral: true}).catch((e) => {})
const filter = (i) => i.user.id === message.author.id
const collector = msg.createMessageComponentCollector({ filter })
collector.on("collect", async (interaction) => {
if(interaction.customId === "helpss") {
if(interaction.values[0] === "user") {
interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "user").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
}
if(interaction.values[0] === "cezalandirma") {
interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "cezalandirma").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
}
if(interaction.values[0] === "dolarcik") {
interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "dolarcik").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
}
if(interaction.values[0] === "eglence") {
interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "eglence").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
}
if(interaction.values[0] === "kayit") {
interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "kayit").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
}
if(interaction.values[0] === "developer") {
interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "developer").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
}
if(interaction.values[0] === "guard") {
    interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "guard").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
    }
    if(interaction.values[0] === "scroom") {
    interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "scroom").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
    }
    if(interaction.values[0] === "owner") {
    interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "owner").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
    }
    if(interaction.values[0] === "terfi") {
    interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "terfi").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
    }
    if(interaction.values[0] === "styonetim") {
    interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "styonetim").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
    }
    if(interaction.values[0] === "stat") {
    interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "stat").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
    }
    if(interaction.values[0] === "yetkili") {
        interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "yetkili").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
        }
        if(interaction.values[0] === "cekilis") {
            interaction.reply({content: `\`\`\`yml\n${client.Komutlar.filter((x) => x.conf.help && x.conf.category == "cekilis").sort((a, b) => b.conf.help - a.conf.help).map((x) => `${settings.Moderation.prefix}${x.conf.help}`).splice(0, 300).join("\n")}\`\`\``, ephemeral: true}).catch(e => {})
            }
}
})
}
}