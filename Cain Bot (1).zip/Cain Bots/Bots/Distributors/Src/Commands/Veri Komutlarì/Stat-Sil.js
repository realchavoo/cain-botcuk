const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');
const settings = require("../../../../../Src/Settings/Settings.json");
const emojis = require("../../../../../Src/Settings/emojiName.json");
const setups = require("../../../../../Src/Schemas/Setup");
const messageGuild = require("../../../../../Src/Schemas/MessageGuilds");
const voiceGuild = require("../../../../../Src/Schemas/VoiceGuilds");
const messageUser = require("../../../../../Src/Schemas/MessageUsers");
const voiceUser = require("../../../../../Src/Schemas/VoiceUsers");
const streamUser = require("../../../../../Src/Schemas/StreamUsers");
const cameraUser = require("../../../../../Src/Schemas/CameraUsers");
const inviterSchema = require("../../../../../Src/Schemas/İnvited");
const messageUserChannel = require("../../../../../Src/Schemas/MessageUserChannels");
const voiceUserChannel = require("../../../../../Src/Schemas/VoiceUserChannels");
const voiceUserParent = require("../../../../../Src/Schemas/VoiceUserParents");
const regstats = require("../../../../../Src/Schemas/RegisterStaffStats");

module.exports = {
  conf: {
    aliases: ["statsıfırla", "stat-sıfırla", "statsifirla"],
    name: "stat-sıfırla",
    help: "stat-sıfırla all/aylık/haftalık/günlük",
    category: "stat"
  },
  Cyrstal: async (client, message, args, embed) => {
    const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });

    if (!args[0]) {
      const menu = new StringSelectMenuBuilder()
        .setCustomId('stat_reset_select')
        .setPlaceholder('Lütfen bir seçenek seçin!')
        .addOptions(
          new StringSelectMenuOptionBuilder().setLabel('Günlük Statları Sıfırla').setValue('günlük').setEmoji("🔄"),
          new StringSelectMenuOptionBuilder().setLabel('Haftalık Statları Sıfırla').setValue('haftalık').setEmoji("🔄"),
          new StringSelectMenuOptionBuilder().setLabel('Aylık Statları Sıfırla').setValue('aylık').setEmoji("🔄"),
          new StringSelectMenuOptionBuilder().setLabel('Tüm Statları Sıfırla').setValue('all').setEmoji("🛑")
        );

      const row = new ActionRowBuilder().addComponents(menu);

      const msg = await message.reply({
        embeds: [embed.setDescription(`Merhaba **${message.guild.name}** Sunucusunun İstatistiklerini Sıfırlamak İçin Aşağıdaki Menüyü Kullanabilirsiniz.`)],
        components: [row]
      });

      const filter = i => i.user.id === message.member.id;
      const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

      collector.on('collect', async (interaction) => {
        if (interaction.isStringSelectMenu()) {
          const selectedOption = interaction.values[0];
          await interaction.deferUpdate();

          // Önceki mesajı sil
          await msg.delete();

          const row = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId("onay")
                .setLabel("Onayla")
                .setStyle(ButtonStyle.Secondary)
                .setEmoji("✅"),
              new ButtonBuilder()
                .setCustomId("red")
                .setLabel("İptal")
                .setStyle(ButtonStyle.Secondary)
                .setEmoji("❌")
            );

          const confirmationMessage = await interaction.channel.send({
            embeds: [embed.setDescription(`Sunucudaki **${selectedOption}** statlarını sıfırlamak istediğinize emin misiniz?`)],
            components: [row]
          });

          const confirmCollector = confirmationMessage.createMessageComponentCollector({ filter, time: 60000 });

          confirmCollector.on("collect", async (button) => {
            if (button.customId === "onay") {
              await button.deferUpdate();
              row.components[0].setDisabled(true);
              row.components[1].setDisabled(true);

              if (selectedOption === 'günlük') {
                await resetStats(message, 'dailyStat');
              } else if (selectedOption === 'haftalık') {
                await resetStats(message, 'weeklyStat');
              } else if (selectedOption === 'aylık') {
                await resetStats(message, 'monthStat');
              } else if (selectedOption === 'all') {
                await resetAllStats(message);
              }

              confirmationMessage.edit({
                embeds: [embed.setDescription(`Başarıyla **${selectedOption}** statları sıfırlandı.`)],
                components: [row]
              });
            } else if (button.customId === "red") {
              await button.deferUpdate();
              row.components[0].setDisabled(true);
              row.components[1].setDisabled(true);

              confirmationMessage.edit({
                embeds: [embed.setDescription(`İşlem iptal edildi.`)],
                components: [row]
              });
            }
          });
        }
      });
      return;
    }

    // Gelen argümanla işlem yap
    if (args[0] === 'günlük') {
      await resetStats(message, 'dailyStat');
    } else if (args[0] === 'haftalık') {
      await resetStats(message, 'weeklyStat');
    } else if (args[0] === 'aylık') {
      await resetStats(message, 'monthStat');
    } else if (args[0] === 'all') {
      await resetAllStats(message);
    }
  }
};

// Tek tek sıfırlama işlemleri
async function resetStats(message, statType) {
  const guildMembers = message.guild.members.cache;
  guildMembers.forEach(async (member) => {
    await messageGuild.updateOne({ guildID: settings.Moderation.guildID, userID: member.user.id }, { $set: { [statType]: 0 } }, { upsert: true });
    await voiceGuild.updateOne({ guildID: settings.Moderation.guildID, userID: member.user.id }, { $set: { [statType]: 0 } }, { upsert: true });
    await messageUser.updateOne({ guildID: settings.Moderation.guildID, userID: member.user.id }, { $set: { [statType]: 0 } }, { upsert: true });
    await voiceUser.updateOne({ guildID: settings.Moderation.guildID, userID: member.user.id }, { $set: { [statType]: 0 } }, { upsert: true });
    await streamUser.updateOne({ guildID: settings.Moderation.guildID, userID: member.user.id }, { $set: { [statType]: 0 } }, { upsert: true });
    await cameraUser.updateOne({ guildID: settings.Moderation.guildID, userID: member.user.id }, { $set: { [statType]: 0 } }, { upsert: true });
  });
}

async function resetAllStats(message) {
  const guildMembers = message.guild.members.cache;
  guildMembers.forEach(async (member) => {
    await messageGuild.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await voiceGuild.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await messageUser.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await voiceUser.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await streamUser.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await cameraUser.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await inviterSchema.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await messageUserChannel.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await voiceUserChannel.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await voiceUserParent.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
    await regstats.deleteMany({ guildID: settings.Moderation.guildID }, { upsert: true });
  });
}
