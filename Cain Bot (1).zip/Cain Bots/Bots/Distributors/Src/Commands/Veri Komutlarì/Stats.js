const settings = require("../../../../../Src/Settings/Settings.json")
const Discord = require("discord.js");
const Canvas = require("@napi-rs/canvas");
const setups = require("../../../../../Src/Schemas/Setup")
const emojis = require("../../../../../Src/Settings/emojiName.json")
const MessageUser = require("../../../../../Src/Schemas/MessageUsers")
const VoiceUser = require("../../../../../Src/Schemas/VoiceUsers")
const MessageUserParents = require("../../../../../Src/Schemas/MessageUserParents")
const VoiceUserParents = require("../../../../../Src/Schemas/VoiceUserParents")
const MessageUserChannel = require("../../../../../Src/Schemas/MessageUserChannels")
const VoiceUserChannel = require("../../../../../Src/Schemas/VoiceUserChannels")
const İnviter = require("../../../../../Src/Schemas/İnviteMembers")
const MemberSetup = require("../../../../../Src/Schemas/UserSetups")
const moment = require("moment");
require("moment-duration-format");
moment.locale("tr")
const path = require("path");
const fs = require("fs");
const ChatFriends = require("../../../../../Src/Schemas/ChatFriends")
const VoiceFriends = require("../../../../../Src/Schemas/VoiceFriends")
module.exports = {
conf: {
aliases: ["mes","stats"],
name: "stats",
help: "stats @Cain/ID",
category: "stat"
},
Cyrstal: async (client, message, args, embed, prefix) => {
const ayar = await setups.findOne({guildID: settings.Moderation.guildID})
if(!ayar) return;
const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
const sesData = await VoiceUser.findOne({ guildID: settings.Moderation.guildID, userID: member.id });
const mesajData = await MessageUser.findOne({ guildID: settings.Moderation.guildID, userID: member.id });
const TopChannels = await MessageUserChannel.aggregate([{ $match: { userID: member.id } }, { $sort: { channelData: -1 } }, { $limit: 5 }]);
const TopVoices = await VoiceUserChannel.aggregate([{ $match: { userID: member.id } }, { $sort: { channelData: -1 } }, { $limit: 5 }]);
const TopVoiceCategory = await VoiceUserParents.aggregate([{ $match: { userID: member.id } }, { $sort: { parentData: -1 } }, { $limit: 5 }]);
const TopMessageCategory = await MessageUserParents.aggregate([{ $match: { userID: member.id } }, { $sort: { parentData: -1 } }, { $limit: 5 }]);
const udb = await İnviter.find({ guildID: settings.Moderation.guildID, inviter: member.user.id })
let MemberData = await MemberSetup.findOne({ guildID: settings.Moderation.guildID, userID: member.id })
if(!MemberData) MemberData = new MemberSetup({ guildID: settings.Moderation.guildID, userID: member.id, levelSystem: true, monthlySystem: true })
const dailyInvites = udb.filter(x => {
const member = message.guild.members.cache.get(x.userID);
return member && Date.now() - member.joinedAt < 1000 * 60 * 60 * 24;
}).length;

const weeklyInvites = udb.filter(x => {
const member = message.guild.members.cache.get(x.userID);
return member && Date.now() - member.joinedAt < 1000 * 60 * 60 * 24 * 7;
}).length;

const monthlyInvites = udb.filter(x => {
const member = message.guild.members.cache.get(x.userID);
return member && Date.now() - member.joinedAt < 1000 * 60 * 60 * 24 * 30;
}).length;
const getChannelName = (channelID) => {
const channel = client.channels.cache.get(channelID);
return channel ? channel: "#Silinmiş-Kanal";
}
const document = await VoiceFriends.findOne({guildID: settings.Moderation.guildID, userID: member.id });
const topFriends = document && document.voiceFriends ? Object.keys(document.voiceFriends).map(c => ({ id: c, total: document.voiceFriends[c] })).sort((a, b) => b.total - a.total).slice(0, 1) : 'Bulunmuyor.'
const theTopFriend = client.users.cache.get(topFriends[0]?.id)
var chatFriend = await ChatFriends.find({ userID: member.id }).sort({ replyLength: -1 });
chatFriend = chatFriend.length > 0 ? await client.users.fetch(chatFriend[0]?.repliedUserID) : undefined;

const allVoiceData = await VoiceUser.find({ guildID: settings.Moderation.guildID });
const allMessageData = await MessageUser.find({ guildID: settings.Moderation.guildID });

// Sesli konuşma sıralaması
const voiceRank = allVoiceData
  .sort((a, b) => (b.topStat || 0) - (a.topStat || 0))
  .findIndex(user => user.userID === member.id) + 1;

// Mesaj sıralaması
const messageRank = allMessageData
  .sort((a, b) => (b.topStat || 0) - (a.topStat || 0))
  .findIndex(user => user.userID === member.id) + 1;

// Kanal verileri

let canvas = Canvas.createCanvas(1152, 585);
let ctx = canvas.getContext("2d");
const imagePath = path.resolve(__dirname, "../../../../../Src/İmages/stat-card.png");

let background = await Canvas.loadImage(imagePath);

ctx.drawImage(background, 0, 0, 1152, 585);

ctx.font = '40px "DINNextLTPro-Bold"';
ctx.fillStyle = '#FFFFFF';
let ramalcik = member.user.username;
ctx.fillText(`${ramalcik}`, canvas.width / 10.00, 63);

ctx.font = '24px "DINNextLTPro-Bold"';
ctx.fillStyle = '#FFFFFF';
ctx.fillText(`${moment(Date.now()).format("LLL")}`, canvas.width / 1.32, 63);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = '#FFFFFF';
ctx.fillText(`${voiceRank || "Bulunamadı"}`, canvas.width / 5.60, 183);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = '#FFFFFF';
ctx.fillText(`${messageRank || "Bulunamadı"}`, canvas.width / 5.60, 233);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = '#FFFFFF';
ctx.fillText(``, canvas.width / 5.60, 283);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = '#FFFFFF';
ctx.fillText(`Veri Bulunamadı.`, canvas.width / 5.60, 333);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`${mesajData?.topStat || 0}`, canvas.width / 1.97, 183, 200, 400);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`${mesajData?.dailyStat || 0}`, canvas.width / 1.97, 233, 200, 400);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`${mesajData?.weeklyStat || 0}`, canvas.width / 1.97, 283, 200, 400);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`Veri Yoktur.`, canvas.width / 1.97, 333, 200, 400);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`${moment.duration(sesData?.topStat || 0).format("H [saat], m [dakika], s [saniye]") || 0}`, canvas.width / 1.20, 183, 200, 400);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`${moment.duration(sesData?.dailyStat || 0).format("H [saat], m [dakika], s [saniye]") || 0}`, canvas.width / 1.20, 233, 200, 400);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`${moment.duration(sesData?.weeklyStat || 0).format("H [saat], m [dakika], s [saniye]") || 0}`, canvas.width / 1.20, 283, 200, 400);

ctx.font = '21px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`Veri Yoktur.`, canvas.width / 1.20, 333, 200, 400);


ctx.font = '23px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`Bulunamadı.`, canvas.width / 1.23, 463, 200, 400);

ctx.font = '23px "DINNextLTPro-Bold"';
ctx.fillStyle = "#FFFFFF";
ctx.fillText(`Bulunamadı.`, canvas.width / 1.23, 515, 200, 400);

let image = await Canvas.loadImage(member.displayAvatarURL({ size: 128, format: 'png' }));
ctx.save();
roundedImage(ctx, 27, 12, 75, 75, 28);
ctx.clip();
ctx.drawImage(image, 27, 12, 75, 75);
ctx.restore();

let img = canvas.toBuffer('image/png');
message.reply({ content: ``, files: [img] });
}
};

/**
* roundedImage()
* @property {ctx} ctx Canvas ctx
* @param {object} ctx Canvas ctx 
* @param {number|bigint} x Number
* @param {number|bigint} y Number
* @param {number|bigint} width Number
* @param {number|bigint} height Number
* @param {number|boolean} radius Number Or Boolean
* @returns {roundedImage}
* @example roundedImage(ctx,50,50,500,300,10)
* @example roundedImage(ctx,50,50,500,300,true)
*/
function roundedImage(ctx, x, y, width, height, radius) {
if (radius === true) radius = 5;
if (!radius || typeof radius !== "number") radius = 0;

ctx.beginPath();
ctx.moveTo(x + radius, y);
ctx.lineTo(x + width - radius, y);
ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
ctx.lineTo(x + width, y + height - radius);
ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
ctx.lineTo(x + radius, y + height);
ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
ctx.lineTo(x, y + radius);
ctx.quadraticCurveTo(x, y, x + radius, y);
ctx.closePath();
ctx.fill();

return ctx;
}
