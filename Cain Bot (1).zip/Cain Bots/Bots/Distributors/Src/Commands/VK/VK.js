const vk = require("../../../../../Src/Schemas/VK")
const Discord = require("discord.js")
const setups = require("../../../../../Src/Schemas/Setup")
const emojis = require("../../../../../Src/Settings/emojiName.json")
const settings = require("../../../../../Src/Settings/Settings.json")
const CommandPermissions = require("../../../../../Src/Schemas/CommandPermissions")
module.exports = {
conf: {
aliases: ["vk"],
name: "vk",
help: "vk",
category: "vk",
cooldown: 15
},
Cyrstal: async (client, message, args, embed) => {
const ayar = await setups.findOne({guildID: settings.Moderation.guildID})
if(!ayar) return;
if(!args[0]) {
await message.react(message.guild.emojiGöster(emojis.yes))
return message.reply({content: `Yanlış Kullanım. \n\nÖrnek Kullanım: **${settings.Moderation.prefix}vk** \`başlat, bitir, gece, sabah, oylama, öldür, koru yardım, rol-dağıt\``}).sil(15)
}
if(args[0] == "yardım") {
message.react(message.guild.emojiGöster(emojis.yes))
return message.reply({embeds: [embed.setDescription(`**${message.guild.emojiGöster(emojis.kalp)} ${message.member} Merhaba Vampir Köylü Hakkında Bilgileri Aşağıda Belirttim.**

*Bu Oyuna Katılırsanız Size Kişi Sayısına Göre Vampir/Doktor/Köylü Olursunuz
(4 Kişi Oynarsa 1 Vampir 1 Doktor Ve 2 Köylü) (6 Kişi Oynarsa 2 Vampir 1 Doktor Ve 3 Köylü) (8 Kişi Oynarsa 2 Vampir 1 Doktor Ve 5 Köylü) Rolünüz Size DM üzerinden Belirtilir.
Rolünüze Göre Hareket Etmelisiniz Ve Vampirlere Göre Özel Oda Vardır Bu Kişilere Odada Yazışma İmkanı Verilir Yani Vampirler Birbirini Bilirler
Ama Onun Harici Kimse Rolünü Bilmez!*`)]})
}
if(args[0] == "durum") {
message.react(message.guild.emojiGöster(emojis.yes))
return message.reply({content: `Yanlış Kullanım. \n\nÖrnek Kullanım: **${settings.Moderation.prefix}vk** \`başlat, bitir, gece, sabah, oylama, öldür, koru yardım, rol-dağıt\``}).sil(15)
}
if(args[0] == "bitir") {
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active === false) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
if (data && data.channels[message.member.voice.channel.id] && !data.channels[message.member.voice.channel.id].Active) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && !data.channels[message.member.voice.channel.id].Admin.includes(message.author.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Komutu Sadece Oyun Yöneticileri Kullanabilir.`}).sil(15);
}
await message.react(message.guild.emojiGöster(emojis.yes))
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: { [message.member.voice.channel.id]: { } } } }, { upsert: true });
let text = `
${message.guild.emojiGöster(emojis.face)} ${message.member} Başarıyla **VK** Oyunu ${message.member.voice.channel} Ses Kanalında Bitirildi.

${message.guild.emojiGöster(emojis.sagok)} Oyuncu Listesi;
${message.member.voice.channel.members.filter(x => x.user.id != message.member.id).map(x => x.toString()).join("\n")}
${message.guild.emojiGöster(emojis.sagok)} Bitiş Tarihi: <t:${(Date.now() / 1000).toFixed(0)}:R>
${message.guild.emojiGöster(emojis.sagok)} Oyun Yöneticisi: ${message.member}
${message.guild.emojiGöster(emojis.sagok)} Vampirler: ${data && data.channels[message.member.voice.channel.id].Vampires && data.channels[message.member.voice.channel.id].Vampires.map(x => message.guild.members.cache.get(x).toString()).join(", ") || "0"}
${message.guild.emojiGöster(emojis.sagok)} Doktorlar: ${data && data.channels[message.member.voice.channel.id].Doctor && data.channels[message.member.voice.channel.id].Doctor.map(x => message.guild.members.cache.get(x).toString()).join(", ") || "0"}
${message.guild.emojiGöster(emojis.sagok)} Köylüler: ${data && data.channels[message.member.voice.channel.id].Players && data.channels[message.member.voice.channel.id].Players.filter(x => data.channels[message.member.voice.channel.id].Doctor && !data.channels[message.member.voice.channel.id].Doctor.includes(x) && data.channels[message.member.voice.channel.id].Vampires && !data.channels[message.member.voice.channel.id].Vampires.includes(x) && x != message.member.user.id).map(x => message.guild.members.cache.get(x).toString()).join(", ") || "0"}
${message.guild.emojiGöster(emojis.sagok)} Ölü Sayısı: ${data && data.channels[message.member.voice.channel.id].Dead && data.channels[message.member.voice.channel.id].Dead || "0"}`
const chunk = await client.splitMessage(text, 4060)
for (text of chunk) {
await message.reply({embeds: [embed.setDescription(`${text}`)]})
}
const channel = message.guild.channels.cache.get(data && data.channels[message.member.voice.channel.id].DoctorChannel)
const channel2 = message.guild.channels.cache.get(data && data.channels[message.member.voice.channel.id].VampireChannel)
if(channel) await channel.delete();
if(channel2) await channel2.delete();
}
if(args[0] == "baslat") {
const Name = ["Vk", "vk"]
const Data = await CommandPermissions.findOne({ guildID: message.guild.id, Command: Name.map(x => x)});
if(!Data?.Permissions?.some(x => message.member.roles.cache.has(x) || x.includes(message.author.id)) && ayar.seniorStaffRoles.some(x => message.member.roles.cache.has(x)) && !ayar.staffRoles.some(x => message.member.roles.cache.has(x)) && !message.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu Komutu Kullanabilmek İçin Yeterli Yetkiye Sahip Değilsin.`}).sil(15)
}
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
if(message.member.voice.channel.members.size < 10) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Ses kanalında en az 10 kişi olmalı.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active === true) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif.`}).sil(15);
}
await message.react(message.guild.emojiGöster(emojis.yes))
await vk.updateOne({guildID: settings.Moderation.guildID}, {$set: {[`channels.${message.member.voice.channel.id}`]: {Players: message.member.voice.channel.members.filter(x => x.id != message.member.id).map(x => x.id), StartDate: Date.now(), Admin: message.member.id, Active: true, Day: "Sabah"}}}, {upsert: true, new: true})
let text = `
${message.guild.emojiGöster(emojis.face)} ${message.member} Başarıyla **VK** Oyunu ${message.member.voice.channel} Ses Kanalında Başlatıldı.

${message.guild.emojiGöster(emojis.sagok)} Oyuncu Listesi;
${message.member.voice.channel.members.map(x => x.toString()).join("\n")}
${message.guild.emojiGöster(emojis.sagok)} Başlatma Tarihi: <t:${(Date.now() / 1000).toFixed(0)}:R>
${message.guild.emojiGöster(emojis.sagok)} Oyun Yöneticisi: ${message.member}`
const chunk = await client.splitMessage(text, 4060)
for (text of chunk) {
await message.reply({embeds: [embed.setDescription(`${text}`)]})
}
}
if(args[0] == "rol-dağıt") {
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
if(message.member.voice.channel.members.size < 10) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Ses kanalında en az 10 kişi olmalı.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active === false) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Villager && data.channels[message.member.voice.channel.id].Villager.length > 0 || data.channels[message.member.voice.channel.id].Vampires && data.channels[message.member.voice.channel.id].Vampires.length > 0 || data.channels[message.member.voice.channel.id].Doctor && data.channels[message.member.voice.channel.id].Doctor.length > 0) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Oyun Rolleri Zaten Dağıtılmış.`}).sil(15);
}
await message.react(message.guild.emojiGöster(emojis.yes))
const members = Array.from(message.member.voice.channel.members.values());
const shuffledMembers = members.sort(() => Math.random() - 0.5).filter(x => x.id !== message.member.id);

const vampiresSize = message.member.voice.channel.members.size < 12
? shuffledMembers.slice(0, 2).map(x => x.id)
: message.member.voice.channel.members.size >= 12 && shuffledMembers.slice(0, 3).map(x => x.id);

const doctorsSize = message.member.voice.channel.members.size < 12
? shuffledMembers.slice(2, 3).map(x => x.id)
: message.member.voice.channel.members.size >= 12 && shuffledMembers.slice(3, 5).map(x => x.id);

const villagersSize = message.member.voice.channel.members.size < 12
? shuffledMembers.slice(3, 30).map(x => x.id)
: message.member.voice.channel.members.size >= 12 && shuffledMembers.slice(5, 30).map(x => x.id);
let doc = await vk.findOne({ guildID: settings.Moderation.guildID });
if (!doc) {
doc = { guildID: settings.Moderation.guildID, channels: {} };
}
doc.channels[message.member.voice.channel.id] = doc.channels[message.member.voice.channel.id] || {};
doc.channels[message.member.voice.channel.id].Villager = villagersSize;
doc.channels[message.member.voice.channel.id].Doctor = doctorsSize;
doc.channels[message.member.voice.channel.id].Vampires = vampiresSize;
doc.channels[message.member.voice.channel.id].Active = true;
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: doc.channels } }, { upsert: true });
const datas = await vk.findOne({ guildID: settings.Moderation.guildID});
const getMembers = (roleArray) => roleArray.map(id => message.guild.members.cache.get(id)).filter(member => member);
const doctorMembers = datas?.channels[message.member.voice.channel.id]?.Doctor ? getMembers(datas.channels[message.member.voice.channel.id].Doctor) : [];
const villagerMembers = datas?.channels[message.member.voice.channel.id]?.Villager ? getMembers(datas.channels[message.member.voice.channel.id].Villager) : [];
const vampireMembers = datas?.channels[message.member.voice.channel.id]?.Vampires ? getMembers(datas.channels[message.member.voice.channel.id].Vampires) : [];
await message.reply({embeds: [embed.setDescription(`**${message.member} Başarıyla Oyun Rolleri Dağıtıldı.**`)]});
await sendMessage(doctorMembers, 'Doktor', message, message.member);
await sendMessage(vampireMembers, 'Vampir', message, message.member);
await sendMessage(villagerMembers, 'Köylü', message, message.member);
try {
const vampirChannel = await message.guild.channels.create({
name: "Vampir Kanalı",
type: Discord.ChannelType.GuildText,
parent: ayar.vkParents[0],
permissionOverwrites: [
{ id: message.guild.id, deny: [Discord.PermissionFlagsBits.SendMessages, Discord.PermissionFlagsBits.ViewChannel] },
]
});
const doctorChannel = await message.guild.channels.create({
name: "Doktor Kanalı",
type: Discord.ChannelType.GuildText,
parent: ayar.vkParents[0],
permissionOverwrites: [
{ id: message.guild.id, deny: [Discord.PermissionFlagsBits.SendMessages, Discord.PermissionFlagsBits.ViewChannel] },
]
});
vampireMembers.forEach(async member => {
try {
await vampirChannel.permissionOverwrites.edit(member.id, { SendMessages: true, ViewChannel: true });
} catch (e) {
console.error(`Hata oluştu:`, e);
}
});

doctorMembers.forEach(async member => {
try {
await doctorChannel.permissionOverwrites.edit(member.id, { SendMessages: true, ViewChannel: true });
} catch (e) {
console.error(`Hata oluştu:`, e);
}
});
let docs = await vk.findOne({ guildID: settings.Moderation.guildID });
docs.channels[message.member.voice.channel.id] = docs.channels[message.member.voice.channel.id] || {};
docs.channels[message.member.voice.channel.id].DoctorChannel = doctorChannel.id;
docs.channels[message.member.voice.channel.id].VampireChannel = vampirChannel.id;
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: docs.channels } }, { upsert: true });
} catch (e) {
console.error('Kanalları oluştururken bir hata oluştu:', e);
}
}
if(args[0] == "öldür") {
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Vampires && !data.channels[message.member.voice.channel.id].Vampires.includes(message.member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Vampir Olmadığın İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].VampireChannel && !data.channels[message.member.voice.channel.id].VampireChannel.includes(message.channel.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Vampir Kanalında Olmadığın İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active && data.channels[message.member.voice.channel.id].Active === false) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
const getMembers = (roleArray) => roleArray.map(id => message.guild.members.cache.get(id)).filter(member => member);
const members = data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Villager ? getMembers(data.channels[message.member.voice.channel.id].Villager) : [];
if(members.length === 0) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Hiç Bir Köylü Kullanıcı yok.`}).sil(15);
}
const member = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Lütfen Bir Kullanıcı Etiketleyin.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].VampiresLimit && !data.channels[message.member.voice.channel.id].VampiresLimit.length == 1) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Sadece Günde 1 Kez Öldürebilirsin.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Vampires && data.channels[message.member.voice.channel.id].Vampires.includes(member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Takım Arkadaşını Öldüremezsin.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Villager && !data.channels[message.member.voice.channel.id].Villager.includes(member.id) && data.channels[message.member.voice.channel.id].Doctor && !data.channels[message.member.voice.channel.id].Doctor.includes(member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Kullanıcı Zaten Katledilmiş.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Day != "Gece") {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Gece Olmadığı Icin Bu Komutu Kullanamazsın.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].DoctorSaved && data.channels[message.member.voice.channel.id].DoctorSaved.includes(member.id)) {
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({content: `${message.member}, Başarıyla ${member} Kullanıcısı Öldürdün.`})
let doc = await vk.findOne({ guildID: settings.Moderation.guildID });
if (!doc) {
doc = { guildID: settings.Moderation.guildID, channels: {} };
}
doc.channels[message.member.voice.channel.id] = doc.channels[message.member.voice.channel.id] || {};
doc.channels[message.member.voice.channel.id].VampiresLimit = 1;
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: doc.channels } }, { upsert: true });
await sendAdminDeadMessage(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && data.channels[message.member.voice.channel.id].Admin, message, member);
return }
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({content: `${message.member}, Başarıyla ${member} Kullanıcısı Öldürdün.`})
await sendAdminSaveMessage(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && data.channels[message.member.voice.channel.id].Admin, message, member);
let doc = await vk.findOne({ guildID: settings.Moderation.guildID });
if (!doc) {
doc = { guildID: settings.Moderation.guildID, channels: {} };
}
doc.channels[message.member.voice.channel.id] = doc.channels[message.member.voice.channel.id] || {};
doc.channels[message.member.voice.channel.id].Dead = +1;
doc.channels[message.member.voice.channel.id].VampiresLimit = 1;
doc.channels[message.member.voice.channel.id].DoctorSaved = "";
doc.channels[message.member.voice.channel.id].Villager = doc.channels[message.member.voice.channel.id].Villager.filter(x => x != member.id).map(x => x);
doc.channels[message.member.voice.channel.id].Players = doc.channels[message.member.voice.channel.id].Players.filter(x => x != member.id).map(x => x);
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: doc.channels } }, { upsert: true });
}
if(args[0] == "koru") {
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Doctor && !data.channels[message.member.voice.channel.id].Doctor.includes(message.member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Doktor Olmadığın İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].DoctorChannel && !data.channels[message.member.voice.channel.id].DoctorChannel.includes(message.channel.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Doktor Kanalında Olmadığın İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active && data.channels[message.member.voice.channel.id].Active === false) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
const members = data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Villager ? data.channels[message.member.voice.channel.id].Villager : [];
if(members.length === 0) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Hiç Bir Köylü Kullanıcı yok.`}).sil(15);
}
const member = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Lütfen Bir Kullanıcı Etiketleyin.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].DoctorLimit && !data.channels[message.member.voice.channel.id].DoctorLimit.length == 1) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Sadece Günde 1 Kez Koruyabilirsin.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Villager && !data.channels[message.member.voice.channel.id].Villager.includes(member.id) && data.channels[message.member.voice.channel.id].Doctor && !data.channels[message.member.voice.channel.id].Doctor.includes(message.member.id) && data.channels[message.member.voice.channel.id].Vampires && !data.channels[message.member.voice.channel.id].Vampires.includes(member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Kullanıcı Oyunda Bulunmamakta.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Day != "Gece") {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Gece Olmadığı Icin Bu Komutu Kullanamazsın.`}).sil(15);
}
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({content: `${message.member}, Başarıyla ${member} Kullanıcısını Korudun.`})
let doc = await vk.findOne({ guildID: settings.Moderation.guildID });
if (!doc) {
doc = { guildID: settings.Moderation.guildID, channels: {} };
}
doc.channels[message.member.voice.channel.id] = doc.channels[message.member.voice.channel.id] || {};
doc.channels[message.member.voice.channel.id].DoctorSaved = member.id;
doc.channels[message.member.voice.channel.id].DoctorLimit = 1;
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: doc.channels } }, { upsert: true });
console.log(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && data.channels[message.member.voice.channel.id].Admin)
await sendAdminSavedMessage(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && data.channels[message.member.voice.channel.id].Admin, message, member);
}
if(args[0] == "gece") {
const getMembers = (roleArray) => roleArray.map(id => message.guild.members.cache.get(id)).filter(member => member);
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && !data.channels[message.member.voice.channel.id].Admin.includes(message.member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Admin Olmadığın İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active && data.channels[message.member.voice.channel.id].Active === false) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Day == "Gece") {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Oyun Modu Zaten Gece Olduğu İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({content: `${message.guild.emojiGöster(emojis.kalp)} ${message.member}, Başarıyla Oyun Modu **Gece** Olarak Ayarlandı.`})
let doc = await vk.findOne({ guildID: settings.Moderation.guildID });
if (!doc) {
doc = { guildID: settings.Moderation.guildID, channels: {} };
}
doc.channels[message.member.voice.channel.id] = doc.channels[message.member.voice.channel.id] || {};
doc.channels[message.member.voice.channel.id].Day = "Gece";
doc.channels[message.member.voice.channel.id].DoctorLimit = 0;
doc.channels[message.member.voice.channel.id].VampiresLimit = 0;
doc.channels[message.member.voice.channel.id].DoctorSaved = "";
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: doc.channels } }, { upsert: true });
message.member.voice.channel.members
.filter(member => member.id !== message.member.id)
.forEach(async member => {
try {
await member.voice.setMute(true);
} catch (e) {
console.error(e);
}
});
}
if(args[0] == "sabah") {
const getMembers = (roleArray) => roleArray.map(id => message.guild.members.cache.get(id)).filter(member => member);
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && !data.channels[message.member.voice.channel.id].Admin.includes(message.member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Admin Olmadığın İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active && data.channels[message.member.voice.channel.id].Active === false) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Day == "Sabah") {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Oyun Modu Zaten Sabah Olduğu İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
await message.react(message.guild.emojiGöster(emojis.yes))
await message.reply({content: `${message.guild.emojiGöster(emojis.kalp)} ${message.member}, Başarıyla Oyun Modu **Sabah** Olarak Ayarlandı.`})
let doc = await vk.findOne({ guildID: settings.Moderation.guildID });
if (!doc) {
doc = { guildID: settings.Moderation.guildID, channels: {} };
}
doc.channels[message.member.voice.channel.id] = doc.channels[message.member.voice.channel.id] || {};
doc.channels[message.member.voice.channel.id].Day = "Sabah";
await vk.updateOne({ guildID: settings.Moderation.guildID }, { $set: { channels: doc.channels } }, { upsert: true });
message.member.voice.channel.members
.filter(member => member.id !== message.member.id)
.forEach(async member => {
try {
await member.voice.setMute(false);
} catch (e) {
console.error(e);
}
});
}
if(args[0] == "oylama") {
if(!message.member.voice.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return message.reply({content: `Bu komutu sadece ses kanalında kullanabilirsin.`}).sil(15)
}
const data = await vk.findOne({guildID: settings.Moderation.guildID});
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Admin && !data.channels[message.member.voice.channel.id].Admin.includes(message.member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Admin Olmadığın İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
if (data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Active && data.channels[message.member.voice.channel.id].Active === false) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Ses Kanalında Vk Oyunu Aktif Değil.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Day != "Sabah") {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Oyun Modu Sabah Olmadığı İçin Bu Komutu Kullanamazsın.`}).sil(15);
}
const member = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
if(!member) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Lütfen Bir Kullanıcı Etiketleyin.`}).sil(15);
}
if(data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Players && !data.channels[message.member.voice.channel.id].Players.includes(member.id)) {
await message.react(message.guild.emojiGöster(emojis.no));
return message.reply({content: `Bu Oyuncu Yaşamıyor.`}).sil(15);
}
await message.react(message.guild.emojiGöster(emojis.yes))
let tikdata = new Map();
let yesData = new Map();
let noData = new Map();
yesData.set("yes", new Set());
noData.set("no", new Set());

let yes = new Discord.ButtonBuilder()
.setLabel('Evet')
.setStyle(Discord.ButtonStyle.Success)
.setEmoji('✅')
.setCustomId('yes');
let no = new Discord.ButtonBuilder()
.setLabel('Hayır')
.setStyle(Discord.ButtonStyle.Danger)
.setEmoji('❌')
.setCustomId('no');

const row = new Discord.ActionRowBuilder()
.addComponents(yes, no);

const msj = await message.reply({content: `${message.guild.emojiGöster(emojis.face)} ${message.member}, Oyun Yöneticisi Oylama Başlattı!\n\n${member} Adlı Kullanıcısı İçin Oylama Başlatıldı Lütfen Evet, Hayır Butonuna Tıklayın.`, components: [row]});
const collector = msj.createMessageComponentCollector({time: 60000});

collector.on('collect', async i => {
if (tikdata.get(i.member.id) >= 1) {
return;
}

tikdata.set(i.member.id, 1);
await i.deferUpdate();

if (i.customId === 'yes') {
let yesSet = yesData.get("yes");
yesSet.add(i.member.id);
yesData.set("yes", yesSet);
yes.setLabel(`Evet ${yesSet.size}`);
} else if (i.customId === 'no') {
let noSet = noData.get("no");
noSet.add(i.member.id);
noData.set("no", noSet);
no.setLabel(`Hayır ${noSet.size}`);
}

await msj.edit({components: [row]});
});

collector.on('end', async i => {
const yesVotes = yesData.get("yes").size;
const noVotes = noData.get("no").size;

if (noVotes > yesVotes) {
await msj.edit({content: `${message.guild.emojiGöster(emojis.face)} ${message.member}, Tıklama İptal Edildi.`, components: []});
} else if (yesVotes == noVotes) {
await msj.edit({content: `${message.guild.emojiGöster(emojis.face)} ${message.member}, Tıklama İptal Edildi Berabere Olduğu İçin.`, components: []});
} else if (yesVotes > noVotes) {
let doc = await vk.findOne({guildID: settings.Moderation.guildID});
if (!doc) {
doc = {guildID: settings.Moderation.guildID, channels: {}};
}

doc.channels[message.member.voice.channel.id] = doc.channels[message.member.voice.channel.id] || {};
doc.channels[message.member.voice.channel.id].Dead = +1;
doc.channels[message.member.voice.channel.id].Villager = doc.channels[message.member.voice.channel.id].Villager.filter(x => x != member.id).map(x => x);
doc.channels[message.member.voice.channel.id].Players = doc.channels[message.member.voice.channel.id].Players.filter(x => x != member.id).map(x => x);
doc.channels[message.member.voice.channel.id].Doctor = doc.channels[message.member.voice.channel.id].Doctor.filter(x => x != member.id).map(x => x);
doc.channels[message.member.voice.channel.id].Vampires = doc.channels[message.member.voice.channel.id].Vampires.filter(x => x != member.id).map(x => x);
await vk.updateOne({guildID: settings.Moderation.guildID}, {$set: {channels: doc.channels}}, {upsert: true});
await member.voice.setMute(true).catch(e => {});

await msj.edit({content: `${message.guild.emojiGöster(emojis.face)} ${member} Kişisi Asıldı.\n\nOyundaki Rolü: ${data && data.channels[message.member.voice.channel.id] && data.channels[message.member.voice.channel.id].Vampires && data.channels[message.member.voice.channel.id].Vampires.includes(member.id) ? "**Vampir**" : data.channels[message.member.voice.channel.id].Doctor && data.channels[message.member.voice.channel.id].Doctor.includes(member.id) ? "**Doktor**" : "**Köylü**"}`, components: []});
} else {
await msj.edit({components: []});
}
});
}
}
}

async function sendMessage(members, role, message, admin) {
for (const member of members) {
try {
await member.send({content: `${member} Merhaba, **${message.guild.name}** Sunucusundan Ulaşıyorum.\n\n${message.member.voice.channel} Kanalında Oynanan Oyun Hakkında Bilgi Vermek İçin Yazıyorum!\nOyun Rolün: **${role}**`});
} catch (e) {
admin.send({content: `Merhaba ${admin}, **${member}** Kullanıcısına Ulaşamıyorum Bilgilendirir Misin Onu!\n\nRolü: **${role}**`});
}
}
};

async function sendAdminDeadMessage(members, message, user) {
try {
const member = message.guild.members.cache.get(members);
await member.send({content: `${member} Merhaba, **${message.guild.name}** Sunucusundan Ulaşıyorum.\n\n${message.member.voice.channel} Kanalında Oynanan Oyun Hakkında Bilgi Vermek İçin Yazıyorum!\nVampirler Gece ${user} Kişisini Öldürmeye Çalıştı Ama Doktor Tarafından Korunduğu İçin Öldüremediler.`});
} catch (e) {
console.error(e);
}
};

async function sendAdminSavedMessage(members, message, user) {
try {
const member = message.guild.members.cache.get(members);
await member.send({content: `${member} Merhaba, **${message.guild.name}** Sunucusundan Ulaşıyorum.\n\n${message.member.voice.channel} Kanalında Oynanan Oyun Hakkında Bilgi Vermek İçin Yazıyorum!\nDoktor Gece ${user} Kullanıcısını Korudu.`});
} catch (e) {
console.error(e);
}
};

async function sendAdminSaveMessage(members, message, user) {
try {
const member = message.guild.members.cache.get(members);
await member.send({content: `${member} Merhaba, **${message.guild.name}** Sunucusundan Ulaşıyorum.\n\n${message.member.voice.channel} Kanalında Oynanan Oyun Hakkında Bilgi Vermek İçin Yazıyorum!\nVampirler Gece ${user} Kullanıcısını Katletti.`});
} catch (e) {
console.error(e);
}
};