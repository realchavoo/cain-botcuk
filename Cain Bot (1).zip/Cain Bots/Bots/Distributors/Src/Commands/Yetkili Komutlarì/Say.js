const fs = require('fs');
const { Client, GatewayIntentBits, AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');
const path = require('path');
const moment = require("moment");
moment.locale("tr");
const clients = global.client;
const Discord = require("discord.js");
const emojis = require("../../../../../Src/Settings/emojiName.json");
const setups = require("../../../../../Src/Schemas/Setup");
const CommandPermissions = require("../../../../../Src/Schemas/CommandPermissions");

module.exports = {
  conf: {
    aliases: ["say"],
    name: "say",
    help: "say",
    category: "yetkili"
  },
  Cyrstal: async (client, message, args, embed) => {
    const ayar = await setups.findOne({ guildID: message.guild.id });
    if (!ayar) return;
    const Name = ["Say", "say"];
    const Data = await CommandPermissions.findOne({
      guildID: message.guild.id,
      Command: Name.map(x => x),
    });

    if (
      !Data?.Permissions?.some(x =>
        message.member.roles.cache.has(x) || x.includes(message.author.id)
      ) &&
      !ayar.seniorStaffRoles.some(x => message.member.roles.cache.has(x)) &&
      !ayar.staffRoles.some(x => message.member.roles.cache.has(x)) &&
      !message.member.permissions.has(Discord.PermissionFlagsBits.Administrator) &&
      !ayar.ownerRoles.some(x => message.member.roles.cache.has(x))
    ) {
      await message.react(message.guild.emojiGöster(emojis.no));
      return message
        .reply({
          content: "Bu Komutu Kullanabilmek İçin Yeterli Yetkiniz Bulunmamaktadır.",
        })
        .then(msg => {
          setTimeout(() => msg.delete(), 15000); // 15 saniye sonra silme
        });
    }

    const guild = message.guild;

    // Sunucu verilerini çekme
    const totalMembers = guild.memberCount;
    const onlineMembers = guild.members.cache.filter(member => 
      member.presence?.status === "online" || 
      member.presence?.status === "dnd" || 
      member.presence?.status === "idle"
    ).size;
    const offlineMembers = totalMembers - onlineMembers;
    const desktopMembers = guild.members.cache.filter(
      member => member.presence?.clientStatus?.desktop
    ).size;
    const webMembers = guild.members.cache.filter(
      member => member.presence?.clientStatus?.web
    ).size;
    const voiceMembers = guild.members.cache.filter(
      member => member.voice.channel
    ).size;
    const activeChannels = guild.channels.cache.filter(
      channel => channel.isVoiceBased() && channel.members.size > 0
    ).size;
    var tagges = message.guild.members.cache.filter(m => 
      ayar.serverTag.some(t => 
          m.user.globalName && m.user.globalName.includes(t) || m.user.username.includes(t)
      )
  ).size;
  var takviye = message.guild.premiumSubscriptionCount;

  const cameraUsers = guild.members.cache.filter(
    (member) => member.voice.channel && member.voice.selfVideo
  ).size;
  const streamUsers = guild.members.cache.filter(
    (member) => member.voice.channel && member.voice.selfStream
  ).size;
  
  // Canvas boyutu
    const canvas = Canvas.createCanvas(700, 300);
    const ctx = canvas.getContext("2d");

    // URL üzerinden resim yükleme
const backgroundUrl = 'https://i.hizliresim.com/ezlj1v3.png';

  // Resmi URL üzerinden yükle
  const background = await Canvas.loadImage(backgroundUrl);
  ctx.drawImage(background, 0, 0, canvas.width, canvas.height);


    // Sunucu adı başlığı
   // Yazıları çizme (güncellenmiş pozisyonlarla, biraz yukarı ve sola kaydırıldı)
// Kalın font ve gölge ekleme
ctx.font = "bold 28px sans-serif"; // Kalın ve daha büyük font
ctx.fillStyle = "#ffffff";
ctx.textAlign = "center"; // Yazıyı ortala

// Gölge ekleme
ctx.shadowColor = "rgba(0, 0, 0, 0.5)"; // Gölge rengi
ctx.shadowBlur = 4; // Gölge bulanıklık
ctx.shadowOffsetX = 2; // Gölge yatay kaydırma
ctx.shadowOffsetY = 2; // Gölge dikey kaydırma

ctx.fillText(`Sunucu Aktiflik Bilgileri`, canvas.width / 2, 35); // Ortaya al


// Detayları hizalama (yukarı ve sola çekildi)
ctx.font = "18px sans-serif";
ctx.fillText(`Toplam Üye: ${totalMembers}`, 130, 115); // Daha aşağı
ctx.fillText(`Online Üye: ${onlineMembers}`, 340, 115); // Daha aşağı
ctx.fillText(`Offline Üye: ${offlineMembers}`, 550, 115); // Daha aşağı
ctx.fillText(`Masaüstü Sayısı: ${desktopMembers}`, 130, 166);
ctx.fillText(`Web Sayısı: ${webMembers}`, 340, 167);
ctx.fillText(`Sesteki Üye: ${voiceMembers}`, 560, 166);
ctx.fillText(`Aktif Kanallar: ${activeChannels}`, 340, 270)
ctx.fillText(`Tag Alanlar: ${tagges}`, 560, 270);
ctx.fillText(`Destek Olanlar: ${takviye}`, 130, 270);
ctx.fillText(`Camera Açanlar: ${cameraUsers}`, 570, 220);
ctx.fillText(`Yayın Açanlar: ${streamUsers}`, 350, 220);


    // Görseli bir dosyaya dönüştür
    const attachment = new AttachmentBuilder(canvas.toBuffer(), {
      name: "Information.png",
    });

    // Mesaj olarak resmi gönder
    message.channel.send({ files: [attachment] });
  },
};

