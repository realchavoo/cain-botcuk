const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  conf: {
    aliases: ["emojiid", "emoji-id"],
    name: "emojiid",
    help: "emojiid",
    owner: true,
    category: "owner",
  },

  Cyrstal: async (client, message, args) => {
    if (!args.length) {
      const emojis = message.guild.emojis.cache;
      if (emojis.size === 0) {
        return message.reply("Bu sunucuda hiç emoji bulunmuyor.");
      }

      const emojiArray = emojis.map((emoji) => `${emoji} | ID: ${emoji.id}`);
      const chunkSize = 20;
      const pages = [];

      for (let i = 0; i < emojiArray.length; i += chunkSize) {
        const chunk = emojiArray.slice(i, i + chunkSize).join("\n");
        const embed = new EmbedBuilder()
          .setTitle(`Sunucudaki Emojiler ve ID'leri - Sayfa ${pages.length + 1}`)
          .setDescription(chunk)
          .setFooter({ text: `Sayfa ${pages.length + 1}/${Math.ceil(emojiArray.length / chunkSize)}` });
        pages.push(embed);
      }

      let currentPage = 0;
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('previous')
            .setLabel('⬅️')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage === 0),

          new ButtonBuilder()
            .setCustomId('next')
            .setLabel('➡️')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage === pages.length - 1)
        );

      const messageEmbed = await message.channel.send({ embeds: [pages[currentPage]], components: [row] });

      const collector = messageEmbed.createMessageComponentCollector({ time: 60000 });

      collector.on('collect', async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({ content: "Bu butonları sadece komutu yazan kişi kullanabilir.", ephemeral: true });
        }

        if (interaction.customId === 'next') {
          currentPage = Math.min(currentPage + 1, pages.length - 1);
        } else if (interaction.customId === 'previous') {
          currentPage = Math.max(currentPage - 1, 0);
        }

        const updatedRow = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('previous')
              .setLabel('⬅️')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(currentPage === 0),

            new ButtonBuilder()
              .setCustomId('next')
              .setLabel('➡️')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(currentPage === pages.length - 1)
          );

        await interaction.update({ embeds: [pages[currentPage]], components: [updatedRow] });
      });

      collector.on('end', () => {
        const disabledRow = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('previous')
              .setLabel('⬅️')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(true),

            new ButtonBuilder()
              .setCustomId('next')
              .setLabel('➡️')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(true)
          );

        messageEmbed.edit({ components: [disabledRow] }).catch(() => {});
      });

      return;
    }

    // Eğer bir emoji belirtilmişse, sadece o emojinin kendisini ve ID'sini göster
    const emojiInput = args[0];
    const foundEmoji = message.guild.emojis.cache.find(
      (e) => e.name === emojiInput || e.toString() === emojiInput
    );

    if (!foundEmoji) {
      return message.reply("Böyle bir emoji bulunamadı.");
    }

    const embed = new EmbedBuilder()
      .setTitle("Emoji ID")
      .setDescription(`Emoji: ${foundEmoji} | ID: ${foundEmoji.id}`);

    return message.channel.send({ embeds: [embed] });
  },
};
