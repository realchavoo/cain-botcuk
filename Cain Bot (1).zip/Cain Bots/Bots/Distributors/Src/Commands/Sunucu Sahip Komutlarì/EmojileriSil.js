const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    conf: {
        name: "emojisil",
        aliases: ["emojisil"],
        help: ".emojisil",
        category: "owner",
        owner: true,  
        cooldown: 10,
    },

    Cyrstal: async (client, message, args, embed) => {
        // shades tag ALCAK
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('delete_emojis')
                .setLabel('Tüm Emojileri Sil')
                .setStyle(ButtonStyle.Danger)
        );

        // SHADES
        const initialMessage = await message.reply({
            content: 'Tüm emojileri silmek için aşağıdaki butona tıklayın.',
            components: [row],
        });

     
        const filter = i => i.customId === 'delete_emojis' && i.user.id === message.author.id;
        const collector = message.channel.createMessageComponentCollector({
            filter,
            time: 15000,
        });

        collector.on('collect', async (interaction) => {
            await interaction.deferUpdate();
            await interaction.message.edit({ content: "Emojiler siliniyor... Lütfen bekleyin!", components: [] });

            const emojis = message.guild.emojis.cache;
            let emojisDeleted = 0;

            for (const emoji of emojis.values()) {
                await emoji.delete('Tüm emojiler siliniyor.').catch(e => {}); // Hata olursa geç
                emojisDeleted++;
                await new Promise(resolve => setTimeout(resolve, 4000));
            }

            await interaction.followUp({
                content: `Tüm emojiler başarıyla silindi! Toplam **${emojisDeleted}** emoji silindi.`,
            });
        });

        collector.on('end', (collected, reason) => {
        });
    },
};
