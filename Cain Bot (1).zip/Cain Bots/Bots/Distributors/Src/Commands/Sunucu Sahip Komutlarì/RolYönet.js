const { PermissionsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    conf: {
        aliases: ["ry"],
        name: "ry",
        help: "ry",
        category: "owner",
    },

    Cyrstal: async (client, message, args) => {
        if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return message.reply("🚫 Bu komutu kullanabilmek için Yönetici yetkisine sahip olmanız gerekiyor!").then(msg => setTimeout(() => msg.delete(), 5000));
        }

        const targetUser = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!targetUser) {
            return message.reply("❗ Lütfen geçerli bir kullanıcı belirtin! Örnek: [**@kullanıcı veya ID**]").then(msg => setTimeout(() => msg.delete(), 5000));
        }

        const roles = message.guild.roles.cache.filter(role => role.name !== "@everyone").sort((a, b) => b.position - a.position);
        if (roles.size === 0) {
            return message.reply("⚠️ Bu sunucuda eklenebilir bir rol bulunmuyor!").then(msg => setTimeout(() => msg.delete(), 5000));
        }

        const itemsPerPage = 10;
        let currentPage = 0;
        const totalPages = Math.ceil(roles.size / itemsPerPage);

        const generateEmbed = (page, status = null) => {
            const start = page * itemsPerPage;
            const end = start + itemsPerPage;
            const rolesList = Array.from(roles.values()).slice(start, end).map((role, index) => `**${start + index + 1}.** <@&${role.id}>`);

            const embed = new EmbedBuilder()
                .setTitle("🎭 Rol Yönetimi")
                .setDescription(`Aşağıdaki roller arasından seçim yapın:\n\n${rolesList.join("\n") || "Bu sayfada gösterilecek rol bulunamadı."}`)
                .setFooter({ text: `Sayfa ${page + 1} / ${totalPages}` })
                .setColor("Blue");

            if (status) {
                embed.addFields({ name: "Son İşlem", value: status, inline: false });
            }

            return embed;
        };

        const row = () => new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("previous").setLabel("◀️ Geri").setStyle(ButtonStyle.Secondary).setDisabled(currentPage === 0),
            new ButtonBuilder().setCustomId("close").setLabel("❌ Kapat").setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId("next").setLabel("İleri ▶️").setStyle(ButtonStyle.Secondary).setDisabled(currentPage === totalPages - 1)
        );

        const embedMessage = await message.channel.send({
            embeds: [generateEmbed(currentPage)],
            components: [row()]
        });

        const filter = interaction => interaction.user.id === message.author.id;
        const collector = embedMessage.createMessageComponentCollector({ filter, time: 60000 });

        collector.on("collect", async interaction => {
            if (interaction.customId === "previous" && currentPage > 0) {
                currentPage--;
            } else if (interaction.customId === "next" && currentPage < totalPages - 1) {
                currentPage++;
            } else if (interaction.customId === "close") {
                await embedMessage.delete();
                return collector.stop();
            }

            await interaction.update({
                embeds: [generateEmbed(currentPage)],
                components: [row()]
            });
        });

        collector.on("end", () => {
            embedMessage.edit({ components: [] });
        });

        message.channel.awaitMessages({
            filter: msg => msg.author.id === message.author.id,
            max: 1,
            time: 30000,
            errors: ["time"]
        }).then(async collected => {
            const input = collected.first().content.trim();
            const isRemoveAction = input.startsWith("-");
            const roleIndex = parseInt(isRemoveAction ? input.slice(1) : input) - 1;
        
            if (isNaN(roleIndex) || roleIndex < 0 || roleIndex >= roles.size) {
                return embedMessage.edit({ embeds: [generateEmbed(currentPage, "❌ Geçersiz rol numarası girdiniz. Lütfen doğru bir numara seçin.")] });
            }
        
            const selectedRole = Array.from(roles.values())[roleIndex];
            let status;
        
            if (isRemoveAction) {
                if (targetUser.roles.cache.has(selectedRole.id)) {
                    await targetUser.roles.remove(selectedRole);
                    status = `✅ <@${targetUser.id}> - <@&${selectedRole.id}> rolü **kaldırıldı**!`;
                } else {
                    status = `⚠️ Bu kullanıcıda zaten bu rol bulunmuyor!`;
                }
            } else {
                if (!targetUser.roles.cache.has(selectedRole.id)) {
                    await targetUser.roles.add(selectedRole);
                    status = `✅ <@${targetUser.id}> - <@&${selectedRole.id}> rolü **eklendi**!`;
                } else {
                    status = `⚠️ Bu kullanıcı zaten bu role sahip!`;
                }
            }
        
            await embedMessage.edit({
                embeds: [generateEmbed(currentPage, status)]
            });
        }).catch(() => {
            embedMessage.edit({ embeds: [generateEmbed(currentPage, "⏰ Zaman aşımı! İşlem iptal edildi.")] });
        });
    }
}        