const { ActionRowBuilder, RoleSelectMenuBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const UserRoles = require("../../../../../Src/Schemas/userRoles");

module.exports = {
  conf: {
    aliases: ["rolver", "rolver"],
    name: "rolver",
    help: ".rolver @Cain/ID <Rol Id>.",
    owner: true,
    category: "owner",
  },

  Cyrstal: async (client, message, args) => {
    if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return message.reply("Bu komutu kullanabilmek için Yönetici yetkisine sahip olmalısınız.");
    }

    const targetUser =
      message.mentions.members.first() || 
      message.guild.members.cache.get(args[0]);

    if (!targetUser) {
      return message.reply("Lütfen bir kullanıcı etiketleyin veya bir kullanıcı ID'si girin.");
    }

    const embed = new EmbedBuilder()
      .setTitle("Rol Yönetimi")
      .setDescription(`${targetUser} için bir işlem seçin. Yönetici veya Kanal Yönet rolleri verilemez.`)
      .setColor("Blue");

    const roleSelectMenu = new RoleSelectMenuBuilder()
      .setCustomId("role_select")
      .setPlaceholder("Rol seçiniz")
      .setMinValues(1)
      .setMaxValues(10);

    const removeRolesButton = new ButtonBuilder()
      .setCustomId("remove_roles")
      .setLabel("Rolleri Geri Al")
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(roleSelectMenu);
    const buttonRow = new ActionRowBuilder().addComponents(removeRolesButton);

    const sentMessage = await message.channel.send({ embeds: [embed], components: [row, buttonRow] });

    const collector = sentMessage.createMessageComponentCollector({ time: 60000 });

    collector.on("collect", async interaction => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({ content: "Bu menüyü sadece komutu kullanan kişi yönetebilir.", ephemeral: true });
      }

      if (interaction.customId === "role_select") {
        const selectedRoles = interaction.values;

        const invalidRoles = selectedRoles.filter(roleId => {
          const role = interaction.guild.roles.cache.get(roleId);
          return role && (role.permissions.has(PermissionsBitField.Flags.Administrator) || role.permissions.has(PermissionsBitField.Flags.ManageChannels));
        });

        if (invalidRoles.length > 0) {
          return interaction.reply({ content: "Yönetici veya Kanal Yönet rolleri verilemez.", ephemeral: true });
        }

        await targetUser.roles.add(selectedRoles);

        await UserRoles.findOneAndUpdate(
          { userId: targetUser.id },
          { $addToSet: { roles: { $each: selectedRoles } } },
          { upsert: true, new: true }
        );

        const updatedEmbed = new EmbedBuilder()
          .setTitle("Roller Güncellendi")
          .setDescription(`${targetUser} kullanıcısına şu roller eklendi: ${selectedRoles.map(roleId => `<@&${roleId}>`).join(", ")}`)
          .setColor("Green");

        await interaction.update({ embeds: [updatedEmbed], components: [] });
      } else if (interaction.customId === "remove_roles") {
        const userData = await UserRoles.findOne({ userId: targetUser.id });

        if (!userData || userData.roles.length === 0) {
          return interaction.reply({ content: "Geri alabileceğiniz kayıtlı roller bulunamadı.", ephemeral: true });
        }

        const removedRoles = userData.roles;

        await targetUser.roles.remove(removedRoles);
        await UserRoles.findOneAndDelete({ userId: targetUser.id });

        const updatedEmbed = new EmbedBuilder()
          .setTitle("Roller Güncellendi")
          .setDescription(`${targetUser} kullanıcısından şu roller geri alındı: ${removedRoles.map(roleId => `<@&${roleId}>`).join(", ")}`)
          .setColor("Red");

        await interaction.update({ embeds: [updatedEmbed], components: [] });
      }
    });
  }
}