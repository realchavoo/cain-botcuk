const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionsBitField } = require('discord.js');

module.exports = {
    conf: {
        aliases: ["reklamss"],
        name: "reklamss",
        help: "Reklam SS sistemi kurulumunu başlatır.",
        category: "owner",
        owner: true,
        cooldown: 15,
    },
    Cyrstal: async (client, message, args, embed) => {

        const initialEmbed = new EmbedBuilder()
            .setDescription("📸 **Reklam SS Kurulumu**\n\nBu sistemi kullanarak sunucunuzda reklam içeriklerini kolayca yönetebilirsiniz. Kurulumu başlatmak için aşağıdaki butona tıklayın.")
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
            .setFooter({ text: "Reklam SS Sistemi Kurulumu", iconURL: client.user.displayAvatarURL() });

        const initialButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId("setup_button")
                    .setLabel("Kurulumu Başlat")
                    .setStyle(ButtonStyle.Success)
            );

        const initialMessage = await message.channel.send({ embeds: [initialEmbed], components: [initialButtons] });

        const filter = (interaction) => interaction.user.id === message.author.id && interaction.customId === "setup_button";
        const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

        collector.on("collect", async (interaction) => {
            await interaction.update({ content: "Embed mesajlarının gönderileceği kanalı seçin", embeds: [], components: [] });

            const embedChannelMenu = new ActionRowBuilder()
                .addComponents(
                    new ChannelSelectMenuBuilder()
                        .setCustomId("embed_channel_select")
                        .setPlaceholder("Embed için kanal seçin.")
                );

            const embedChannelMessage = await message.channel.send({ content: "📜 Embed kanalı seçimi yapın:", components: [embedChannelMenu] });

            const embedChannelFilter = (selectInteraction) => selectInteraction.user.id === message.author.id && selectInteraction.customId === "embed_channel_select";
            const embedChannelCollector = message.channel.createMessageComponentCollector({ embedChannelFilter, time: 60000 });

            embedChannelCollector.on("collect", async (embedChannelInteraction) => {
                const selectedEmbedChannel = embedChannelInteraction.values[0]; 
                await embedChannelInteraction.update({ content: `⚙️ Log kanalı oluşturuluyor, lütfen bekleyin...`, components: [] });

                const logChannelName = "reklam-ss-log";
                let logChannel = message.guild.channels.cache.find(channel => channel.name === logChannelName);

                if (!logChannel) {
                    logChannel = await message.guild.channels.create({
                        name: logChannelName,
                        type: 0, 
                        permissionOverwrites: [
                            {
                                id: message.guild.roles.everyone.id, 
                                deny: [
                                    PermissionsBitField.Flags.ViewChannel, 
                                    PermissionsBitField.Flags.SendMessages, 
                                ],
                            },
                            {
                                id: message.guild.roles.cache.find(role => role.permissions.has(PermissionsBitField.Flags.Administrator))?.id || message.guild.ownerId, // Yöneticiler
                                allow: [
                                    PermissionsBitField.Flags.ViewChannel, 
                                    PermissionsBitField.Flags.SendMessages, 
                                ],
                            },
                        ],
                    });

                    const lastCategory = message.guild.channels.cache
                        .filter(channel => channel.type === 4) 
                        .sort((a, b) => a.position - b.position) 
                        .last();

                    if (lastCategory) {
                        await logChannel.setParent(lastCategory.id);
                    }
                    await logChannel.setPosition(message.guild.channels.cache.size - 1); 
                }

                await message.channel.send(`✅ Sistem başarıyla kuruldu!\n**Embed Kanalı:** <#${selectedEmbedChannel}>\n**Log Kanalı:** <#${logChannel.id}>`);

                const logEmbed = new EmbedBuilder()
                    .setDescription("🔍 **Reklam SS Sistemi**\n\nArtık reklam içeriklerini kolayca rapor edebilirsiniz. Aşağıdaki butonu kullanarak reklam ekran görüntülerini loglayabilirsiniz.")
                    .setFooter({ text: "Reklam SS Sistemi", iconURL: client.user.displayAvatarURL() });

                const logButton = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("reklamss_button")
                            .setLabel("Reklam SS")
                            .setStyle(ButtonStyle.Primary)
                    );

                const embedChannel = message.guild.channels.cache.get(selectedEmbedChannel);
                if (embedChannel) {
                    await embedChannel.send({ embeds: [logEmbed], components: [logButton] });
                }

                client.on("interactionCreate", async (modalInteraction) => {
                    if (!modalInteraction.isButton() || modalInteraction.customId !== "reklamss_button") return;

                    const modal = new ModalBuilder()
                        .setCustomId("reklamss_modal")
                        .setTitle("Reklam SS Gönder");

                    const linkInput = new TextInputBuilder()
                        .setCustomId("reklamss_link_input")
                        .setLabel("Ekran görüntüsü linkini girin:")
                        .setStyle(TextInputStyle.Short);

                    const modalRow = new ActionRowBuilder().addComponents(linkInput);
                    modal.addComponents(modalRow);

                    await modalInteraction.showModal(modal);
                });

                client.on("interactionCreate", async (modalSubmit) => {
                    if (!modalSubmit.isModalSubmit() || modalSubmit.customId !== "reklamss_modal") return;

                    const screenshotLink = modalSubmit.fields.getTextInputValue("reklamss_link_input");
                    const screenshotEmbed = new EmbedBuilder()
                        .setDescription(`📷 **Yeni Reklam SS**\n\n[Bağlantıyı görüntüle](${screenshotLink})`)
                        .setImage(screenshotLink)
                        .setTimestamp();

                    if (logChannel) {
                        await logChannel.send({ embeds: [screenshotEmbed] });
                    }

                    await modalSubmit.reply({ content: "📝 Ekran görüntüsü başarıyla log kanalına gönderildi.", ephemeral: true });
                });
            });
        });
    },
};
