const settings = require("../../../../../Src/Settings/Settings.json")
const Discord = require('discord.js');
const setups = require("../../../../../Src/Schemas/Setup")
const AdvertDB = require("../../../../../Src/Schemas/AdvertDB")
const emojis = require("../../../../../Src/Settings/emojiName.json")
module.exports = {
conf: {
name: "reklam-kanal",
aliases: ["reklamkanal"],
help: "reklam-kanal ekle/sil/liste #Kanal/ID",
owner: true,
category: "owner"
},
Cyrstal: async (client, message, args, embed) => {
const ayar = await setups.findOne({guildID: settings.Moderation.guildID})
if(!ayar) return;
let data = await AdvertDB.findOne({ guildID: message.guild.id });
if (!data) data = await new AdvertDB({ guildID: message.guild.id, advert: [] }).save();
if (!args[0]) return message.reply({ content: "Lütfen geçerli bir işlem belirtin!\n\n`ekle`, `sil`" }).sil(15)
if (args[0] === "ekle") {
let channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
if (!channel) return message.reply({ content: "Lütfen geçerli bir kanal belirtin!" }).sil(15);
const url = args[2];
if (data && data.advert.find((x) => x.channel === channel.id)) return message.reply({ content: "Bu kanal zaten veritabanında bulunuyor!" }).sil(15)
await AdvertDB.updateOne({ guildID: message.guild.id }, { $push: { advert: { channel: channel.id, url: url ? url : "" } } }, { upsert: true });
await message.reply({ content: "Başarılı bir şekilde **"+channel.name+"** kanalı veritabanına eklendi!" });
} else if (args[0] === "sil") {
let channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]);
if (!channel) return message.reply({ content: "Lütfen geçerli bir kanal belirtin!" }).sil(15)
const url = args[2];
if (data && !data.advert.find((x) => x.channel === channel.id)) return message.reply({ content: "Bu kanal veritabanında bulunmuyor!" }).sil(15)
await AdvertDB.updateOne({ guildID: message.guild.id }, { $pull: { advert: { channel: channel.id, url: url ? url : ""} } }, { upsert: true });
await message.reply({ content: "Başarılı bir şekilde **"+channel.name+"** kanalı veritabanından silindi!" });
} else if (args[0] === "liste") {
if(!data) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ content: "Sunucuda reklam kanalı bulunmamaktadır!" }).sil(15);
}
if(!data.advert) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ content: "Sunucuda reklam kanalı bulunmamaktadır!" }).sil(15);
}
if(!data.advert.channel) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ content: "Sunucuda reklam kanalı bulunmamaktadır!" }).sil(15);
}
if(data.advert && data.advert.length == 0 && data.advert.channel.length == 0) {
await message.react(message.guild.emojiGöster(emojis.no))
return await message.reply({ content: "Sunucuda reklam kanalı bulunmamaktadır!" }).sil(15);
}
embed.setFooter({text: "Toplam Kanal Sayısı: " + (data.advert ? (data.advert).length : 0)});
embed.setDescription(`${message.guild.emojiGöster(emojis.info)} **${message.guild.name}** Sunucusunun Reklam Kanal Ayarları Aşağıda Belirtilmiştir;\n\n${data.advert && data.advert.map((x, index) => `**${index + 1}.** ${message.guild.channels.cache.get(x.channel) || x.channel} - [Tıkla](https://discord.gg/${x.url ? x.url : message.guild.vanityURLCode})`).join("\n")}`);
message.reply({ embeds: [embed] });
}
}
};
