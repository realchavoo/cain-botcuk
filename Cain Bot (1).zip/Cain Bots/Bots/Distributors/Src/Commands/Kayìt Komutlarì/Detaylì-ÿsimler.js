const axios = require("axios");
const settings = require("../../../../../Src/Settings/Settings.json");
const emojis = require("../../../../../Src/Settings/emojiName.json");
const setups = require("../../../../../Src/Schemas/Setup");
const CommandPermissions = require("../../../../../Src/Schemas/CommandPermissions");
const Discord = require("discord.js");

module.exports = {
  conf: {
    name: "detaylı-isimler",
    help: "detaylı-isimler @Cain/ID",
    category: "kayit",
    aliases: ["detaylıisimler", "detaylı-isimler", "di", "detayli-isimler", "detayliisimler"]
  },
  Cyrstal: async (client, message, args, embed, prefix) => {
    const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
    if (!ayar) return;
    const Name = ["detaylıisimler", "detaylı-isimler", "di", "detayli-isimler", "detayliisimler"];
    const Data = await CommandPermissions.findOne({ guildID: message.guild.id, Command: Name.map(x => x) });
    if (!Data?.Permissions?.some(x => message.member.roles.cache.has(x) || x.includes(message.author.id)) &&
        !ayar.seniorStaffRoles.some(x => message.member.roles.cache.has(x)) &&
        !ayar.registerRoles.some(oku => message.member.roles.cache.has(oku)) &&
        !ayar.ownerRoles.some(oku => message.member.roles.cache.has(oku)) &&
        !message.member.permissions.has(Discord.PermissionFlagsBits.Administrator) &&
        !ayar.staffRoles.some(oku => message.member.roles.cache.has(oku))) {
      await message.react(message.guild.emojiGöster(emojis.no));
      return message.reply({ embeds: [embed.setDescription(`Yetkin bulunmamakta. Yetkili olmak istersen başvuru yapabilirsin.`)] }).sil(15);
    }
    let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || await client.users.fetch(args[0]);
    if (!member) {
      await message.react(message.guild.emojiGöster(emojis.no));
      return message.reply({ embeds: [embed.setDescription(`Bir üye belirtmelisin!`)] }).sil(15);
    }
    const response = await axios.get(`http://185.169.180.182:1555/api/user?id=${member.id}`);
    if (!response.data) return;
    await message.react(message.guild.emojiGöster(emojis.yes));
    const userData = response.data;
    const userGender = userData.TopSex || "Belirsiz";
    let text = userData.Guilds.map(x => `Sunucu: ${x.guildName}\nİsim: ${x.displayName}\nCinsiyet: ${userGender}`).join("\n\n");
    if (message.guild.members.cache.get(member.id)) {
      const chunk = await client.splitMessage(text, 4060);
      for (let part of chunk) {
        await message.channel.send({ embeds: [embed.setDescription(`${message.guild.emojiGöster(emojis.info)} ${member} Kullanıcısının Diğer Sunuculardaki (**${userData.Guilds.length}**) Verisi Aşağıda Belirtilmiştir.\n\n\`\`\`yml\n${part}\`\`\``)] });
      }
    } else {
      const chunk = await client.splitMessage(text, 4060);
      for (let part of chunk) {
        await message.channel.send({ embeds: [embed.setDescription(`${message.guild.emojiGöster(emojis.info)} **${member.username}** Kullanıcısının Diğer Sunuculardaki (**${userData.Guilds.length}**) Verisi Aşağıda Belirtilmiştir.\n\n\`\`\`yml\n${part}\`\`\``)] });
      }
    }
  }
};