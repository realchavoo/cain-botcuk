const emojis = require("../../../../../Src/Settings/emojiName.json")
const setups = require("../../../../../Src/Schemas/Setup")
const Discord = require("discord.js");
const settings = require("../../../../../Src/Settings/Settings.json")
module.exports = {
    conf: {
      aliases: ["kurulum"],
      name: "kurulum",
      help: "kurulum",
      category: "developer",
      owner: true
    },
    Cyrstal: async (client, message, args, embed) => {

const row = new Discord.ActionRowBuilder()
.addComponents(
new Discord.ButtonBuilder()
.setCustomId("kanalk")
.setLabel("Kanal Kurulum")
.setStyle(Discord.ButtonStyle.Secondary),
new Discord.ButtonBuilder()
.setCustomId("emojik")
.setLabel("Emoji Kurulum")
.setStyle(Discord.ButtonStyle.Secondary),
);
let msg = await message.channel.send({ content: `Lütfen **60 saniye** içerisinde hangi kurulum yapacağınızı aşağıdaki butonlara tıklayarak cevaplayınız.`, components: [row]})
var filter = (button) => button.user.id === message.author.id;
const collector = msg.createMessageComponentCollector({ filter, time: 60000 })

collector.on('collect', async (interaction) => {   
    if (interaction.customId === "kanalk") {
        const logChannelNames = [
            'message-log', 'voice-log', 'tag-log', 'rol-log', 'mute-log', 'vmute-log', 
            'jail-log', 'reklamcı-log', 'yasaklıtag-log', 'ban-log', 'ceza-log', 
            'üye-log', 'kayıt-log', 'mazeret-log', 'gorev-log', 'terfi-sistem-log', 
            'yetki-log', 'streamer-basvuru-log', 'yetkili-basvuru-log', 'şikayet-log', 
            'öneri-log', 'istek-log', 'özeloda-log', 'yetki-bırakan-log', 'yetki-çek-log', 
            'taglı-log', 'timeout-log', 'günlük-sıfırlama-log', 'haftalık-sıfırlama-log', 
            'aylık-sıfırlama-log', 'kanal-koruma-log', 'rol-koruma-log', 'emoji-koruma-log', 
            'stick-koruma-log', 'üye-koruma-log', 'sunucu-koruma-log', 'web-koruma-log', 
            'offline-koruma-log', 'guard-log'
        ];
    
        const moderationCategory = await message.guild.channels.cache.find(c => c.name === 'Moderasyon Log' && c.type === Discord.ChannelType.GuildCategory) ||
            await message.guild.channels.create({
                name: 'Moderasyon Log',
                type: Discord.ChannelType.GuildCategory,
                permissionOverwrites: [{ id: settings.Moderation.guildID, deny: [Discord.PermissionFlagsBits.ViewChannel] }],
            });
    
        const guardCategory = await message.guild.channels.cache.find(c => c.name === 'Guard Log' && c.type === Discord.ChannelType.GuildCategory) ||
            await message.guild.channels.create({
                name: 'Guard Log',
                type: Discord.ChannelType.GuildCategory,
                permissionOverwrites: [{ id: settings.Moderation.guildID, deny: [Discord.PermissionFlagsBits.ViewChannel] }],
            });
    
        const guardLogChannels = ['kanal-koruma-log', 'rol-koruma-log', 'emoji-koruma-log', 
            'stick-koruma-log', 'üye-koruma-log', 'sunucu-koruma-log', 'web-koruma-log', 
            'offline-koruma-log', 'guard-log'];
    
        const missingChannels = logChannelNames.filter(channelName => !message.guild.channels.cache.some(c => c.name === channelName));
    
        if (missingChannels.length === 0) {
            return interaction.reply({ content: `Tüm log kanalları zaten kurulu.`, ephemeral: true });
        }
    
        for (const channelName of missingChannels) {
            const parentCategory = guardLogChannels.includes(channelName) ? guardCategory : moderationCategory;
    
            await message.guild.channels.create({
                name: channelName,
                type: Discord.ChannelType.GuildText,
                parent: parentCategory.id
            }).then(() => console.log(`${channelName} kanalı oluşturuldu.`))
              .catch(err => console.log(`Kanal oluşturulurken hata oluştu: ${err}`));
        }
    
        interaction.reply({ content: `Eksik olan log kanalları başarıyla kuruldu.`, ephemeral: true });
    }
}
)
    
collector.on('collect', async (interaction) => {
    if (interaction.customId === "emojik") {
        const emojiNames = {
            yes: emojis.yes,
            no: emojis.no,
            sifir: emojis.sifir,
            bir: emojis.bir,
            iki: emojis.iki,
            uc: emojis.uc,
            dort: emojis.dort,
            bes: emojis.bes,
            alti: emojis.alti,
            yedi: emojis.yedi,
            sekiz: emojis.sekiz,
            dokuz: emojis.dokuz,
            fillStart: emojis.fillStart,
            fill: emojis.fill,
            fillEnd: emojis.fillEnd,
            empty: emojis.empty,
            emptyEnd: emojis.emptyEnd,
            info: emojis.info,
            warn: emojis.warn,
            top_bir: emojis.top_bir,
            top_iki: emojis.top_iki,
            top_uc: emojis.top_uc,
            nocommand: emojis.nocommand,
            kalp: emojis.kalp,
            punish: emojis.punish,
            star: emojis.star,
            face: emojis.face,
            fire: emojis.fire,
            like: emojis.like,
            sagok: emojis.sagok,
            stat: emojis.stat,
            member: emojis.member,
            dislike: emojis.dislike,
            nokta: emojis.nokta,
        };

        const emojiList = {
            [emojiNames.yes]: "https://cdn.discordapp.com/emojis/1197343830207381557.gif?size=96&animated=true",
            [emojiNames.no]: "https://cdn.discordapp.com/emojis/791592984025497604.gif?size=96&animated=true",
            [emojiNames.sifir]: "https://cdn.discordapp.com/emojis/1274681507138506754.gif?size=96&animated=true",
            [emojiNames.bir]: "https://cdn.discordapp.com/emojis/1325568835276898331.gif?size=96&animated=true",
            [emojiNames.iki]: "https://cdn.discordapp.com/emojis/1274655485907173417.gif?size=96&animated=true",
            [emojiNames.uc]: "https://cdn.discordapp.com/emojis/1325568845766852701.gif?size=96&animated=true",
            [emojiNames.dort]: "https://cdn.discordapp.com/emojis/1316986799481950248.gif?size=96&animated=true",
            [emojiNames.bes]: "https://cdn.discordapp.com/emojis/1204163907539968082.gif?size=96&animated=true",
            [emojiNames.alti]: "https://cdn.discordapp.com/emojis/1204163945188040716.gif?size=96&animated=true",
            [emojiNames.yedi]: "https://cdn.discordapp.com/emojis/1316986758583423010.gif?size=96&animated=true",
            [emojiNames.sekiz]: "https://cdn.discordapp.com/emojis/1316986786873868340.gif?size=96&animated=true",
            [emojiNames.dokuz]: "https://cdn.discordapp.com/emojis/1295091010237497395.gif?size=96&animated=true",

            [emojiNames.fillStart]: "https://cdn.discordapp.com/emojis/1235161873029140593.webp?size=128&quality=lossless",
            [emojiNames.empty]: "https://cdn.discordapp.com/emojis/1235161782645952541.webp?size=128&quality=lossless",
            [emojiNames.emptyEnd]: "https://cdn.discordapp.com/emojis/1235161798446026762.webp?size=128&quality=lossless",
            [emojiNames.fillEnd]: "https://cdn.discordapp.com/emojis/1235161914296897626.webp?size=128&quality=lossless",
            [emojiNames.fill]: "https://cdn.discordapp.com/emojis/1235161899046535169.webp?size=128&quality=lossless",
            
            [emojiNames.warn]: "https://cdn.discordapp.com/emojis/1235162120644198410.webp?size=128&quality=lossless",
            [emojiNames.info]: "https://cdn.discordapp.com/emojis/1235175778032029756.gif?size=128&quality=lossless",
            [emojiNames.top_bir]: "https://cdn.discordapp.com/emojis/1235161684969259009.webp?size=128&quality=lossless",
            [emojiNames.top_iki]: "https://cdn.discordapp.com/emojis/1235177405513994273.webp?size=128&quality=lossless",
            [emojiNames.top_uc]: "https://cdn.discordapp.com/emojis/1235162066755649546.webp?size=128&quality=lossless",
            [emojiNames.nocommand]: "https://cdn.discordapp.com/emojis/1235162103262871592.webp?size=128&quality=lossless",
            [emojiNames.kalp]: "https://cdn.discordapp.com/emojis/1235161713402187836.webp?size=128&quality=lossless",
            [emojiNames.punish]: "https://cdn.discordapp.com/emojis/1235161749410545664.webp?size=128&quality=lossless",
            [emojiNames.star]: "https://cdn.discordapp.com/emojis/1235161929752903772.webp?size=128&quality=lossless",
            [emojiNames.face]: "https://cdn.discordapp.com/emojis/1235161643852365886.webp?size=128&quality=lossless",
            [emojiNames.fire]: "https://cdn.discordapp.com/emojis/1235161657681117224.webp?size=128&quality=lossless",
            [emojiNames.like]: "https://cdn.discordapp.com/emojis/1235161731819376780.webp?size=128&quality=lossless",
            [emojiNames.sagok]: "https://cdn.discordapp.com/emojis/1238493890714013717.webp?size=128&quality=lossless",
            [emojiNames.stat]: "https://cdn.discordapp.com/emojis/1102633652074057738.gif?size=128&quality=lossless",
            [emojiNames.member]: "https://cdn.discordapp.com/emojis/1202317755764965386.webp?size=128&quality=lossless",
            [emojiNames.dislike]: "https://cdn.discordapp.com/emojis/1266349718666215424.webp?size=128&quality=lossless",
            [emojiNames.nokta]: "https://cdn.discordapp.com/emojis/1268245979157631159.webp?size=128&quality=lossless",
        };

        for (const [emojiName, emojiLink] of Object.entries(emojiList)) {
            const existingEmoji = message.guild.emojis.cache.find(e => e.name === emojiName);
            if (!existingEmoji) {
                await message.guild.emojis.create({ attachment: emojiLink, name: emojiName })
                    .then(() => {
                        message.channel.send({ content: `Başarıyla ${emojiName} emojisi oluşturuldu.` });
                    })
                    .catch(err => console.log(err));
            } else {
                message.channel.send({ content: `${emojiName} emojisi zaten mevcut.` });
            }
        }

        interaction.reply({ content: `Emoji kurulumu başarıyla tamamlandı.`, ephemeral: true });
    }
});

function randomColor() {
const letters = '0123456789ABCDEF';
let color = '#';
for (let i = 0; i < 6; i++) {
color += letters[Math.floor(Math.random() * 16)];
}
return color;
}
}
    }