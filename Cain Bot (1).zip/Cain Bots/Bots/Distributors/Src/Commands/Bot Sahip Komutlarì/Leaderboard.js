const { EmbedBuilder } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");
moment.locale("tr");
const settings = require("../../../../../Src/Settings/Settings.json");
const lb = require("../../../../../Src/Schemas/leaderboard"); // Leaderboard veritabanı modeli
const voiceUser = require("../../../../../Src/Schemas/VoiceUsers"); // Ses verileri modeli
const messageUser = require("../../../../../Src/Schemas/MessageUsers"); // Mesaj verileri modeli
const db = require("../../../../../Src/Schemas/İnvited"); // Davet verileri modeli

module.exports = {
    conf: {
        aliases: ["leaderboard", "lb"],
        name: "lb",
        help: "lb-kur",
        owner: true,
        category: "developer",
    },

    Cyrstal: async (client, message, args) => {

        if (!args[0]) {
            return message.reply({
                content: `${settings.prefix}leaderboard kur/sıfırla`
            }).then((msg) => setTimeout(() => msg.delete(), 15000));
        }

        if (["kur", "kurulum", "setup"].includes(args[0])) {
            try {
                const existingData = await lb.findOne({ guildID: message.guild.id });
                if (existingData) {
                    return message.reply({
                        content: `Database'de kayıtlı veri bulunmakta. Sıfırlamadan kurulum yapamazsınız.`
                    }).then((msg) => setTimeout(() => msg.delete(), 15000));
                }

                const guild = client.guilds.cache.get(message.guild.id);

                // Verileri al
                const voiceUsersData = await voiceUser.find({ guildID: guild.id }).sort({ topStat: -1 });
                const messageUsersData = await messageUser.find({ guildID: guild.id }).sort({ topStat: -1 });
                const inviteData = await db.find({ guildID: guild.id }).sort({ total: -1 });
                let inviteList = [];

                inviteData.forEach((x, index) => {
                    inviteList.push(`❯ \` ${index + 1}. \` <@${x.userID}>: \` ${x.total} Davet \``);
                });

                // Sıralama listelerini oluştur
                const voiceList = await Promise.all(voiceUsersData.slice(0, 30).map(async (x, index) => {
                    const user = await guild.members.fetch(x.userID).catch(() => null);
                    const userName = user ? user.displayName : "Unknown";
                    return `❯ \` ${index + 1}. \` ${userName}: \` ${moment.duration(x.topStat).format("D [Gün], H [Saat], m [Dakika]")} \``;
                }));

                const messageList = await Promise.all(messageUsersData.slice(0, 30).map(async (x, index) => {
                    const user = await guild.members.fetch(x.userID).catch(() => null);
                    const userName = user ? user.displayName : "Unknown";
                    return `❯ \` ${index + 1}. \` ${userName}: \` ${x.topStat.toLocaleString()} Mesaj \``;
                }));

                // Embed oluştur
                const ChatEmbed = new EmbedBuilder()
                    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                    .setDescription(`\`${guild.name}\` sunucusunun genel mesaj sıralaması listelenmektedir.\n\n${messageList.join("\n") || "Veri Bulunmuyor."}\n\nGüncellenme Tarihi: <t:${Math.floor(Date.now() / 1000)}:R>`);

                const VoiceEmbed = new EmbedBuilder()
                    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                    .setDescription(`\`${guild.name}\` sunucusunun genel ses sıralaması listelenmektedir.\n\n${voiceList.join("\n") || "Veri Bulunmuyor."}\n\nGüncellenme Tarihi: <t:${Math.floor(Date.now() / 1000)}:R>`);

                const InviteEmbed = new EmbedBuilder()
                    .setAuthor({ name: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                    .setDescription(`\`${guild.name}\` sunucusunun genel davet sıralaması listelenmektedir.\n\n${inviteList.join("\n") || "Veri Bulunmuyor."}\n\nGüncellenme Tarihi: <t:${Math.floor(Date.now() / 1000)}:R>`);

                // Kanaldaki mesajları gönder
                const LeaderBoardChannel = message.channel;
                const chatMessage = await LeaderBoardChannel.send({ embeds: [ChatEmbed] });
                const voiceMessage = await LeaderBoardChannel.send({ embeds: [VoiceEmbed] });
                const inviteMessage = await LeaderBoardChannel.send({ embeds: [InviteEmbed] });

                // Veritabanına kaydet
                await lb.create({
                    guildID: message.guild.id,
                    channelID: LeaderBoardChannel.id,
                    messageListID: chatMessage.id,
                    voiceListID: voiceMessage.id,
                    inviteListID: inviteMessage.id
                });

                // 10 saniyede bir sıralamaları güncelle
                setInterval(async () => {
                    const updatedVoiceUsersData = await voiceUser.find({ guildID: guild.id }).sort({ topStat: -1 });
                    const updatedMessageUsersData = await messageUser.find({ guildID: guild.id }).sort({ topStat: -1 });
                    const updatedInviteData = await db.find({ guildID: guild.id }).sort({ total: -1 });

                    let updatedInviteList = [];
                    updatedInviteData.forEach((x, index) => {
                        updatedInviteList.push(`❯ \` ${index + 1}. \` <@${x.userID}>: \` ${x.total} Davet \``);
                    });

                    const updatedVoiceList = await Promise.all(updatedVoiceUsersData.slice(0, 30).map(async (x, index) => {
                        const user = await guild.members.fetch(x.userID).catch(() => null);
                        const userName = user ? user.displayName : "Unknown";
                        return `❯ \` ${index + 1}. \` ${userName}: \` ${moment.duration(x.topStat).format("D [Gün], H [Saat], m [Dakika]")} \``;
                    }));

                    const updatedMessageList = await Promise.all(updatedMessageUsersData.slice(0, 30).map(async (x, index) => {
                        const user = await guild.members.fetch(x.userID).catch(() => null);
                        const userName = user ? user.displayName : "Unknown";
                        return `❯ \` ${index + 1}. \` ${userName}: \` ${x.topStat.toLocaleString()} Mesaj \``;
                    }));

                    const updatedChatEmbed = new EmbedBuilder()
                        .setAuthor({ name: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                        .setDescription(`\`${guild.name}\` sunucusunun genel mesaj sıralaması listelenmektedir.\n\n${updatedMessageList.join("\n") || "Veri Bulunmuyor."}\n\nGüncellenme Tarihi: <t:${Math.floor(Date.now() / 1000)}:R>`);

                    const updatedVoiceEmbed = new EmbedBuilder()
                        .setAuthor({ name: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                        .setDescription(`\`${guild.name}\` sunucusunun genel ses sıralaması listelenmektedir.\n\n${updatedVoiceList.join("\n") || "Veri Bulunmuyor."}\n\nGüncellenme Tarihi: <t:${Math.floor(Date.now() / 1000)}:R>`);

                    const updatedInviteEmbed = new EmbedBuilder()
                        .setAuthor({ name: guild.name, iconURL: guild.iconURL({ dynamic: true }) })
                        .setDescription(`\`${guild.name}\` sunucusunun genel davet sıralaması listelenmektedir.\n\n${updatedInviteList.join("\n") || "Veri Bulunmuyor."}\n\nGüncellenme Tarihi: <t:${Math.floor(Date.now() / 1000)}:R>`);

                    await chatMessage.edit({ embeds: [updatedChatEmbed] });
                    await voiceMessage.edit({ embeds: [updatedVoiceEmbed] });
                    await inviteMessage.edit({ embeds: [updatedInviteEmbed] });

                }, 10000); // Her 10 saniyede bir güncellenir

            } catch (error) {
                console.error("Kurulum hatası:", error);
                message.reply({ content: "Kurulum sırasında bir hata oluştu. Lütfen tekrar deneyin." });
            }
        }

        if (["temizle", "sıfırla"].includes(args[0])) {
            try {
                const existingData = await lb.findOne({ guildID: message.guild.id });
                if (!existingData) {
                    return message.reply({
                        content: `Database'de kayıtlı veri bulunmamaktadır.`
                    }).then((msg) => setTimeout(() => msg.delete(), 5000));
                }

                const channel = message.guild.channels.cache.get(existingData.channelID);
                if (channel) {
                    const chatMessage = await channel.messages.fetch(existingData.messageListID).catch(() => null);
                    const voiceMessage = await channel.messages.fetch(existingData.voiceListID).catch(() => null);
                    const inviteMessage = await channel.messages.fetch(existingData.inviteListID).catch(() => null);
                    if (chatMessage) await chatMessage.delete();
                    if (voiceMessage) await voiceMessage.delete();
                    if (inviteMessage) await inviteMessage.delete();
                }

                await lb.deleteOne({ guildID: message.guild.id });

                message.reply({ content: `Leaderboard verileri başarıyla sıfırlandı.` });

            } catch (error) {
                console.error("Sıfırlama hatası:", error);
                message.reply({ content: "Sıfırlama işlemi sırasında bir hata oluştu." });
            }
        }
    }
};
