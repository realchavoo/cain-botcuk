const settings = require("../../../../../Src/Settings/Settings.json");
const emojis = require("../../../../../Src/Settings/emojiName.json");
const Discord = require("discord.js");

module.exports = {
  conf: {
    aliases: ["kur-yardım","setup-yardım","setup-yardim"],
    name: "setup-yardım",
    help: "setup-yardım",
    category: "developer",
    owner: true
  },
  Cyrstal: async (client, message, args, embed) => {

    const initialEmbed = new Discord.EmbedBuilder()
    .setDescription(`
📋 **Bot Kurulumu!** Botu kolayca kurarak sunucunuza entegre edebilirsiniz. Aşağıdaki seçeneklerle botun özelliklerini yapılandırın:

🔹 **Sunucu Kurulumu** - Sunucu ayarlarını düzenleyin.
🔹 **Rol Kurulumu** - Rol ayarlarını yapılandırın.
🔹 **Kanal Kurulumu** - Kanallarınızı ayarlayın.
🔹 **Kategori Kurulumu** - Kategorileri yapılandırın.
🔹 **Guard Kurulumu** - Güvenlik ayarlarınızı optimize edin.

✨ *Daha fazla detay için, aşağıdaki menüden ihtiyacınıza uygun seçeneği belirleyin!* ✨
`);

    const row = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.StringSelectMenuBuilder()
          .setCustomId("setupMenu")
          .setPlaceholder("Bir seçenek seçin")
          .addOptions([
            {
              label: "Sunucu Kurulum",
              description: "Sunucu Ayarları",
              value: "info",
            },
            {
              label: "Rol Kurulum",
              description: "Rol Ayarları",
              value: "roles",
            },
            {
              label: "Kanal Kurulum",
              description: "Kanal Ayarları",
              value: "channels",
            },
            {
              label: "kategori Kurulum",
              description: "kategori Ayarları",
              value: "permissions",
            },
            {
              label: "Guard Kurulum",
              description: "Guard Ayarları",
              value: "logs",
            }
          ])
      );

    const msg = await message.channel.send({ embeds: [initialEmbed], components: [row] });

    const collector = msg.createMessageComponentCollector({
      componentType: Discord.ComponentType.StringSelect,
      time: 60000 
    });

    collector.on("collect", async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        return interaction.reply({ content: "Bu menüyü kullanma yetkiniz yok.", ephemeral: true });
      }

      let selectedEmbed;
      if (interaction.values[0] === "info") {
        selectedEmbed = new Discord.EmbedBuilder()
          .setDescription(`
**.setup servertag** - 🏷️ Sunucu tagını ayarlamak için.
**.setup defaulttag** - 📌 Varsayılan tagı ayarlamak için.
**.setup nametag** - 📝 İsim tagını ayarlamak için.
**.setup botfooter** - ✏️ Botun alt yazısını ayarlamak için.
**.setup unregistername** - 🗃️ Kayıtsız isim ayarlamak için.
**.setup guildname** - 🏛️ Sunucu adı ayarlamak için.
**.setup guildurl** - 🔗 Sunucu URL’sini ayarlamak için.
**.setup botroles** - 🛡️ Bot rolleri ayarlamak için.
**.setup voicechannel** - 🎙️ Botun bağlanacağı ses kanalını ayarlamak için.
**.setup minage** - 📅 Minimum yaş sınırı ayarlamak için.
            `);
      } else if (interaction.values[0] === "roles") {
        selectedEmbed = new Discord.EmbedBuilder()
          .setTitle("Rol Ayarları")
          .setDescription(`
**.setup manroles** - 👨 Erkek rolleri ayarlamak için.
**.setup womanroles** - 👩 Kadın rolleri ayarlamak için.
**.setup unregisterroles** - 📁 Kayıtsız rolleri ayarlamak için.
**.setup staffroles** - 🛠️ Yetkili rolleri ayarlamak için.
**.setup seniorstaffroles** - 🏅 Üst yetkili rolleri ayarlamak için.
**.setup staffstartroles** - 🎓 Yetkili başlangıç rolleri ayarlamak için.
**.setup registerroles** - 📋 Kayıt sorumlusu rolleri ayarlamak için.
**.setup tagroles** - 🎫 Taglı rolleri ayarlamak için.
**.setup ownerroles** - 👑 Sahip rolleri ayarlamak için.
**.setup boosterroles** - 💎 Booster rolleri ayarlamak için.
**.setup warnhammer** - ⚠️ Uyarı yetkisi olan rolleri ayarlamak için. [AYARLANACAK]
**.setup banhammer** - 🚫 Ban yetkisi olan rolleri ayarlamak için.
**.setup jailhammer** - 🔒 Karantina yetkisi olan rolleri ayarlamak için.
**.setup mutehammer** - 🔇 Susturma yetkisi olan rolleri ayarlamak için.
**.setup jailroles** - 🏚️ Karantina rolleri ayarlamak için.
**.setup reklamroles** - 📣 Reklamcı rolleri ayarlamak için.
**.setup muteroles** - 🔕 Chat mute rolleri ayarlamak için.
**.setup vmuteroles** - 🎙️ Voice mute rolleri ayarlamak için.
**.setup fakeaccroles** - 🆕 Yeni hesap rolleri ayarlamak için.
**.setup bannedtagroles** - 🚫 Yasaklı tag rolleri ayarlamak için.
**.setup roleaddroles** - ➕ Rol işlem rolleri ayarlamak için.
**.setup viproles** - ⭐ VIP rolleri ayarlamak için.
**.setup katildiperm** - ✅ Katıldı yetkisi olan rolleri ayarlamak için.
**.setup katilmadiperm** - ❌ Katılmadı yetkisi olan rolleri ayarlamak için.
**.setup mazeretperm** - 🕒 Mazeretli rolleri ayarlamak için.
**.setup scroles** - 🔍 Sorun çözme yetkilisi rolleri ayarlamak için.
    `);
      } else if (interaction.values[0] === "channels") {
        selectedEmbed = new Discord.EmbedBuilder()
          .setTitle("Kanal Ayarları")
          .setDescription(`
**.setup chatchannel** - 💬 Sohbet kanalı ayarlamak için.
**.setup invitechannel** - ✉️ İnvite kanalı ayarlamak için.
**.setup registerchannel** - 👋 Kayıt kanalı ayarlamak için.
**.setup ruleschannel** - 📜 Kurallar kanalı ayarlamak için.
**.setup solvingchannel** - 🛠️ Sorun çözme log kanalı ayarlamak için.
**.setup afkchannel** - 🔇 Afk ses kanalı ayarlamak için.`
);
      } else if (interaction.values[0] === "permissions") {
        selectedEmbed = new Discord.EmbedBuilder()
          .setDescription(`
**.setup publicparents** - 🌐 Public kategorisini ayarlamak için.
**.setup registerparents** - 📝 Kayıt kategorisini ayarlamak için.
**.setup solvingparents** - 🛠️ Sorun çözme kategorisini ayarlamak için.
**.setup privateparents** - 🔒 Secret kategorisini ayarlamak için.
**.setup aloneparents** - 🧑 Alone kategorisini ayarlamak için.
**.setup funparents** - 🎉 Eğlence kategorisini ayarlamak için.
**.setup vkparents** - 🎤 VK kategorisini ayarlamak için.
**.setup streamerparents** - 📺 Streamer kategorisini ayarlamak için.`
);
      } else if (interaction.values[0] === "logs") {
        selectedEmbed = new Discord.EmbedBuilder()
          .setDescription(`
**.setup rolecreatelimit [Sayı]** - Rol oluşturma limiti ayarını yapılandırır.
**.setup channelcreatelimit [Sayı]** - Kanal oluşturma limiti ayarını yapılandırır.
**.setup emojicreatelimit [Sayı]** - Emoji oluşturma limiti ayarını yapılandırır.
**.setup roleupdatelimit [Sayı]** - Rol güncelleme limiti ayarını yapılandırır.
**.setup channelupdatelimit [Sayı]** - Kanal güncelleme limiti ayarını yapılandırır.
**.setup emojiupdatelimit [Sayı]** - Emoji güncelleme limiti ayarını yapılandırır.
**.setup roledeletelimit [Sayı]** - Rol silme limiti ayarını yapılandırır.
**.setup channeldeletelimit [Sayı]** - Kanal silme limiti ayarını yapılandırır.
**.setup emojideletelimit [Sayı]** - Emoji silme limiti ayarını yapılandırır.
**.setup stickercreatelimit [Sayı]** - Sticker oluşturma limiti ayarını yapılandırır.
**.setup stickerupdatelimit [Sayı]** - Sticker güncelleme limiti ayarını yapılandırır.
**.setup stickerdeletelimit [Sayı]** - Sticker silme limiti ayarını yapılandırır.
**.setup webhookcreatelimit [Sayı]** - Webhook oluşturma limiti ayarını yapılandırır.
**.setup webhookupdatelimit [Sayı]** - Webhook güncelleme limiti ayarını yapılandırır.
**.setup webhookdeletelimit [Sayı]** - Webhook silme limiti ayarını yapılandırır.
**.setup memberroleupdatelimit [Sayı]** - Üye rol güncelleme limiti ayarını yapılandırır.
**.setup memberbanlimit [Sayı]** - Üye yasaklama limiti ayarını yapılandırır.
**.setup memberkicklimit [Sayı]** - Üye atma limiti ayarını yapılandırır.
**.setup memberunbanlimit [Sayı]** - Üye yasak kaldırma limiti ayarını yapılandırır.
          `);
      }

      await interaction.update({ embeds: [selectedEmbed] });
    });

    collector.on("end", async () => {
      await msg.edit({ components: [] });
    });
  }
};
