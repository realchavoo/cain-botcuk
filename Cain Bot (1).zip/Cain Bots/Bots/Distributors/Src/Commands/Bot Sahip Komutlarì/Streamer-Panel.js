const Discord = require("discord.js")
const emojis = require("../../../../../Src/Settings/emojiName.json")
module.exports = {
conf: {
aliases: ["streamer-panel", "streamerpanel", "st-panel", "stpanel"],
name: "st-panel",
help: "st-panel",
category: "developer",
owner: true
},
Cyrstal: async (client, message, args, embed) => {
await message.delete().catch(e => {})
const row = new Discord.ActionRowBuilder()
.addComponents(
new Discord.ButtonBuilder()
.setCustomId("sahiplen")
.setLabel("Streamer Odası Sahiplen")
.setStyle(Discord.ButtonStyle.Primary),
new Discord.ButtonBuilder()
.setCustomId("streamizinver")
.setLabel("Odada Yayın İznı Ver")
.setStyle(Discord.ButtonStyle.Primary),
new Discord.ButtonBuilder()
.setCustomId("streamizinal")
.setLabel("Odada Yayın İzni Al")
.setStyle(Discord.ButtonStyle.Primary),
new Discord.ButtonBuilder()
.setCustomId("streamname")
.setLabel("Odanın İsmini Ayarla")
.setStyle(Discord.ButtonStyle.Primary)
)
await message.channel.send({content: `
${message.guild.emojiGöster(emojis.sagok)} **${message.guild.name}** Streamer Yönetim Paneli;

\` Streamer Oda Sahiplen. \` Bulunduğunuz Streamer Odasını Sahiplenip Yayın Açmanızı Sağlar.
\` Odada Yayın İznı Ver. \` Bulunduğunuz Odada Seçtiğiniz Kullanıcıya Yayın İzni Verir.
\` Odada Yayın İzni Al. \` Bulunduğunuz Odada Seçtiğiniz Kullanıcıdan Yayın İzni Alır.
\` Odanın İsmini Ayarla. \` Bulunduğunuz Odanın İsmini Değiştirir. (**Streamer Sorumlulularına Özel**)`, components: [row]})
}
}