const Discord = require("discord.js")
const emojis = require("../../../../../Src/Settings/emojiName.json")
module.exports = {
conf: {
aliases: ["sc-panel", "scpanel"],
name: "sc-panel",
help: "sc-panel",
category: "developer",
owner: true
},
Cyrstal: async (client, message, args, embed) => {
await message.delete().catch(e => {})
const row = new Discord.ActionRowBuilder()
.addComponents(
new Discord.ButtonBuilder()
.setCustomId("sc-panel")
.setLabel("Sorun Çözme Çağır.")
.setStyle(Discord.ButtonStyle.Primary)
.setEmoji("1087380479189196870"))
await message.channel.send({content: `${message.guild.emojiGöster(emojis.sagok)} Merhabalar Değerli **${message.guild.name}** Üyeleri, Aşağı Tarafta Bulunan Butondan Sorun Çözücü Arkadaşlara Ulaşabilirsiniz.

Lütfen ⁠${message.guild.channels.cache.find(x => x.name == "sorun-çözme" || x.name == "sorun-cözme" || x.name == "sorun-cözme-chat" || x.name == "sorun-çözme-chat") || "**Sorun Çözme Chat**"} Kanalından Kişi Etiketleyip Gereksiz Yoğunluğa Sebep Açmayınız.`, components: [row]})
}
}