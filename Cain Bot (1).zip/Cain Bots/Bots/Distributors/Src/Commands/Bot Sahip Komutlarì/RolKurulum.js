const emojis = require("../../../../../Src/Settings/emojiName.json")
const setups = require("../../../../../Src/Schemas/Setup")
const Discord = require("discord.js");
const settings = require("../../../../../Src/Settings/Settings.json")
module.exports = {
    conf: {
      aliases: ["rkurulum"],
      name: "rkurulum",
      help: "rkurulum",
      category: "developer",
      owner: true
    },
    Cyrstal: async (client, message, args, embed) => {

const row = new Discord.ActionRowBuilder()
.addComponents(
new Discord.ButtonBuilder()
.setCustomId("rolk")
.setLabel("Rol Kurulum")
.setStyle(Discord.ButtonStyle.Secondary),
)
let msg = await message.channel.send({ content: `Role Select Rollerini Kurmak için Tıkla.`, components: [row]})
var filter = (button) => button.user.id === message.author.id;
const collector = msg.createMessageComponentCollector({ filter, time: 60000 })
collector.on("collect", async interaction => {
    if (interaction.customId === "rolk") {
        const ayar = await setups.findOne({guildID: settings.Moderation.guildID})
        const blackRoles = await message.guild.roles.create({
            name: "Siyah",
            color: "#030101",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            })
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { blackRoles: blackRoles.id } }, { upsert: true })
            const blueRoles = await message.guild.roles.create({
            name: "Mavi",
            color: "#2e8ff0",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            })
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { blueRoles: blueRoles.id } }, { upsert: true })
            const whiteRoles = await message.guild.roles.create({
            name: "Beyaz",
            color: "#ffffff",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { whiteRoles: whiteRoles.id } }, { upsert: true })
            const redRoles = await message.guild.roles.create({
            name: "Kırmızı",
            color: "#ff0000",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { redRoles: redRoles.id } }, { upsert: true })
            const yellowRoles = await message.guild.roles.create({
            name: "Sarı",
            color: "#a3ff00",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { yellowRoles: yellowRoles.id } }, { upsert: true })
            const pinkRoles = await message.guild.roles.create({
            name: "Pembe",
            color: "#ff0cfc",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { pinkRoles: pinkRoles.id } }, { upsert: true })
            const purpleRoles = await message.guild.roles.create({
            name: "Mor",
            color: "#7c00f8",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { purpleRoles: purpleRoles.id } }, { upsert: true })
            const orangeRoles = await message.guild.roles.create({
            name: "Turuncu",
            color: "#ff7c00",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { orangeRoles: orangeRoles.id } }, { upsert: true })
            const greenRoles = await message.guild.roles.create({
            name: "Yeşil",
            color: "#119f14",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { greenRoles: greenRoles.id } }, { upsert: true })
            const brownRoles = await message.guild.roles.create({
            name: "Kahverengi",
            color: "#703307",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { brownRoles: brownRoles.id } }, { upsert: true })
            const burgundyRoles = await message.guild.roles.create({
            name: "Bordo",
            color: "#670303",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { burgundyRoles: burgundyRoles.id } }, { upsert: true })
            const turquoiseRoles = await message.guild.roles.create({
            name: "Turkuaz",
            color: "#00ffdb",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { turquoiseRoles: turquoiseRoles.id } }, { upsert: true })
            const beigeRoles = await message.guild.roles.create({
            name: "Bej",
            color: "#fdffe0",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { beigeRoles: beigeRoles.id } }, { upsert: true })
            const navyblueRoles = await message.guild.roles.create({
            name: "Lacivert",
            color: "#02002c",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { navyblueRoles: navyblueRoles.id } }, { upsert: true })
            const lightblueRoles = await message.guild.roles.create({
            name: "Açık Mavi",
            color: "#92cbf0",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { lightblueRoles: lightblueRoles.id } }, { upsert: true })
            const pistachiogreenRoles = await message.guild.roles.create({
            name: "Fıstık Yeşili",
            color: "#009e7d",
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq.",
            position: ayar && ayar.boosterRoles ? message.guild.roles.cache.get(ayar.boosterRoles).position + 1 : 0
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { pistachiogreenRoles: pistachiogreenRoles.id } }, { upsert: true })
            await message.guild.roles.create({
            name: "━━━━Etkinlik Rolleri━━━━",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            const etkinlikRoles = await message.guild.roles.create({
            name: "🎉 Etkinlik Katılımcısı",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { etkinlikRoles: etkinlikRoles.id } }, { upsert: true })
            const cekilisRoles = await message.guild.roles.create({
            name: "🎁 Çekiliş Katılımcısı",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { cekilisRoles: cekilisRoles.id } }, { upsert: true })
            await message.guild.roles.create({
            name: "━━━━İlişki Rolleri━━━━",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            const coupleRoles =  await message.guild.roles.create({
            name: "Sevgilim Var",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            })
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { coupleRoles: coupleRoles.id } }, { upsert: true })
            const aloneRoles = await message.guild.roles.create({
            name: "Sevgilim Yok",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { aloneRoles: aloneRoles.id } }, { upsert: true })
            const syRoles = await message.guild.roles.create({
            name: "Sevgili Yapmıyorum",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { syRoles: syRoles.id } }, { upsert: true })
            await message.guild.roles.create({
            name: "━━━━Oyun Rolleri━━━━",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            const minecraftRoles = await message.guild.roles.create({
            name: "Minecraft",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { minecraftRoles: minecraftRoles.id } }, { upsert: true })
            const fortniteRoles = await message.guild.roles.create({
            name: "Fortnite",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { fortniteRoles: fortniteRoles.id } }, { upsert: true })
            const mlbbRoles = await message.guild.roles.create({
            name: "Mobile Legends",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { mlbbRoles: mlbbRoles.id } }, { upsert: true })
            const csRoles = await message.guild.roles.create({
            name: "Counter Strike",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { csRoles: csRoles.id } }, { upsert: true })
            const pubgRoles = await message.guild.roles.create({
            name: "Pubg",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { pubgRoles: pubgRoles.id } }, { upsert: true })
            const amongusRoles = await message.guild.roles.create({
            name: "Among Us",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { amongusRoles: amongusRoles.id } }, { upsert: true })
            const lolRoles = await message.guild.roles.create({
            name: "League Of Legends",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { lolRoles: lolRoles.id } }, { upsert: true })
            const gtavRoles = await message.guild.roles.create({
            name: "Gta V",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { gtavRoles: gtavRoles.id } }, { upsert: true })
            const valorantRoles = await message.guild.roles.create({
            name: "Valorant",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { valorantRoles: valorantRoles.id } }, { upsert: true })
            const metinTwoRoles = await message.guild.roles.create({
            name: "Metin 2",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { metinTwoRoles: metinTwoRoles.id } }, { upsert: true })
            const fivemRoles = await message.guild.roles.create({
            name: "FiveM",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { fivemRoles: fivemRoles.id } }, { upsert: true })
            const zulaRoles = await message.guild.roles.create({
            name: "Zula",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { zulaRoles: zulaRoles.id } }, { upsert: true })
            const mtaRoles = await message.guild.roles.create({
            name: "MTA:SA",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { mtaRoles: mtaRoles.id } }, { upsert: true })
            await message.guild.roles.create({
            name: "━━━━Takım Rolleri━━━━",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            const bjkRoles = await message.guild.roles.create({
            name: "Beşiktaş",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { bjkRoles: bjkRoles.id } }, { upsert: true })
            const gsRoles = await message.guild.roles.create({
            name: "Galatasaray",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { gsRoles: gsRoles.id } }, { upsert: true })
            const fbRoles = await message.guild.roles.create({
            name: "Fenerbahçe",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { fbRoles: fbRoles.id } }, { upsert: true })
            const tsRoles = await message.guild.roles.create({
            name: "Trabzonspor",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { tsRoles: tsRoles.id } }, { upsert: true })
            await message.guild.roles.create({
            name: "━━━━Burç Rolleri━━━━",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            const akrepRoles = await message.guild.roles.create({
            name: "♏ Akrep",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { akrepRoles: akrepRoles.id } }, { upsert: true })
            const yengecRoles = await message.guild.roles.create({
            name: "♋ Yengeç",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { yengecRoles: yengecRoles.id } }, { upsert: true })
            const ikizlerRoles = await message.guild.roles.create({
            name: "♊ İkizler",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { ikizlerRoles: ikizlerRoles.id } }, { upsert: true })
            const yayRoles = await message.guild.roles.create({
            name: "♐ Yay",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { yayRoles: yayRoles.id } }, { upsert: true })
            const aslanRoles = await message.guild.roles.create({
            name: "♌ Aslan",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { aslanRoles: aslanRoles.id } }, { upsert: true })
            const teraziRoles = await message.guild.roles.create({
            name: "♎ Terazi",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { teraziRoles: teraziRoles.id } }, { upsert: true })
            const basakRoles = await message.guild.roles.create({
            name: "♍ Başak",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { basakRoles: basakRoles.id } }, { upsert: true })
            const kovaRoles = await message.guild.roles.create({
            name: "♒ Kova",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { kovaRoles: kovaRoles.id } }, { upsert: true })
            const balikRoles = await message.guild.roles.create({
            name: "♓ Balık",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { balikRoles: balikRoles.id } }, { upsert: true })
            const oglakRoles = await message.guild.roles.create({
            name: "♑ Oğlak",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { oglakRoles: oglakRoles.id } }, { upsert: true })
            const bogaRoles = await message.guild.roles.create({
            name: "♉ Boğa",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { bogaRoles: bogaRoles.id } }, { upsert: true })
            const kocRoles = await message.guild.roles.create({
            name: "♈ Koç",
            color: randomColor(),
            permissions: "0",
            reason: "Rol Seçim Menüsü için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { kocRoles: kocRoles.id } }, { upsert: true })
            await message.guild.roles.create({
            name: "━━━━Aylık Perm Rolleri━━━━",
            color: randomColor(),
            permissions: "0",
            reason: "Aylık perm için Lazımki kurduk sanane aq."
            });
            const oneMonthRoles = await message.guild.roles.create({
            name: "🥇 1 Aylık Üye",
            color: randomColor(),
            permissions: "0",
            reason: "Aylık perm için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { oneMonthRoles: oneMonthRoles.id } }, { upsert: true })
            const threeMonthRoles = await message.guild.roles.create({
            name: "🥉 3 Aylık Üye",
            color: randomColor(),
            permissions: "0",
            reason: "Aylık perm için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { threeMonthRoles: threeMonthRoles.id } }, { upsert: true })
            const sixMonthRoles = await message.guild.roles.create({
            name: "🏅 6 Aylık Üye",
            color: randomColor(),
            permissions: "0",
            reason: "Aylık perm için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { sixMonthRoles: sixMonthRoles.id } }, { upsert: true })
            const nineMonthRoles = await message.guild.roles.create({
            name: "🎖️ 9 Aylık Üye",
            color: randomColor(),
            permissions: "0",
            reason: "Aylık perm için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { nineMonthRoles: nineMonthRoles.id } }, { upsert: true })
            const oneYearRoles = await message.guild.roles.create({
            name: "🏆 1 Senelik Üye",
            color: randomColor(),
            permissions: "0",
            reason: "Aylık perm için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { oneYearRoles: oneYearRoles.id } }, { upsert: true })
            await message.guild.roles.create({
            name: "━━━━Perm Rolleri━━━━",
            color: randomColor(),
            permissions: "0",
            reason: "Bot için Lazımki kurduk sanane aq."
            });
            const katildiPerms = await message.guild.roles.create({
            name: "✔️ Katıldı",
            color: randomColor(),
            permissions: "0",
            reason: "Perm için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { katildiPerms: katildiPerms.id } }, { upsert: true })
            const katilmadiPerms = await message.guild.roles.create({
            name: "❌ Katılmadı",
            color: randomColor(),
            permissions: "0",
            reason: "Perm için Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { katilmadiPerms: katilmadiPerms.id } }, { upsert: true })
            const mazeretPerms = await message.guild.roles.create({
            name: "✔️ Mazeretli",
            color: randomColor(),
            permissions: "0",
            reason: "Permiçin Lazımki kurduk sanane aq."
            });
            await setups.updateOne({ guildID: settings.Moderation.guildID }, { $set: { mazeretPerms: mazeretPerms.id } }, { upsert: true })
    }



function randomColor() {
const letters = '0123456789ABCDEF';
let color = '#';
for (let i = 0; i < 6; i++) {
color += letters[Math.floor(Math.random() * 16)];
}
return color;
}
}
)
    }
}