const settings = require('../../Src/Settings/Settings.json');
const { Connect } = require('../../Connects')
const { Bots } = require('../../Clients')
const Discord = require('discord.js')
const fs = require('fs');
const client = global.client = new Bots();
require("./Src/Functions/function")(client)
client.Komutlar = new Discord.Collection();
client.Aliases = new Discord.Collection();
client.Invites = new Discord.Collection();
Connect.BotLogin(client, settings.Moderation.token)
Connect.MongoLogin(settings.Moderation.mongoURL)
Connect.VoiceJoin(client)

fs.readdir('./Src/Commands/', (err, files) => {
if (err) console.error(err);
files.forEach(f => {
fs.readdir("./Src/Commands/" + f, (err2, files2) => {
files2.forEach(file => {
let props = require(`./Src/Commands/${f}/` + file);
console.log(`[MODERATİON - KOMUT] ${props.conf.name} Komutu Yüklendi!`);
client.Komutlar.set(props.conf.name, props);
props.conf.aliases.forEach(alias => {
client.Aliases.set(alias, props.conf.name);
});
})
})
});
});

fs.readdir("./Src/Events", (err, files) => {
if (err) return console.error(err);
files
.filter((file) => file.endsWith(".js"))
.forEach((file) => {
let prop = require(`./Src/Events/${file}`);
if (!prop.conf) return;
client.on(prop.conf.name, prop);
console.log(`[MODERATİON - EVENT] ${prop.conf.name} Eventi Yüklendi!`);
});
});

const ForbiddenWords = require("../../Src/Schemas/yasakkelime")

client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;

    const data = await ForbiddenWords.findOne({ guildID: message.guild.id });
    if (!data || !data.words.length) return;

    const forbiddenWord = data.words.find((word) =>
        message.content.toLowerCase().includes(word.toLowerCase())
    );

    if (forbiddenWord) {
        await message.delete().catch(() => {});

        const warningMessage = await message.channel.send({
            content: `⚠️ **${message.author}, dikkat!**  
❌ Mesajınızda yasaklı bir kelime tespit edildi: **\`${forbiddenWord}\`**  
Lütfen kurallara uygun bir şekilde davranın.`
        });

        // 5 saniye sonra botun mesajını sil
        setTimeout(() => {
            warningMessage.delete().catch(() => {});
        }, 5000);
    }
});

let cameraUsers = 0;

client.on('voiceStateUpdate', (oldState, newState) => {
  // Kullanıcı kamera açtıysa
  if (!oldState.selfVideo && newState.selfVideo) {
    cameraUsers++;
  }

  // Kullanıcı kamera kapattıysa
  if (oldState.selfVideo && !newState.selfVideo) {
    cameraUsers = Math.max(0, cameraUsers - 1); // Negatif olmamalı
  }
});
