const settings = require('../../Src/Settings/Settings.json');
const setups = require("../../Src/Schemas/Setup");
const Discord = require('discord.js');
const {createAudioPlayer,createAudioResource,NoSubscriberBehavior,AudioPlayerStatus, AudioPlayer, joinVoiceChannel} = require('@discordjs/voice');
const play = require('play-dl');
module.exports = async(client, channel) => {
AudioPlayer.setMaxListeners(0)
client.player = createAudioPlayer({inlineVolume : true,behaviors: {noSubscriber: NoSubscriberBehavior.Play},});
client.url = settings.Welcome.youtubeURL;
client.stream;
client.message;
client.channelId;
client.playing;
client.voiceConnection;
client.staffJoined = false;
let stream;
let resource;
if (channel) {
client.on(Discord.Events.ClientReady, async () => {
let guild = client.guilds.cache.get(settings.Moderation.guildID);
if (!guild) return;
let Channel = guild.channels.cache.get(channel);
if (!Channel) return;
client.voiceConnection = await joinVoiceChannel({
channelId: Channel.id,
guildId: Channel.guild.id,
adapterCreator: Channel.guild.voiceAdapterCreator,
group: client.user.id
});
if(!await hasStaff(channel)) {
await client.start(channel)
} else {
client.staffJoined = true
client.playing = false
await client.player.stop()
client.player.play(createAudioResource("./yetkili.mp3"));
}
if (client.connectionInterval) clearInterval(client.connectionInterval);
client.connectionInterval = setInterval(async () => {
client.voiceConnection = await joinVoiceChannel({
channelId: Channel.id,
guildId: Channel.guild.id,
adapterCreator: Channel.guild.voiceAdapterCreator,
group: client.user.id
});
}, 5000);
});
client.on(Discord.Events.VoiceStateUpdate, async (oldState, newState) => {
const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
if (!ayar) return;
if(oldState.channel && !newState.channel && oldState.channelId == channel && await hasStaff(oldState.channel)) {
client.staffJoined = true;
client.playing = false;
await client.player.stop()
client.player.play(createAudioResource("./yetkili.mp3"));
return;}
if(newState.channelId && (oldState.channelId !== newState.channelId) && await isStaff(newState.member) && newState.channelId === channel && !await hasStaff(oldState.channel)) {
client.staffJoined = true;
client.playing = false;
await client.player.stop()
client.player.play(createAudioResource("./yetkili.mp3"));
return;}
if(oldState.channelId && (oldState.channelId !== newState.channelId) && await isStaff(newState.member) && oldState.channelId === channel && !await hasStaff(newState.channel)) {
client.staffJoined = false;
client.playing = true;
client.start(channel)
return;}
if(oldState.channel && oldState.channelId === channel && newState.channelId !== channel && !await hasStaff(oldState.channel)) {
client.staffJoined = false;
client.playing = true;
client.start(channel)
return;}
if (oldState?.member?.id === client?.user?.id && oldState?.channelId && !newState?.channelId) {
let guild = client.guilds.cache.get(settings.Moderation.guildID);
if (!guild) return;
let Channel = guild.channels.cache.get(channel);
if (!Channel) return;
client.voiceConnection = await joinVoiceChannel({
channelId: Channel.id,
guildId: Channel.guild.id,
adapterCreator: Channel.guild.voiceAdapterCreator,
group: client.user.id
});
}
})
}
client.start = async function(channelId, a) {
let guild = client.guilds.cache.get(settings.Moderation.guildID);
if(!guild) return;
let channel = guild.channels.cache.get(channelId);
if(!channel) return;
client.channelId = channelId;
let connection = client.voiceConnection
if(settings.Welcome.mp3 == true) {
resource = client.stream = createAudioResource("./hosgeldin.mp3");
} else if(settings.Welcome.mp3 == false) {
stream = await play.stream(client.url);
resource = client.stream = createAudioResource(stream.stream, {inputType: stream.type});
}
let player = client.player
player.on(AudioPlayerStatus.Playing, () => {});
player.on(AudioPlayerStatus.Paused, () => {});
player.on(AudioPlayerStatus.Idle, async() => {
if(client.staffJoined == true) return;
if(settings.Welcome.mp3 == true) {
resource = client.stream = createAudioResource("./hosgeldin.mp3");
} else if(settings.Welcome.mp3 == false) {
stream = await play.stream(client.url);
resource = client.stream = createAudioResource(stream.stream, {inputType: stream.type});
}
player.play(resource);
connection.subscribe(player);
});
player.on('idle', async () => {
if(client.staffJoined == true) return;
if(settings.Welcome.mp3 == true) {
resource = client.stream = createAudioResource("./hosgeldin.mp3");
} else if(settings.Welcome.mp3 == false) {
stream = await play.stream(client.url);
resource = client.stream = createAudioResource(stream.stream, {inputType: stream.type,});
}
client.player.play(resource);
});
if(client.staffJoined == true) return;
player.play(resource)
connection.subscribe(player);
}
async function hasStaff (channel, checkMember = false) {
const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
if(!ayar) return;
if(!channel) return;
if(channel?.members?.some(m => (checkMember !== false ? m.user.id !== checkMember.id : true) && !m.user.bot && m.roles.highest.position >= m.guild.roles.cache.get(ayar.registerPerms).position)) return true;
return false;
}
async function getStaffs (channel, checkMember = false) {
const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
if(!ayar) return;
if(!channel) return;
return channel?.members?.filter(m => (checkMember !== false ? m.user.id !== checkMember.id : true) && !m.user.bot && m.roles.highest.position > m.guild.roles.cache.get(ayar.registerPerms).position).size
}
async function isStaff(member) {
const ayar = await setups.findOne({ guildID: settings.Moderation.guildID });
if(!ayar) return;
const guild = client.guilds.cache.get(settings.Moderation.guildID);
if(!guild) return;
if(!member || !guild.members.cache.get(member.id)) return;
if(!member.user.bot && (member.permissions.has(Discord.PermissionFlagsBits.Administrator) || member.roles.highest.position >= guild.roles.cache.get(ayar.registerPerms).position)) return true;
return false;
}
};